import functools
from typing import Callable, Any
from telegram import Update
from telegram.ext import ContextTypes

from database import db
from utils.helpers import is_premium

def require_user(func: Callable) -> Callable:
    """Decorator to ensure user exists in database"""
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        if not user:
            return
        
        # Check if user exists
        db_user = await db.get_user(user.id)
        if not db_user:
            # Create user
            db_user = await db.create_user(
                user.id, 
                user.username, 
                user.first_name
            )
        
        # Add user to context
        context.user_data['db_user'] = db_user
        
        return await func(update, context, *args, **kwargs)
    return wrapper

def require_relation(func: Callable) -> Callable:
    """Decorator to ensure user has an active relation with target"""
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        
        # Extract target user
        from utils.helpers import extract_user
        target_id, target_mention = extract_user(update.effective_message)
        
        if not target_id:
            await update.effective_message.reply_text(
                "❌ Укажите пользователя (ответом или упоминанием)"
            )
            return
        
        # Check relation
        relation = await db.get_relation(user.id, target_id)
        if not relation:
            await update.effective_message.reply_text(
                "❌ У вас нет отношений с этим пользователем"
            )
            return
        
        # Add relation to context
        context.user_data['current_relation'] = relation
        context.user_data['target_id'] = target_id
        context.user_data['target_mention'] = target_mention
        
        return await func(update, context, *args, **kwargs)
    return wrapper

def require_partner(func: Callable) -> Callable:
    """Decorator for actions that require both users to be present"""
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        
        # Get relation from context
        relation = context.user_data.get('current_relation')
        if not relation:
            await update.effective_message.reply_text(
                "❌ Отношения не найдены"
            )
            return
        
        # Get partner ID
        partner_id = relation['user2_id'] if relation['user1_id'] == user.id else relation['user1_id']
        
        # Check if partner is in chat
        chat = update.effective_chat
        try:
            member = await chat.get_member(partner_id)
            if member.status in ['left', 'kicked']:
                await update.effective_message.reply_text(
                    "❌ Ваш партнёр покинул чат"
                )
                return
        except:
            pass
        
        return await func(update, context, *args, **kwargs)
    return wrapper

def check_ignore(func: Callable) -> Callable:
    """Decorator to check ignore list"""
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        target_id = context.user_data.get('target_id')
        
        if target_id:
            # Check if target ignores user
            if await db.is_ignored(user.id, target_id):
                await update.effective_message.reply_text(
                    "❌ Этот пользователь добавил вас в игнор-лист RP команд"
                )
                return
            
            # Check if user ignores target
            if await db.is_ignored(target_id, user.id):
                await update.effective_message.reply_text(
                    "❌ Вы не можете взаимодействовать с пользователем, которого игнорируете"
                )
                return
        
        return await func(update, context, *args, **kwargs)
    return wrapper

def premium_required(func: Callable) -> Callable:
    """Decorator for premium-only features"""
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        db_user = context.user_data.get('db_user')
        
        if not db_user:
            db_user = await db.get_user(user.id)
        
        if not is_premium(db_user):
            await update.effective_message.reply_text(
                "💎 Эта функция доступна только для VIP пользователей!\n"
                "Приобретите VIP по команде .вип"
            )
            return
        
        return await func(update, context, *args, **kwargs)
    return wrapper

def admin_only(func: Callable) -> Callable:
    """Decorator for admin-only commands"""
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        chat = update.effective_chat
        
        # Check if user is chat admin
        if chat.type != 'private':
            try:
                member = await chat.get_member(user.id)
                if member.status not in ['creator', 'administrator']:
                    await update.effective_message.reply_text(
                        "❌ Эта команда только для администраторов чата"
                    )
                    return
            except:
                pass
        
        return await func(update, context, *args, **kwargs)
    return wrapper

def rate_limit(seconds: int):
    """Decorator for rate limiting commands"""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            user_id = update.effective_user.id
            command = func.__name__
            
            # Check cooldown in Redis
            redis_key = f"cooldown:{user_id}:{command}"
            last_used = await db.redis.get(redis_key)
            
            if last_used:
                from utils.helpers import format_duration
                remaining = seconds - (await db.redis.ttl(redis_key))
                await update.effective_message.reply_text(
                    f"⏳ Подождите {format_duration(remaining)} перед повторным использованием"
                )
                return
            
            # Set cooldown
            await db.redis.setex(redis_key, seconds, "1")
            
            return await func(update, context, *args, **kwargs)
        return wrapper
    return decorator

def log_command(func: Callable) -> Callable:
    """Decorator to log command usage"""
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        command = update.message.text.split()[0] if update.message else "callback"
        
        # Log to console
        print(f"👤 {user.id} (@{user.username}) used {command}")
        
        # Log to database
        await db.db.command_log.insert_one({
            "user_id": user.id,
            "username": user.username,
            "command": command,
            "timestamp": db._now(),
            "chat_id": update.effective_chat.id if update.effective_chat else None
        })
        
        return await func(update, context, *args, **kwargs)
    return wrapper