import logging
import random
import asyncio
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from database import db
from utils.constants import VEHICLE_TYPES, CASINO_LOCATIONS, INVENTORY_ITEMS
from utils.decorators import require_user, rate_limit, log_command, premium_required
from utils.helpers import format_number, format_duration
from keyboards.inline import casino_menu_keyboard, vehicle_menu_keyboard, location_menu_keyboard

logger = logging.getLogger(__name__)

@require_user
@log_command
async def casino_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Main casino menu"""
    user = update.effective_user
    
    # Get or create casino profile
    profile = await db.get_casino_profile(user.id)
    if not profile:
        profile = await db.create_casino_profile(user.id)
    
    vehicle = profile["vehicle"]
    
    text = (
        f"🎰 **Казино Крабиков**\n\n"
        f"💰 Баланс: {format_number(profile['crabs'])} 🦀\n\n"
        
        f"🚗 **Транспорт**\n"
        f"Тип: {VEHICLE_TYPES[vehicle['type']]['name']}\n"
        f"Уровень: {vehicle['level']}\n"
        f"⚡ Мощность: {vehicle['power']}/{vehicle['max_power']}\n"
        f"⛽ Топливо: {vehicle['fuel']}/{vehicle['max_fuel']}\n"
        f"🔧 Состояние: {vehicle['condition']}%\n"
        f"📦 Хранилище: {vehicle['storage_used']}/{vehicle['max_storage']}\n\n"
        
        f"🗺️ **Локации**\n"
        f"Открыто: {len([l for l in profile['locations'].values() if l.get('unlocked')])}\n\n"
        
        f"**Команды:**\n"
        f"• .транспорт - управление транспортом\n"
        f"• .локация - выбор локации\n"
        f"• .добыча - добывать крабиков\n"
        f"• .рулетка - играть в рулетку\n"
        f"• .динамит - игра Динамит\n"
        f"• .био - биометрия"
    )
    
    await update.effective_message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=casino_menu_keyboard(profile)
    )

@require_user
@log_command
async def vehicle_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Vehicle management"""
    user = update.effective_user
    
    profile = await db.get_casino_profile(user.id)
    if not profile:
        profile = await db.create_casino_profile(user.id)
    
    current_vehicle = profile["vehicle"]
    
    # List available vehicles
    available = []
    for vid in VEHICLE_TYPES:
        if vid == current_vehicle["type"]:
            available.append(vid)
        elif VEHICLE_TYPES[vid].get("price", 0) <= profile["crabs"]:
            # Can afford
            if not VEHICLE_TYPES[vid].get("premium") or is_premium(await db.get_user(user.id)):
                available.append(vid)
    
    text = (
        f"🚗 **Управление транспортом**\n\n"
        f"Текущий: {VEHICLE_TYPES[current_vehicle['type']]['name']}\n"
        f"Уровень: {current_vehicle['level']}\n"
        f"⚡ Мощность: {current_vehicle['power']}/{current_vehicle['max_power']}\n"
        f"⛽ Топливо: {current_vehicle['fuel']}/{current_vehicle['max_fuel']}\n"
        f"💰 Цена топлива: {current_vehicle['fuel_cost_per_liter']} краб/л\n"
        f"🔧 Состояние: {current_vehicle['condition']}%\n"
        f"🛠️ Ремонт: {current_vehicle['repair_cost']} краб\n\n"
        
        f"Доступные улучшения:"
    )
    
    await update.effective_message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=vehicle_menu_keyboard(current_vehicle, available)
    )

@require_user
@log_command
async def location_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Location selection"""
    user = update.effective_user
    
    profile = await db.get_casino_profile(user.id)
    if not profile:
        profile = await db.create_casino_profile(user.id)
    
    text = "🗺️ **Доступные локации**\n\n"
    
    for loc_id, loc_data in profile["locations"].items():
        config = CASINO_LOCATIONS.get(loc_id, {})
        
        if loc_data.get("unlocked"):
            status = "✅"
            req_power = config.get("min_power", 1) * loc_data.get("level", 1)
            crabs = config.get("max_crabs_per_trip", 1000) * loc_data.get("level", 1)
            fuel = config.get("fuel_cost", 10) * loc_data.get("level", 1)
            duration = config.get("duration", 60)
            
            text += f"{status} **{config.get('name', loc_id)}**\n"
            text += f"   Треб. мощность: {req_power}\n"
            text += f"   🦀 Крабиков: до {format_number(crabs)}\n"
            text += f"   ⛽ Топливо: {fuel} л\n"
            text += f"   ⏱️ Время: {duration} мин\n\n"
        else:
            req_power = config.get("min_power", 1)
            text += f"🔒 **{config.get('name', loc_id)}**\n"
            text += f"   Треб. мощность: {req_power}\n\n"
    
    text += "Выберите локацию в меню ниже"
    
    await update.effective_message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=location_menu_keyboard(profile["locations"])
    )

@require_user
@rate_limit(300)  # 5 minutes cooldown
@log_command
async def mine_crabs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mine crabs at selected location"""
    user = update.effective_user
    message = update.effective_message
    
    args = context.args
    if not args:
        await message.reply_text(
            "❌ Использование: .добыча <локация>\n"
            "Локации: beach, forest, mountains, desert, ocean, volcano, arctic, space"
        )
        return
    
    location_id = args[0].lower()
    
    profile = await db.get_casino_profile(user.id)
    if not profile:
        profile = await db.create_casino_profile(user.id)
    
    # Check if location exists
    if location_id not in CASINO_LOCATIONS:
        await message.reply_text("❌ Неверная локация")
        return
    
    # Check if location is unlocked
    if location_id not in profile["locations"] or not profile["locations"][location_id].get("unlocked"):
        await message.reply_text("❌ Локация не разблокирована")
        return
    
    location = profile["locations"][location_id]
    config = CASINO_LOCATIONS[location_id]
    
    # Check if already on expedition
    if profile.get("active_expedition"):
        await message.reply_text("❌ Вы уже в экспедиции. Дождитесь завершения")
        return
    
    # Check vehicle power
    required_power = config["min_power"] * location["level"]
    if profile["vehicle"]["power"] < required_power:
        await message.reply_text(
            f"❌ Недостаточно мощности. Нужно: {required_power}, у вас: {profile['vehicle']['power']}"
        )
        return
    
    # Check fuel
    fuel_needed = config["fuel_cost"] * location["level"]
    if profile["vehicle"]["fuel"] < fuel_needed:
        await message.reply_text(f"❌ Недостаточно топлива. Нужно: {fuel_needed} л")
        return
    
    # Check storage
    storage_needed = 1  # Each trip uses 1 storage slot
    if profile["vehicle"]["storage_used"] + storage_needed > profile["vehicle"]["max_storage"]:
        await message.reply_text("❌ Недостаточно места в хранилище")
        return
    
    # Start expedition
    profile["vehicle"]["fuel"] -= fuel_needed
    profile["vehicle"]["storage_used"] += storage_needed
    profile["active_expedition"] = {
        "location": location_id,
        "started_at": datetime.utcnow(),
        "duration": config["duration"]
    }
    
    await db.update_vehicle(user.id, 
        fuel=profile["vehicle"]["fuel"],
        storage_used=profile["vehicle"]["storage_used"]
    )
    
    await db.db.casino.update_one(
        {"user_id": user.id},
        {"$set": {"active_expedition": profile["active_expedition"]}}
    )
    
    # Schedule completion
    asyncio.create_task(complete_expedition_after_delay(
        context, user.id, config["duration"] * 60
    ))
    
    await message.reply_text(
        f"🚗 Экспедиция в {config['name']} началась!\n"
        f"⏱️ Длительность: {config['duration']} минут\n"
        f"⛽ Потрачено топлива: {fuel_needed} л\n"
        f"📦 Занято места: 1\n\n"
        f"Я вернусь, когда экспедиция завершится!"
    )

async def complete_expedition_after_delay(context: ContextTypes.DEFAULT_TYPE, user_id: int, delay_seconds: int):
    """Complete expedition after delay"""
    await asyncio.sleep(delay_seconds)
    
    profile = await db.get_casino_profile(user_id)
    if not profile or not profile.get("active_expedition"):
        return
    
    expedition = profile["active_expedition"]
    location_id = expedition["location"]
    location = profile["locations"][location_id]
    config = CASINO_LOCATIONS[location_id]
    
    # Calculate crabs mined
    base_crabs = random.randint(
        config["max_crabs_per_trip"] // 2,
        config["max_crabs_per_trip"]
    ) * location["level"]
    
    # Apply luck
    if random.random() < 0.1:  # 10% chance for bonus
        base_crabs = int(base_crabs * 1.5)
    
    # Add to balance
    await db.add_crabs(user_id, base_crabs, f"expedition_{location_id}")
    
    # Clear expedition
    await db.db.casino.update_one(
        {"user_id": user_id},
        {
            "$set": {"active_expedition": None},
            "$inc": {f"locations.{location_id}.expeditions": 1}
        }
    )
    
    # Free storage
    await db.db.casino.update_one(
        {"user_id": user_id},
        {"$inc": {"vehicle.storage_used": -1}}
    )
    
    # Notify user
    try:
        await context.bot.send_message(
            user_id,
            f"✅ **Экспедиция завершена!**\n\n"
            f"📍 Локация: {config['name']}\n"
            f"🦀 Добыто: {format_number(base_craps)} крабиков\n\n"
            f"Используйте .казино для продолжения"
        )
    except:
        pass

@require_user
@log_command
async def roulette(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Play roulette"""
    user = update.effective_user
    message = update.effective_message
    
    args = context.args
    if len(args) < 2:
        await message.reply_text(
            "❌ Использование: .рулетка <ставка> <число/цвет>\n"
            "Пример: .рулетка 1000 красное\n"
            "Цвета: красное, чёрное, зеро\n"
            "Числа: 0-36"
        )
        return
    
    try:
        bet = int(args[0])
    except:
        await message.reply_text("❌ Ставка должна быть числом")
        return
    
    choice = args[1].lower()
    
    profile = await db.get_casino_profile(user.id)
    if not profile:
        profile = await db.create_casino_profile(user.id)
    
    if profile["crabs"] < bet:
        await message.reply_text(f"❌ Недостаточно крабиков. Баланс: {format_number(profile['crabs'])}")
        return
    
    # Spin roulette
    number = random.randint(0, 36)
    
    # Determine color
    if number == 0:
        color = "зеро"
    elif number in [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]:
        color = "красное"
    else:
        color = "чёрное"
    
    # Check win
    win = False
    multiplier = 0
    
    if choice == "зеро" and number == 0:
        win = True
        multiplier = 36
    elif choice in ["красное", "чёрное"] and choice == color:
        win = True
        multiplier = 2
    elif choice.isdigit() and int(choice) == number:
        win = True
        multiplier = 36
    
    if win:
        winnings = bet * multiplier
        await db.add_crabs(user.id, winnings, "roulette_win")
        
        text = (
            f"🎲 **Рулетка**\n\n"
            f"Шар остановился на {number} ({color})\n"
            f"Ваш выбор: {choice}\n\n"
            f"✅ **ВЫ ВЫИГРАЛИ!**\n"
            f"💰 Выигрыш: {format_number(winnings)} 🦀\n"
            f"💸 Чистая прибыль: {format_number(winnings - bet)} 🦀"
        )
    else:
        await db.remove_crabs(user.id, bet, "roulette_loss")
        
        text = (
            f"🎲 **Рулетка**\n\n"
            f"Шар остановился на {number} ({color})\n"
            f"Ваш выбор: {choice}\n\n"
            f"❌ **ВЫ ПРОИГРАЛИ**\n"
            f"Потеряно: {format_number(bet)} 🦀"
        )
    
    await message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

@require_user
@log_command
async def dynamite_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Play Dynamite game"""
    user = update.effective_user
    message = update.effective_message
    
    args = context.args
    if len(args) < 1:
        await message.reply_text(
            "❌ Использование: .динамит <ставка>\n"
            "Пример: .динамит 1000"
        )
        return
    
    try:
        bet = int(args[0])
    except:
        await message.reply_text("❌ Ставка должна быть числом")
        return
    
    profile = await db.get_casino_profile(user.id)
    if not profile:
        profile = await db.create_casino_profile(user.id)
    
    if profile["crabs"] < bet:
        await message.reply_text(f"❌ Недостаточно крабиков. Баланс: {format_number(profile['crabs'])}")
        return
    
    # Game setup
    grid = [
        ["💣", "💎", "💎"],
        ["💎", "💣", "💎"],
        ["💎", "💎", "👑"]
    ]
    
    # Shuffle grid
    flat = [cell for row in grid for cell in row]
    random.shuffle(flat)
    grid = [flat[i:i+3] for i in range(0, 9, 3)]
    
    # Display grid
    text = "💣 **Динамит** 💣\n\n"
    for row in grid:
        text += "".join(row) + "\n"
    
    # Find queen position
    queen_pos = None
    for i in range(3):
        for j in range(3):
            if grid[i][j] == "👑":
                queen_pos = (i, j)
                break
    
    # Randomly select player's choice
    player_pos = (random.randint(0, 2), random.randint(0, 2))
    
    text += f"\nВы выбрали позицию: {player_pos}\n\n"
    
    # Check result
    if player_pos == queen_pos:
        # Win - get queen
        winnings = bet * 5
        await db.add_crabs(user.id, winnings, "dynamite_win")
        text += f"✅ **КОРОЛЕВА!**\nВы выиграли {format_number(winnings)} 🦀"
    elif grid[player_pos[0]][player_pos[1]] == "💣":
        # Lose - hit bomb
        await db.remove_crabs(user.id, bet, "dynamite_loss")
        text += f"💥 **БУМ!**\nВы проиграли {format_number(bet)} 🦀"
    else:
        # Normal gem - double or nothing
        text += f"💎 Вы нашли самоцвет!\nХотите продолжить?"
        
        keyboard = [
            [
                InlineKeyboardButton("✅ Взять выигрыш", callback_data=f"dynamite_take_{bet}"),
                InlineKeyboardButton("🎲 Продолжить", callback_data=f"dynamite_continue_{bet}")
            ]
        ]
        
        await message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        return
    
    await message.reply_text(text)

@require_user
@log_command
async def biometry_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Play Biometry game"""
    user = update.effective_user
    message = update.effective_message
    
    # Simple memory game
    sequence = [random.randint(1, 9) for _ in range(5)]
    
    text = "🧬 **Биометрия**\n\n"
    text += "Запомните последовательность:\n"
    text += " ".join(str(x) for x in sequence)
    
    # Store in context
    context.user_data["biometry"] = {
        "sequence": sequence,
        "step": 0
    }
    
    await message.reply_text(text)
    
    # Wait 3 seconds
    await asyncio.sleep(3)
    
    # Clear message (can't edit other user's message, so send new)
    await message.reply_text(
        "🎯 Теперь повторите последовательность,\n"
        "отправляя числа по одному"
    )

@require_user
@log_command
async def top_players(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show top players by crabs"""
    # Get top 10 players by crabs
    cursor = db.db.casino.find().sort("crabs", -1).limit(10)
    top = await cursor.to_list(length=10)
    
    if not top:
        await update.effective_message.reply_text("📊 Топ игроков пока пуст")
        return
    
    text = "🏆 **Топ игроков по крабикам**\n\n"
    
    for i, player in enumerate(top, 1):
        user_id = player["user_id"]
        try:
            user = await context.bot.get_chat(user_id)
            name = user.first_name
        except:
            name = f"User{user_id}"
        
        crabs = player["crabs"]
        expeditions = player.get("stats", {}).get("total_expeditions", 0)
        
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        text += f"{medal} {name} - {format_number(crabs)} 🦀 (эксп: {expeditions})\n"
    
    await update.effective_message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle casino callbacks"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "casino_menu":
        await casino_menu(update, context)
    
    elif data == "casino_vehicle":
        await vehicle_menu(update, context)
    
    elif data == "casino_locations":
        await location_menu(update, context)
    
    elif data.startswith("vehicle_select_"):
        vehicle_id = data.split("_")[2]
        
        user = update.effective_user
        profile = await db.get_casino_profile(user.id)
        
        if not profile:
            return
        
        current = profile["vehicle"]["type"]
        if vehicle_id == current:
            await query.edit_message_text("✅ Это ваш текущий транспорт")
            return
        
        vehicle_config = VEHICLE_TYPES[vehicle_id]
        price = vehicle_config.get("price", 0)
        
        if profile["crabs"] < price:
            await query.edit_message_text(f"❌ Недостаточно крабиков. Нужно: {format_number(price)}")
            return
        
        # Buy new vehicle
        await db.remove_crabs(user.id, price, f"buy_vehicle_{vehicle_id}")
        
        # Sell old vehicle (50% refund)
        old_config = VEHICLE_TYPES[current]
        refund = int(old_config.get("price", 0) * 0.5)
        if refund > 0:
            await db.add_crabs(user.id, refund, "sell_vehicle")
        
        # Update vehicle
        new_vehicle = {
            "type": vehicle_id,
            "level": 1,
            "power": vehicle_config["power"],
            "fuel": vehicle_config["fuel_capacity"],
            "max_fuel": vehicle_config["fuel_capacity"],
            "condition": 100,
            "storage": vehicle_config["storage"],
            "storage_used": 0
        }
        
        await db.db.casino.update_one(
            {"user_id": user.id},
            {"$set": {"vehicle": new_vehicle}}
        )
        
        await query.edit_message_text(
            f"✅ Транспорт обновлён!\n"
            f"Приобретён: {vehicle_config['name']}\n"
            f"💰 Потрачено: {format_number(price - refund)} 🦀"
        )
    
    elif data == "vehicle_refuel":
        user = update.effective_user
        profile = await db.get_casino_profile(user.id)
        
        if not profile:
            return
        
        vehicle = profile["vehicle"]
        fuel_needed = vehicle["max_fuel"] - vehicle["fuel"]
        cost = fuel_needed * vehicle["fuel_cost_per_liter"]
        
        if profile["crabs"] < cost:
            await query.edit_message_text(f"❌ Недостаточно крабиков. Нужно: {format_number(cost)}")
            return
        
        await db.remove_crabs(user.id, cost, "refuel")
        await db.update_vehicle(user.id, fuel=vehicle["max_fuel"])
        
        await query.edit_message_text(
            f"⛽ Заправлено {fuel_needed} л\n"
            f"💰 Потрачено: {format_number(cost)} 🦀"
        )
    
    elif data == "vehicle_repair":
        user = update.effective_user
        profile = await db.get_casino_profile(user.id)
        
        if not profile:
            return
        
        vehicle = profile["vehicle"]
        cost = vehicle["repair_cost"]
        
        if cost == 0:
            await query.edit_message_text("✅ Транспорт в идеальном состоянии")
            return
        
        if profile["crabs"] < cost:
            await query.edit_message_text(f"❌ Недостаточно крабиков. Нужно: {format_number(cost)}")
            return
        
        await db.remove_crabs(user.id, cost, "repair")
        await db.update_vehicle(user.id, condition=100)
        
        await query.edit_message_text(
            f"🔧 Транспорт полностью отремонтирован!\n"
            f"💰 Потрачено: {format_number(cost)} 🦀"
        )
    
    elif data.startswith("location_"):
        location_id = data.split("_")[1]
        
        user = update.effective_user
        profile = await db.get_casino_profile(user.id)
        
        if not profile:
            return
        
        location = profile["locations"].get(location_id)
        
        if not location:
            # Unlock new location
            config = CASINO_LOCATIONS[location_id]
            price = config.get("unlock_price", 10000)
            
            if profile["crabs"] < price:
                await query.edit_message_text(f"❌ Недостаточно крабиков. Нужно: {format_number(price)}")
                return
            
            await db.remove_crabs(user.id, price, f"unlock_{location_id}")
            
            await db.db.casino.update_one(
                {"user_id": user.id},
                {"$set": {f"locations.{location_id}": {
                    "unlocked": True,
                    "level": 1,
                    "expeditions": 0,
                    "total_crabs_mined": 0
                }}}
            )
            
            await query.edit_message_text(f"✅ Локация {config['name']} разблокирована!")
        else:
            # Show location details
            config = CASINO_LOCATIONS[location_id]
            text = (
                f"📍 **{config['name']}**\n\n"
                f"Уровень: {location['level']}\n"
                f"Экспедиций: {location['expeditions']}\n"
                f"Всего добыто: {format_number(location['total_crabs_mined'])} 🦀\n\n"
                
                f"**Текущие показатели:**\n"
                f"Треб. мощность: {config['min_power'] * location['level']}\n"
                f"Макс. крабиков: {format_number(config['max_crabs_per_trip'] * location['level'])}\n"
                f"Топливо: {config['fuel_cost'] * location['level']} л\n"
                f"Время: {config['duration']} мин\n\n"
                
                f"Команда: .добыча {location_id}"
            )
            
            await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN)
    
    elif data.startswith("dynamite_take_"):
        bet = int(data.split("_")[2])
        
        user = update.effective_user
        
        # Take winnings (double)
        winnings = bet * 2
        await db.add_crabs(user.id, winnings, "dynamite_win")
        
        await query.edit_message_text(
            f"✅ Вы взяли выигрыш!\n"
            f"💰 Выигрыш: {format_number(winnings)} 🦀"
        )
    
    elif data.startswith("dynamite_continue_"):
        bet = int(data.split("_")[2])
        
        # Continue game - 50% chance to win/lose
        if random.random() < 0.5:
            # Win
            winnings = bet * 4
            await db.add_crabs(update.effective_user.id, winnings, "dynamite_win")
            await query.edit_message_text(
                f"✅ **УСПЕХ!**\n"
                f"💰 Выигрыш: {format_number(winnings)} 🦀"
            )
        else:
            # Lose
            await db.remove_crabs(update.effective_user.id, bet, "dynamite_loss")
            await query.edit_message_text(
                f"💥 **ВЗРЫВ!**\n"
                f"Вы проиграли {format_number(bet)} 🦀"
            )