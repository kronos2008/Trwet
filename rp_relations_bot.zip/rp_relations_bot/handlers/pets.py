import logging
import random
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from database import db
from utils.constants import PET_RARITIES, PET_TYPES, PET_HOUSES, PET_ROOMS
from utils.decorators import require_user, rate_limit, log_command, premium_required
from utils.helpers import format_number, format_duration, is_premium
from keyboards.inline import pets_menu_keyboard, egg_shop_keyboard

logger = logging.getLogger(__name__)

@require_user
@log_command
async def pets_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Main pets menu"""
    user = update.effective_user
    message = update.effective_message
    
    # Get user's pets
    pets = await db.get_user_pets(user.id)
    
    if not pets:
        text = (
            "🐾 **Питомцы**\n\n"
            "У вас пока нет питомцев.\n"
            "Купите яйцо и вырастите своего питомца!"
        )
        keyboard = [
            [InlineKeyboardButton("🥚 Купить яйцо", callback_data="pet_buy_egg")],
            [InlineKeyboardButton("◀️ Назад", callback_data="menu_main")]
        ]
    else:
        text = "🐾 **Ваши питомцы**\n\n"
        
        for pet in pets[:5]:
            name = pet["name"]
            pet_type = pet["pet_type"]
            level = pet["level"]
            mood = pet["mood"]
            hp = pet["hp"]
            
            mood_emoji = "😊" if mood > 70 else "😐" if mood > 40 else "😢"
            hp_emoji = "❤️" if hp > 70 else "💛" if hp > 40 else "💔"
            
            text += f"{mood_emoji} **{name}** ({pet_type})\n"
            text += f"  Уровень: {level} | {hp_emoji} {hp}% | Настроение: {mood}%\n\n"
    
    await message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=pets_menu_keyboard(pets) if pets else InlineKeyboardMarkup(keyboard)
    )

@require_user
@log_command
async def buy_egg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Buy an egg"""
    user = update.effective_user
    message = update.effective_message
    
    # Show egg shop
    text = (
        "🥚 **Магазин яиц**\n\n"
        "**Обычное яйцо** - 10 000 искр\n"
        "• 70% обычный\n"
        "• 20% необычный\n"
        "• 8% редкий\n"
        "• 1.5% эпический\n"
        "• 0.5% легендарный\n\n"
        
        "**✨ Золотое яйцо** - 50 000 искр\n"
        "• 2% обычный\n"
        "• 13% необычный\n"
        "• 45% редкий\n"
        "• 38% эпический\n"
        "• 2% легендарный\n\n"
        
        "**🌟 Премиум яйцо** - 25 ⭐\n"
        "• 5% необычный\n"
        "• 25% редкий\n"
        "• 60% эпический\n"
        "• 10% легендарный\n\n"
        
        "Выберите яйцо:"
    )
    
    await message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=egg_shop_keyboard()
    )

@require_user
@log_command
async def feed_pet(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Feed a pet"""
    user = update.effective_user
    message = update.effective_message
    
    args = context.args
    if not args:
        await message.reply_text(
            "❌ Использование: .покормить <id питомца>\n"
            "ID можно посмотреть в .питомец"
        )
        return
    
    pet_id = args[0]
    
    # Get pet
    pet = await db.get_pet(user.id, pet_id)
    if not pet:
        await message.reply_text("❌ Питомец не найден")
        return
    
    # Check if already fed recently
    last_fed = pet.get("last_fed")
    if last_fed and (datetime.utcnow() - last_fed).total_seconds() < 3600:  # 1 hour cooldown
        remaining = 3600 - (datetime.utcnow() - last_fed).total_seconds()
        await message.reply_text(
            f"⏳ Питомца можно кормить через {format_duration(int(remaining))}"
        )
        return
    
    # Calculate cost
    food_cost = pet["food_consumption"] * 5
    water_cost = pet["water_consumption"] * 3
    total_cost = food_cost + water_cost
    
    # Get casino profile for payment
    casino = await db.get_casino_profile(user.id)
    if not casino or casino["crabs"] < total_cost:
        await message.reply_text(f"❌ Недостаточно крабиков. Нужно: {format_number(total_cost)}")
        return
    
    # Pay
    await db.remove_crabs(user.id, total_cost, f"feed_pet_{pet_id}")
    
    # Update pet
    await db.db.pets.update_one(
        {"user_id": user.id, "pet_id": pet_id},
        {
            "$set": {
                "last_fed": datetime.utcnow(),
                "hp": min(100, pet["hp"] + 20)
            }
        }
    )
    
    await message.reply_text(
        f"🍖 {pet['name']} накормлен(а)!\n"
        f"💰 Потрачено: {format_number(total_cost)} крабиков\n"
        f"❤️ Здоровье: +20%"
    )

@require_user
@log_command
async def play_with_pet(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Play with a pet"""
    user = update.effective_user
    message = update.effective_message
    
    args = context.args
    if not args:
        await message.reply_text(
            "❌ Использование: .поиграть <id питомца>"
        )
        return
    
    pet_id = args[0]
    
    # Get pet
    pet = await db.get_pet(user.id, pet_id)
    if not pet:
        await message.reply_text("❌ Питомец не найден")
        return
    
    # Check cooldown
    last_played = pet.get("last_played")
    if last_played and (datetime.utcnow() - last_played).total_seconds() < 1800:  # 30 min cooldown
        remaining = 1800 - (datetime.utcnow() - last_played).total_seconds()
        await message.reply_text(
            f"⏳ С питомцем можно играть через {format_duration(int(remaining))}"
        )
        return
    
    # Calculate mood increase based on personality
    personality = pet.get("personality", 0)
    mood_increase = 20
    if personality > 0:
        mood_increase = int(mood_increase * (1 + personality / 100))
    
    exp_gain = 15
    
    # Update pet
    new_mood = await db.update_pet_mood(user.id, pet_id, mood_increase)
    exp_result = await db.add_pet_exp(user.id, pet_id, exp_gain)
    
    await db.db.pets.update_one(
        {"user_id": user.id, "pet_id": pet_id},
        {"$set": {"last_played": datetime.utcnow()}}
    )
    
    await message.reply_text(
        f"🎾 Вы поиграли с {pet['name']}!\n"
        f"😊 Настроение: +{mood_increase} (теперь {new_mood}%)\n"
        f"✨ Опыт: +{exp_gain}"
    )

@require_user
@log_command
async def pet_house_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Pet house management"""
    user = update.effective_user
    message = update.effective_message
    
    args = context.args
    if not args:
        await message.reply_text(
            "❌ Использование: .домик <id питомца>"
        )
        return
    
    pet_id = args[0]
    
    # Get pet
    pet = await db.get_pet(user.id, pet_id)
    if not pet:
        await message.reply_text("❌ Питомец не найден")
        return
    
    house = pet.get("house")
    
    if not house:
        # Show available houses
        text = f"🏠 **Домик для {pet['name']}**\n\n"
        
        for house_id, config in PET_HOUSES.items():
            text += f"**{config['name']}**\n"
            text += f"💰 Цена: {format_number(config['price'])} искр\n"
            text += f"🚪 Слотов: {config['slots']}\n"
            text += f"😊 Бонус настроения: +{config['mood_bonus']}\n"
            text += f"✨ Бонус опыта: +{config['exp_bonus']}%\n\n"
        
        text += "Купить домик: .домик купить <тип>"
    else:
        house_config = PET_HOUSES.get(house["house_type"], PET_HOUSES["картонная_коробка"])
        
        text = f"🏠 **Домик {pet['name']}**\n\n"
        text += f"Тип: {house_config['name']}\n"
        text += f"Комнат: {len(house.get('rooms', []))}/{house_config['slots']}\n\n"
        
        text += "**Бонусы:**\n"
        text += f"• Настроение: +{house_config['mood_bonus']}\n"
        text += f"• Опыт: +{house_config['exp_bonus']}%\n"
        
        if house_config['skill_bonus']:
            text += f"• Навыки: +{house_config['skill_bonus']}%\n"
        if house_config['decay_reduction']:
            text += f"• Спад настроения: -{house_config['decay_reduction']}%\n"
        
        if house.get("rooms"):
            text += "\n**Установленные комнаты:**\n"
            for room in house["rooms"]:
                room_config = PET_ROOMS.get(room, {})
                text += f"• {room_config.get('name', room)}\n"
    
    await message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

@require_user
@log_command
async def hatch_egg(update: Update, context: ContextTypes.DEFAULT_TYPE, egg_type: str):
    """Hatch an egg"""
    user = update.effective_user
    
    # Check if user has space for pet
    pets = await db.get_user_pets(user.id)
    if len(pets) >= 5:
        await update.effective_message.reply_text(
            "❌ У вас уже максимальное количество питомцев (5)"
        )
        return
    
    # Determine rarity based on egg type
    if egg_type == "normal":
        rarities = ["обычный"] * 70 + ["необычный"] * 20 + ["редкий"] * 8 + ["эпический"] * 1.5 + ["легендарный"] * 0.5
        # Convert to integer weights
        rarities = ["обычный"] * 70 + ["необычный"] * 20 + ["редкий"] * 8 + ["эпический"] * 1 + ["легендарный"] * 1
    
    elif egg_type == "golden":
        rarities = ["обычный"] * 2 + ["необычный"] * 13 + ["редкий"] * 45 + ["эпический"] * 38 + ["легендарный"] * 2
    
    elif egg_type == "premium":
        rarities = ["необычный"] * 5 + ["редкий"] * 25 + ["эпический"] * 60 + ["легендарный"] * 10
    
    else:
        await update.effective_message.reply_text("❌ Неверный тип яйца")
        return
    
    # Select random rarity
    rarity = random.choice(rarities)
    
    # Select random pet type
    pet_type = random.choice(PET_TYPES)
    
    # Create pet
    pet = await db.create_pet(user.id, pet_type, rarity)
    
    # Get color
    color = PET_RARITIES.get(rarity, {}).get("color", "⚪️")
    
    await update.effective_message.reply_text(
        f"🥚 **Яйцо вскрылось!**\n\n"
        f"{color} Из яйца вылупился **{pet['name']}**!\n"
        f"Тип: {pet_type}\n"
        f"Редкость: {rarity.upper()}\n"
        f"Характер: {pet['personality']} ({'😊' if pet['personality'] > 0 else '😐' if pet['personality'] == 0 else '😢'})\n\n"
        f"ID: `{pet['pet_id']}`\n\n"
        f"Используйте .питомец для просмотра"
    )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle pet callbacks"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "pet_menu":
        await pets_menu(update, context)
    
    elif data == "pet_buy_egg":
        await buy_egg(update, context)
    
    elif data == "egg_buy_normal":
        # Check if user can afford
        user = update.effective_user
        casino = await db.get_casino_profile(user.id)
        
        if not casino or casino["crabs"] < 10000:
            await query.edit_message_text("❌ Недостаточно крабиков. Нужно 10 000")
            return
        
        await db.remove_crabs(user.id, 10000, "buy_egg_normal")
        await hatch_egg(update, context, "normal")
    
    elif data == "egg_buy_golden":
        user = update.effective_user
        casino = await db.get_casino_profile(user.id)
        
        if not casino or casino["crabs"] < 50000:
            await query.edit_message_text("❌ Недостаточно крабиков. Нужно 50 000")
            return
        
        await db.remove_crabs(user.id, 50000, "buy_egg_golden")
        await hatch_egg(update, context, "golden")
    
    elif data == "egg_buy_premium":
        user = update.effective_user
        
        # Check if user has stars
        # Here would be stars payment check
        
        await hatch_egg(update, context, "premium")
    
    elif data.startswith("pet_select_"):
        pet_id = data.split("_")[2]
        
        # Show pet details
        user = update.effective_user
        pet = await db.get_pet(user.id, pet_id)
        
        if not pet:
            await query.edit_message_text("❌ Питомец не найден")
            return
        
        # Calculate stats
        mood = pet["mood"]
        hp = pet["hp"]
        level = pet["level"]
        exp = pet["exp"]
        exp_next = pet["exp_for_next_level"] if level < pet["max_level"] else "MAX"
        exp_progress = pet["exp_progress"]
        
        progress_bar = "█" * (exp_progress // 10) + "░" * (10 - (exp_progress // 10))
        
        mood_emoji = "😊" if mood > 70 else "😐" if mood > 40 else "😢"
        hp_emoji = "❤️" if hp > 70 else "💛" if hp > 40 else "💔"
        
        # Personality description
        if pet["personality"] <= -7:
            personality_desc = "😔 Меланхоличный"
        elif pet["personality"] <= -3:
            personality_desc = "😞 Грустный"
        elif pet["personality"] <= 2:
            personality_desc = "😐 Спокойный"
        elif pet["personality"] <= 6:
            personality_desc = "😊 Жизнерадостный"
        else:
            personality_desc = "🤩 Восторженный"
        
        text = (
            f"**{pet['name']}** {PET_RARITIES[pet['rarity']]['color']}\n\n"
            
            f"**Основное**\n"
            f"Тип: {pet['pet_type']}\n"
            f"Редкость: {pet['rarity'].upper()}\n"
            f"Характер: {personality_desc} ({pet['personality']})\n\n"
            
            f"**Состояние**\n"
            f"{hp_emoji} Здоровье: {hp}%\n"
            f"{mood_emoji} Настроение: {mood}%\n\n"
            
            f"**Прогресс**\n"
            f"Уровень: {level}/{pet['max_level']}\n"
            f"Опыт: {exp}/{exp_next}\n"
            f"{progress_bar} {exp_progress}%\n\n"
            
            f"**Потребление**\n"
            f"🍖 Еда: {pet['food_consumption']} ед/день\n"
            f"💧 Вода: {pet['water_consumption']} ед/день\n"
            f"💰 Стоимость: {pet['food_consumption']*5 + pet['water_consumption']*3} краб/день\n\n"
            
            f"**Навыки**\n"
        )
        
        for skill in pet.get("skills", []):
            emoji = "✅" if skill["type"] == "positive" else "❌"
            text += f"{emoji} {skill['name']} (ур.{skill['level']})\n"
        
        # Actions
        keyboard = [
            [
                InlineKeyboardButton("🎾 Играть", callback_data=f"pet_play_{pet_id}"),
                InlineKeyboardButton("🍖 Кормить", callback_data=f"pet_feed_{pet_id}")
            ],
            [
                InlineKeyboardButton("🏠 Домик", callback_data=f"pet_house_{pet_id}"),
                InlineKeyboardButton("✏️ Переименовать", callback_data=f"pet_rename_{pet_id}")
            ],
            [InlineKeyboardButton("◀️ Назад", callback_data="pet_menu")]
        ]
        
        await query.edit_message_text(
            text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )