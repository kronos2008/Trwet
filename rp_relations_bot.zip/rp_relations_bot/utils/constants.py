# utils/constants.py

# Standard RP commands with emojis and templates
STANDARD_RP_COMMANDS = {
    "поцеловать": {"emoji": "😘", "template": "{user} поцеловал(а) {target}"},
    "обнять": {"emoji": "🤗", "template": "{user} обнял(а) {target}"},
    "засосать": {"emoji": "💋", "template": "{user} засосал(а) {target}"},
    "ударить": {"emoji": "👊", "template": "{user} ударил(а) {target}"},
    "изнасиловать": {"emoji": "👉👌", "template": "{user} жёстко изнасиловал(а) в сладкие дырочки {target}"},
    "отсосать": {"emoji": "😗", "template": "{user} отсосал(а) у {target}"},
    "отлизать": {"emoji": "👅", "template": "{user} отлизал(а) у {target}"},
    "кусь": {"emoji": "💢", "template": "{user} укусил(а) {target}"},
    "хрусь": {"emoji": "🦴", "template": "{user} похрустел(а) костяшками {target}"},
    "пнуть": {"emoji": "👞", "template": "{user} пнул(а) поджопника {target}"},
    "пощекотать": {"emoji": "🙌", "template": "{user} пощекотал(а) {target}"},
    "залезть": {"emoji": "👙", "template": "{user} залез(ла) в трусики к {target}"},
    "сесть": {"emoji": "😈", "template": "{user} сел(а) на лицо {target}"},
    "лап": {"emoji": "🫴", "template": "{user} полапал(а) {target} за интимные места"},
    "шлеп": {"emoji": "✋", "template": "{user} отшлепал(а) {target} за попку"},
    "щелбан": {"emoji": "👌", "template": "{user} вдарил(а) смачного щелбана в лоб {target}"},
    "уебать": {"emoji": "💥", "template": "{user} уебал(а) {target}"},
    "вмазать": {"emoji": "🥊", "template": "{user} вмазал(а) {target}"},
    "втащить": {"emoji": "🥊", "template": "{user} втащил(а) {target}"},
    "заехать": {"emoji": "👊", "template": "{user} заехал(а) по челюсти {target}"},
    "пощечина": {"emoji": "🖐️", "template": "{user} дал(а) пощёчину {target}"},
    "толкнуть": {"emoji": "🫳", "template": "{user} толкнул(а) {target}"},
    "швырнуть": {"emoji": "💫", "template": "{user} швырнул(а) {target}"},
    "подзатыльник": {"emoji": "👋", "template": "{user} зарядил(а) подзатыльник {target}"},
    "флиртовать": {"emoji": "😏", "template": "{user} флиртует с {target}"},
    "подмигнуть": {"emoji": "😉", "template": "{user} подмигнул(а) {target}"},
    "трахнуть": {"emoji": "🍆🍑", "template": "{user} жёстко трахнул(а) {target} во все дырочки"},
    "лизнуть": {"emoji": "👅", "template": "{user} лизнул(а) {target} в интимное место"},
    "прижать": {"emoji": "🤌", "template": "{user} прижал(а) {target} к стене и страстно поцеловал(а)"},
    "связать": {"emoji": "🪢", "template": "{user} связал(а) {target} и начал(а) доминировать"},
    "раздеть": {"emoji": "👗", "template": "{user} страстно сорвал(а) одежду с {target}"},
    "выебать": {"emoji": "🔞", "template": "{user} выебал(а) {target} до полного изнеможения"},
    "погладить": {"emoji": "🫳", "template": "{user} нежно погладил(а) {target} по головке"},
    "насадить": {"emoji": "🕳️", "template": "{user} насадил(а) {target} на свой(ю) кол"},
    "отыметь": {"emoji": "😈💦", "template": "{user} отымел(а) {target} как последнюю сучку"},
    "вылизать": {"emoji": "👅💦", "template": "{user} вылизал(а) {target} до последней капли"},
    "пожать руку": {"emoji": "🤝", "template": "{user} крепко пожал(а) руку {target}"},
    "похлопать": {"emoji": "👋", "template": "{user} дружески похлопал(а) {target} по плечу"},
    "дать пять": {"emoji": "🖐️", "template": "{user} дал(а) пять {target}"},
    "поклониться": {"emoji": "🙇", "template": "{user} уважительно поклонился(а) {target}"},
    "помахать": {"emoji": "👋", "template": "{user} весело помахал(а) {target}"},
    "показать язык": {"emoji": "😛", "template": "{user} показал(а) язык {target}"},
    "подбодрить": {"emoji": "👍", "template": "{user} подбодрил(а) {target} большим пальцем"},
    "аплодировать": {"emoji": "👏", "template": "{user} громко поаплодировал(а) {target}"},
    "обнять дружески": {"emoji": "🫂", "template": "{user} крепко обнял(а) {target} по-дружески"},
    "успокоить": {"emoji": "🤲", "template": "{user} нежно успокоил(а) {target}"},
    "погладить по голове": {"emoji": "🤗", "template": "{user} ласково погладил(а) {target} по голове"},
    "кивнуть": {"emoji": "👋", "template": "{user} одобрительно кивнул(а) {target}"}
}

# Relation action cooldowns and rewards
RELATION_ACTIONS = {
    # Basic actions (level 1+)
    "обнять": {"cooldown": 300, "sparks": 5, "min_level": 1},
    "поцеловать": {"cooldown": 600, "sparks": 10, "min_level": 1},
    "комплимент": {"cooldown": 900, "sparks": 15, "min_level": 1},
    
    # Level 5+ actions
    "романтика": {"cooldown": 3600, "sparks": 50, "min_level": 5},
    "свидание": {"cooldown": 7200, "sparks": 100, "min_level": 5},
    
    # Level 10+ actions
    "признание": {"cooldown": 14400, "sparks": 200, "min_level": 10},
    "подарок": {"cooldown": 28800, "sparks": 400, "min_level": 10},
    
    # Level 15+ actions
    "путешествие": {"cooldown": 43200, "sparks": 800, "min_level": 15},
    "сюрприз": {"cooldown": 86400, "sparks": 1500, "min_level": 15},
    
    # Level 20+ actions
    "душевный_разговор": {"cooldown": 108000, "sparks": 2500, "min_level": 20},
    "мечты": {"cooldown": 172800, "sparks": 4000, "min_level": 20},
    
    # Level 25+ actions
    "обещание": {"cooldown": 259200, "sparks": 6000, "min_level": 25},
    "ритуал": {"cooldown": 345600, "sparks": 9000, "min_level": 25},
    
    # Level 30 actions
    "клятва": {"cooldown": 432000, "sparks": 15000, "min_level": 30},
    
    # Premium actions
    "аура_эмпатии": {"cooldown": 86400, "sparks": 5000, "premium": True, "min_level": 15},
    "нейронная_связь": {"cooldown": 172800, "sparks": 10000, "premium": True, "min_level": 20},
    "параллельный_мир": {"cooldown": 259200, "sparks": 20000, "premium": True, "min_level": 25},
    "днк_любовь": {"cooldown": 432000, "sparks": 50000, "premium": True, "min_level": 30},
    "квантовое_слияние": {"cooldown": 604800, "sparks": 100000, "premium": True, "min_level": 30},
    
    # Intimate actions
    "секс": {"cooldown": 7200, "sparks": 200, "min_level": 5, "pregnancy_chance": 15},
    "кекс": {"cooldown": 7200, "sparks": 200, "min_level": 5, "pregnancy_chance": 15},
    "пошалить": {"cooldown": 7200, "sparks": 200, "min_level": 5, "pregnancy_chance": 15},
    "минет": {"cooldown": 3600, "sparks": 150, "min_level": 5, "gender_req": "male"},
    "куни": {"cooldown": 3600, "sparks": 150, "min_level": 5, "gender_req": "female"}
}

# House types
HOUSE_TYPES = {
    "хижина": {
        "price": 50000,
        "build_time": 48,  # hours
        "rooms": 3,
        "maintenance": 0.0006,  # 0.06% of price per week
        "prestige": 5,
        "description": "🏚️ Маленькая уютная хижина для начинающих"
    },
    "загородный_дом": {
        "price": 150000,
        "build_time": 96,
        "rooms": 5,
        "maintenance": 0.001,
        "prestige": 15,
        "description": "🏡 Просторный дом за городом"
    },
    "коттедж": {
        "price": 300000,
        "build_time": 144,
        "rooms": 7,
        "maintenance": 0.0015,
        "prestige": 30,
        "description": "🏘️ Современный коттедж"
    },
    "особняк": {
        "price": 600000,
        "build_time": 192,
        "rooms": 10,
        "maintenance": 0.002,
        "prestige": 50,
        "description": "🏰 Роскошный особняк"
    },
    "поместье": {
        "price": 1000000,
        "build_time": 240,
        "rooms": 15,
        "maintenance": 0.0025,
        "prestige": 80,
        "description": "🏛️ Величественное поместье"
    },
    "замок": {
        "price": 2000000,
        "build_time": 288,
        "rooms": 20,
        "maintenance": 0.0035,
        "prestige": 150,
        "description": "🏯 Настоящий средневековый замок"
    },
    "премиум_вилла": {
        "price": 5000000,
        "build_time": 360,
        "rooms": 30,
        "maintenance": 0.005,
        "prestige": 300,
        "premium": True,
        "description": "✨ Эксклюзивная вилла для премиум отношений"
    }
}

# Room types
ROOM_TYPES = {
    # Жилые комнаты
    "спальня": {"levels": 4, "price_per_level": 5000, "prestige": 5, "actions": ["отдых", "романтика"]},
    "гостиная": {"levels": 4, "price_per_level": 6000, "prestige": 5, "actions": ["киномарафон", "вечеринка"]},
    "кухня": {"levels": 4, "price_per_level": 4000, "prestige": 3, "actions": ["готовка", "ужин"]},
    "столовая": {"levels": 3, "price_per_level": 3000, "prestige": 2, "actions": ["семейный_ужин"]},
    
    # Функциональные
    "ванная": {"levels": 3, "price_per_level": 5000, "prestige": 4, "actions": ["спа"]},
    "прачечная": {"levels": 2, "price_per_level": 2000, "prestige": 1, "actions": []},
    "кладовая": {"levels": 2, "price_per_level": 1500, "prestige": 1, "actions": []},
    "мастерская": {"levels": 3, "price_per_level": 4000, "prestige": 3, "actions": ["творчество"]},
    
    # Развлекательные
    "игровая": {"levels": 3, "price_per_level": 8000, "prestige": 8, "actions": ["игры"]},
    "кинотеатр": {"levels": 3, "price_per_level": 15000, "prestige": 15, "actions": ["киносеанс"]},
    "спортзал": {"levels": 3, "price_per_level": 10000, "prestige": 10, "actions": ["тренировка"]},
    "бассейн": {"levels": 2, "price_per_level": 20000, "prestige": 20, "actions": ["плавание"]},
    "библиотека": {"levels": 3, "price_per_level": 6000, "prestige": 6, "actions": ["чтение"]},
    "сауна": {"levels": 2, "price_per_level": 12000, "prestige": 12, "actions": ["парение"]},
    
    # Премиум
    "частный_клуб": {"levels": 2, "price_per_level": 30000, "prestige": 30, "premium": True, "actions": ["вечеринка"]},
    "винный_погреб": {"levels": 2, "price_per_level": 25000, "prestige": 25, "premium": True, "actions": ["дегустация"]},
    "кабинет": {"levels": 3, "price_per_level": 15000, "prestige": 15, "actions": ["работа"]}
}

# Pet rarities
PET_RARITIES = {
    "обычный": {
        "color": "⚪️",
        "max_level": 10,
        "skill_count": 1,
        "egg_price": 10000,
        "egg_chance": 70
    },
    "необычный": {
        "color": "🟢",
        "max_level": 20,
        "skill_count": 2,
        "egg_price": None,
        "egg_chance": 20
    },
    "редкий": {
        "color": "🔵",
        "max_level": 30,
        "skill_count": 2,
        "egg_price": None,
        "egg_chance": 8
    },
    "эпический": {
        "color": "🟣",
        "max_level": 40,
        "skill_count": 3,
        "egg_price": None,
        "egg_chance": 1.5
    },
    "легендарный": {
        "color": "🟡",
        "max_level": 50,
        "skill_count": 5,
        "egg_price": None,
        "egg_chance": 0.5
    }
}

# Premium egg
PREMIUM_EGG = {
    "price_stars": 25,
    "chances": {
        "необычный": 5,
        "редкий": 25,
        "эпический": 60,
        "легендарный": 10
    }
}

# Pet types (over 100 variations)
PET_TYPES = [
    "🐕 Собака", "🐈 Кот", "🐉 Дракон", "🦊 Лиса", "🐺 Волк", 
    "🐇 Кролик", "🐭 Хомяк", "🐹 Морская свинка", "🐸 Лягушка", 
    "🐦 Попугай", "🦉 Сова", "🐍 Змея", "🦎 Ящерица", "🐢 Черепаха", 
    "🐟 Рыбка", "🐠 Золотая рыбка", "🐡 Рыба-шар", "🐙 Осьминог", 
    "🦑 Кальмар", "🦐 Креветка", "🦞 Лобстер", "🐚 Улитка", 
    "🐌 Слизень", "🐛 Гусеница", "🦋 Бабочка", "🐝 Пчела", 
    "🐞 Божья коровка", "🦗 Сверчок", "🕷️ Паук", "🦂 Скорпион", 
    "🦟 Комар", "🦠 Амёба", "🧫 Бактерия", "🦠 Вирус", "🧬 Клетка",
    "🦄 Единорог", "🐲 Дракончик", "🐉 Китайский дракон", "🐩 Пудель",
    "🐕‍🦺 Овчарка", "🐕 Хаски", "🐕 Такса", "🐕 Корги", "🐈 Персидский кот",
    "🐈 Сфинкс", "🐈 Бенгальский кот", "🐈 Мейн-кун", "🦁 Львёнок",
    "🐯 Тигрёнок", "🐆 Леопард", "🐅 Пантера", "🐃 Буйвол", "🐂 Бык",
    "🐄 Корова", "🐖 Свинка", "🐗 Кабан", "🐏 Баран", "🐑 Овечка",
    "🐐 Козлик", "🐫 Верблюд", "🦙 Лама", "🦒 Жираф", "🐘 Слон",
    "🦏 Носорог", "🦛 Бегемот", "🐁 Мышь", "🐀 Крыса", "🦔 Ёжик",
    "🦇 Летучая мышь", "🐿️ Белка", "🦌 Олень", "🐴 Лошадь", "🐎 Пони",
    "🦓 Зебра", "🦍 Горилла", "🐒 Обезьянка", "🐧 Пингвин", "🐦‍⬛ Ворон",
    "🦅 Орёл", "🦢 Лебедь", "🦩 Фламинго", "🐓 Петух", "🐔 Курица",
    "🐣 Цыплёнок", "🦆 Утка", "🦃 Индюк", "🐊 Крокодил", "🐊 Аллигатор",
    "🦕 Динозавр", "🦖 Тираннозавр", "🦕 Трицератопс", "🦕 Птеродактиль",
    "🐋 Кит", "🐬 Дельфин", "🦈 Акула", "🐊 Кайман", "🐠 Рыба-клоун",
    "🐟 Сом", "🐟 Щука", "🐟 Карп", "🐟 Лосось", "🐟 Форель"
]

# Vehicle types for casino
VEHICLE_TYPES = {
    "basic": {
        "name": "🚗 Базовая тачка",
        "price": 0,
        "power": 10,
        "fuel_capacity": 100,
        "storage": 1
    },
    "improved": {
        "name": "🚙 Улучшенный внедорожник",
        "price": 50000,
        "power": 20,
        "fuel_capacity": 150,
        "storage": 2
    },
    "truck": {
        "name": "🚚 Грузовик",
        "price": 150000,
        "power": 30,
        "fuel_capacity": 200,
        "storage": 4
    },
    "helicopter": {
        "name": "🚁 Вертолёт",
        "price": 500000,
        "power": 50,
        "fuel_capacity": 300,
        "storage": 6
    },
    "ship": {
        "name": "🛳️ Корабль",
        "price": 1000000,
        "power": 80,
        "fuel_capacity": 500,
        "storage": 10
    },
    "spaceship": {
        "name": "🚀 Космический корабль",
        "price": 5000000,
        "power": 150,
        "fuel_capacity": 1000,
        "storage": 20,
        "premium": True
    }
}

# Casino locations
CASINO_LOCATIONS = {
    "beach": {
        "name": "🏖️ Пляж",
        "min_power": 1,
        "max_crabs_per_trip": 5000,
        "fuel_cost": 10,
        "duration": 60  # minutes
    },
    "forest": {
        "name": "🌲 Лес",
        "min_power": 5,
        "max_crabs_per_trip": 10000,
        "fuel_cost": 15,
        "duration": 120
    },
    "mountains": {
        "name": "⛰️ Горы",
        "min_power": 10,
        "max_crabs_per_trip": 20000,
        "fuel_cost": 20,
        "duration": 180
    },
    "desert": {
        "name": "🏜️ Пустыня",
        "min_power": 15,
        "max_crabs_per_trip": 35000,
        "fuel_cost": 25,
        "duration": 240
    },
    "ocean": {
        "name": "🌊 Океан",
        "min_power": 20,
        "max_crabs_per_trip": 50000,
        "fuel_cost": 30,
        "duration": 300
    },
    "volcano": {
        "name": "🌋 Вулкан",
        "min_power": 30,
        "max_crabs_per_trip": 75000,
        "fuel_cost": 40,
        "duration": 360
    },
    "arctic": {
        "name": "❄️ Арктика",
        "min_power": 40,
        "max_crabs_per_trip": 100000,
        "fuel_cost": 50,
        "duration": 420
    },
    "space": {
        "name": "🌌 Космос",
        "min_power": 60,
        "max_crabs_per_trip": 150000,
        "fuel_cost": 100,
        "duration": 600,
        "premium": True
    }
}