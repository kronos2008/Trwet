from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from typing import List, Dict, Any, Optional

def main_menu_keyboard() -> InlineKeyboardMarkup:
    """Main menu keyboard"""
    keyboard = [
        [
            InlineKeyboardButton("💑 Отношения", callback_data="menu_relations"),
            InlineKeyboardButton("🏠 Дом", callback_data="menu_house")
        ],
        [
            InlineKeyboardButton("🐾 Питомцы", callback_data="menu_pets"),
            InlineKeyboardButton("👶 Дети", callback_data="menu_children")
        ],
        [
            InlineKeyboardButton("🎰 Казино", callback_data="menu_casino"),
            InlineKeyboardButton("👤 Профиль", callback_data="menu_profile")
        ],
        [
            InlineKeyboardButton("📊 Топ", callback_data="menu_top"),
            InlineKeyboardButton("❓ Помощь", callback_data="menu_help")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def relation_menu_keyboard(has_relation: bool = False, relation_data: Dict = None) -> InlineKeyboardMarkup:
    """Relations menu keyboard"""
    keyboard = []
    
    if not has_relation:
        keyboard.append([
            InlineKeyboardButton("💌 Найти партнёра", callback_data="rel_find"),
            InlineKeyboardButton("📝 Запросы", callback_data="rel_requests")
        ])
    else:
        keyboard.extend([
            [
                InlineKeyboardButton("❤️ Действия", callback_data="rel_actions"),
                InlineKeyboardButton("📊 Статистика", callback_data="rel_stats")
            ],
            [
                InlineKeyboardButton("🏠 Дом", callback_data="rel_house"),
                InlineKeyboardButton("👶 Дети", callback_data="rel_children")
            ],
            [
                InlineKeyboardButton("💔 Расторгнуть", callback_data="rel_break"),
                InlineKeyboardButton("🔍 Проверка", callback_data="rel_check")
            ]
        ])
    
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="menu_main")])
    return InlineKeyboardMarkup(keyboard)

def house_menu_keyboard(has_house: bool = False) -> InlineKeyboardMarkup:
    """House menu keyboard"""
    keyboard = []
    
    if not has_house:
        keyboard.append([
            InlineKeyboardButton("🏗️ Построить дом", callback_data="house_build")
        ])
    else:
        keyboard.extend([
            [
                InlineKeyboardButton("🚪 Комнаты", callback_data="house_rooms"),
                InlineKeyboardButton("🔧 Улучшения", callback_data="house_upgrades")
            ],
            [
                InlineKeyboardButton("⭐ Престиж", callback_data="house_prestige"),
                InlineKeyboardButton("💰 Доход", callback_data="house_income")
            ],
            [
                InlineKeyboardButton("🏷️ Продать", callback_data="house_sell"),
                InlineKeyboardButton("📊 Статистика", callback_data="house_stats")
            ]
        ])
    
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="menu_relations")])
    return InlineKeyboardMarkup(keyboard)

def rooms_keyboard(rooms: List[Dict], page: int = 0) -> InlineKeyboardMarkup:
    """Rooms list keyboard"""
    keyboard = []
    
    # Show rooms (4 per page)
    start_idx = page * 4
    end_idx = start_idx + 4
    page_rooms = rooms[start_idx:end_idx]
    
    for room in page_rooms:
        name = room["name"]
        level = room.get("level", 1)
        max_level = room.get("max_level", 4)
        
        level_display = "█" * level + "░" * (max_level - level)
        
        keyboard.append([
            InlineKeyboardButton(
                f"{name} [{level_display}]", 
                callback_data=f"room_select_{room['id']}"
            )
        ])
    
    # Navigation
    nav_row = []
    if page > 0:
        nav_row.append(InlineKeyboardButton("◀️", callback_data=f"rooms_page_{page-1}"))
    
    nav_row.append(InlineKeyboardButton(f"{page+1}/{(len(rooms)-1)//4+1}", callback_data="rooms_current"))
    
    if end_idx < len(rooms):
        nav_row.append(InlineKeyboardButton("▶️", callback_data=f"rooms_page_{page+1}"))
    
    if nav_row:
        keyboard.append(nav_row)
    
    # Actions
    keyboard.extend([
        [InlineKeyboardButton("➕ Купить комнату", callback_data="room_buy")],
        [InlineKeyboardButton("◀️ Назад", callback_data="house_menu")]
    ])
    
    return InlineKeyboardMarkup(keyboard)

def pets_menu_keyboard(pets: List[Dict]) -> InlineKeyboardMarkup:
    """Pets menu keyboard"""
    keyboard = []
    
    # List pets
    for pet in pets[:5]:  # Max 5 per page
        name = pet["name"]
        level = pet["level"]
        mood = pet["mood"]
        
        mood_emoji = "😊" if mood > 70 else "😐" if mood > 40 else "😢"
        
        keyboard.append([
            InlineKeyboardButton(
                f"{mood_emoji} {name} (Lv.{level})",
                callback_data=f"pet_select_{pet['pet_id']}"
            )
        ])
    
    # Actions
    keyboard.extend([
        [
            InlineKeyboardButton("🥚 Купить яйцо", callback_data="pet_buy_egg"),
            InlineKeyboardButton("🏠 Домики", callback_data="pet_houses")
        ],
        [InlineKeyboardButton("◀️ Назад", callback_data="menu_main")]
    ])
    
    return InlineKeyboardMarkup(keyboard)

def egg_shop_keyboard() -> InlineKeyboardMarkup:
    """Egg shop keyboard"""
    keyboard = [
        [
            InlineKeyboardButton("🥚 Обычное (10к)", callback_data="egg_buy_normal"),
            InlineKeyboardButton("✨ Золотое (50к)", callback_data="egg_buy_golden")
        ],
        [
            InlineKeyboardButton("🌟 Премиум (25⭐)", callback_data="egg_buy_premium")
        ],
        [InlineKeyboardButton("◀️ Назад", callback_data="pet_menu")]
    ]
    return InlineKeyboardMarkup(keyboard)

def children_menu_keyboard(children: List[Dict]) -> InlineKeyboardMarkup:
    """Children menu keyboard"""
    keyboard = []
    
    for child in children[:5]:
        name = child["name"]
        age = child["age"]
        stage = child["stage"]
        
        stage_emoji = {
            "baby": "👶",
            "toddler": "🧒",
            "preschool": "🧒",
            "child": "🧒",
            "teenager": "👦",
            "adult": "👨"
        }.get(stage, "👤")
        
        keyboard.append([
            InlineKeyboardButton(
                f"{stage_emoji} {name} ({age} мес)",
                callback_data=f"child_select_{child['child_id']}"
            )
        ])
    
    keyboard.extend([
        [
            InlineKeyboardButton("🎂 Событие", callback_data="child_event"),
            InlineKeyboardButton("📊 Отчёт", callback_data="child_report")
        ],
        [InlineKeyboardButton("◀️ Назад", callback_data="menu_relations")]
    ])
    
    return InlineKeyboardMarkup(keyboard)

def casino_menu_keyboard(profile: Dict) -> InlineKeyboardMarkup:
    """Casino menu keyboard"""
    vehicle = profile.get("vehicle", {})
    location_count = len([l for l in profile.get("locations", {}).values() if l.get("unlocked")])
    
    keyboard = [
        [
            InlineKeyboardButton("🚗 Транспорт", callback_data="casino_vehicle"),
            InlineKeyboardButton("🗺️ Локации", callback_data="casino_locations")
        ],
        [
            InlineKeyboardButton("⛏️ Добыча", callback_data="casino_mine"),
            InlineKeyboardButton("📦 Инвентарь", callback_data="casino_inventory")
        ],
        [
            InlineKeyboardButton("🎲 Рулетка", callback_data="casino_roulette"),
            InlineKeyboardButton("💣 Динамит", callback_data="casino_dynamite")
        ],
        [
            InlineKeyboardButton("📊 Статистика", callback_data="casino_stats"),
            InlineKeyboardButton("🏆 Топ", callback_data="casino_top")
        ],
        [InlineKeyboardButton("◀️ Назад", callback_data="menu_main")]
    ]
    
    return InlineKeyboardMarkup(keyboard)

def vehicle_menu_keyboard(current_vehicle: Dict, available_vehicles: List[str]) -> InlineKeyboardMarkup:
    """Vehicle upgrade menu"""
    keyboard = []
    
    for vehicle_id in available_vehicles:
        from utils.constants import VEHICLE_TYPES
        v_data = VEHICLE_TYPES[vehicle_id]
        
        # Check if this is current vehicle
        if vehicle_id == current_vehicle.get("type"):
            name = f"✅ {v_data['name']} (текущий)"
        else:
            name = v_data['name']
        
        keyboard.append([
            InlineKeyboardButton(name, callback_data=f"vehicle_select_{vehicle_id}")
        ])
    
    keyboard.append([InlineKeyboardButton("🔧 Заправить", callback_data="vehicle_refuel")])
    keyboard.append([InlineKeyboardButton("🛠️ Починить", callback_data="vehicle_repair")])
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="casino_menu")])
    
    return InlineKeyboardMarkup(keyboard)

def location_menu_keyboard(locations: Dict) -> InlineKeyboardMarkup:
    """Locations menu keyboard"""
    keyboard = []
    
    for loc_id, loc_data in locations.items():
        from utils.constants import CASINO_LOCATIONS
        loc_config = CASINO_LOCATIONS.get(loc_id, {})
        
        if loc_data.get("unlocked"):
            name = f"✅ {loc_config.get('name', loc_id)}"
            power_req = loc_config.get("min_power", 0)
            status = f"⚡{power_req}"
        else:
            name = f"🔒 {loc_config.get('name', loc_id)}"
            status = f"⚡{loc_config.get('min_power', 0)}"
        
        keyboard.append([
            InlineKeyboardButton(f"{name} [{status}]", callback_data=f"location_{loc_id}")
        ])
    
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="casino_menu")])
    
    return InlineKeyboardMarkup(keyboard)

def confirmation_keyboard(action: str, data: str) -> InlineKeyboardMarkup:
    """Yes/No confirmation keyboard"""
    keyboard = [
        [
            InlineKeyboardButton("✅ Да", callback_data=f"confirm_{action}_{data}"),
            InlineKeyboardButton("❌ Нет", callback_data=f"cancel_{action}")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def pagination_keyboard(base_callback: str, current_page: int, total_pages: int, back_callback: str) -> InlineKeyboardMarkup:
    """Generic pagination keyboard"""
    keyboard = []
    
    # Navigation row
    nav_row = []
    if current_page > 0:
        nav_row.append(InlineKeyboardButton("◀️", callback_data=f"{base_callback}_{current_page-1}"))
    
    nav_row.append(InlineKeyboardButton(f"{current_page+1}/{total_pages}", callback_data="pagination_current"))
    
    if current_page < total_pages - 1:
        nav_row.append(InlineKeyboardButton("▶️", callback_data=f"{base_callback}_{current_page+1}"))
    
    if nav_row:
        keyboard.append(nav_row)
    
    # Back button
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data=back_callback)])
    
    return InlineKeyboardMarkup(keyboard)

def gender_selection_keyboard() -> InlineKeyboardMarkup:
    """Gender selection keyboard"""
    keyboard = [
        [
            InlineKeyboardButton("👨 Мужской", callback_data="gender_male"),
            InlineKeyboardButton("👩 Женский", callback_data="gender_female")
        ],
        [InlineKeyboardButton("◀️ Отмена", callback_data="gender_cancel")]
    ]
    return InlineKeyboardMarkup(keyboard)

def vip_packages_keyboard() -> InlineKeyboardMarkup:
    """VIP packages keyboard"""
    keyboard = [
        [
            InlineKeyboardButton("1 месяц - 100 ⭐", callback_data="vip_1m"),
            InlineKeyboardButton("3 месяца - 270 ⭐", callback_data="vip_3m")
        ],
        [
            InlineKeyboardButton("6 месяцев - 500 ⭐", callback_data="vip_6m"),
            InlineKeyboardButton("1 год - 900 ⭐", callback_data="vip_12m")
        ],
        [
            InlineKeyboardButton("2 года - 1600 ⭐", callback_data="vip_24m")
        ],
        [InlineKeyboardButton("◀️ Назад", callback_data="menu_profile")]
    ]
    return InlineKeyboardMarkup(keyboard)