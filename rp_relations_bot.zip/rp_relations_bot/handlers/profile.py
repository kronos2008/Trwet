import logging
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CallbackQueryHandler
from telegram.constants import ParseMode

from database import db
from utils.decorators import require_user, log_command
from utils.helpers import get_user_mention, is_premium, format_number
from keyboards.inline import main_menu_keyboard, gender_selection_keyboard, vip_packages_keyboard

logger = logging.getLogger(__name__)

@require_user
@log_command
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start command"""
    user = update.effective_user
    db_user = context.user_data['db_user']
    
    welcome_text = (
        f"👋 Привет, {user.first_name}!\n\n"
        "Я бот для ролевых игр и виртуальных отношений.\n"
        "Вот что я умею:\n\n"
        "🎭 **RP команды** - .обнять, .поцеловать и другие\n"
        "💑 **Отношения** - создавай пары и развивай их\n"
        "🏠 **Дома** - строй и улучшай жильё\n"
        "🐾 **Питомцы** - заводи и воспитывай\n"
        "👶 **Дети** - создавай семью\n"
        "🎰 **Казино** - добывай крабиков\n\n"
        "Используй .help для списка команд"
    )
    
    await update.message.reply_text(
        welcome_text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=main_menu_keyboard()
    )

@require_user
@log_command
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Help command"""
    help_text = (
        "📚 **Список команд**\n\n"
        "**Основные:**\n"
        ".start - запустить бота\n"
        ".help - это меню\n"
        ".профиль - мой профиль\n"
        ".мойпол - установить пол\n"
        ".ник <имя> - установить ник\n\n"
        
        "**RP команды:**\n"
        ".обнять, .поцеловать, .ударить и т.д.\n"
        ".ррп - список всех RP команд\n"
        ".срп - создать свою RP команду\n"
        ".мрп - мои RP команды\n"
        ".урп - удалить RP команду\n"
        ".ирп - игнор-лист RP\n\n"
        
        "**Отношения:**\n"
        ".отн - меню отношений\n"
        ".запрос @user - предложить отношения\n"
        ".расторгнуть - разорвать отношения\n"
        ".проверка - проверить верность\n"
        ".обида - обидеться на партнёра\n\n"
        
        "**Дом:**\n"
        ".дом - управление домом\n"
        ".построить - построить дом\n\n"
        
        "**Питомцы:**\n"
        ".питомец - меню питомцев\n"
        ".яйцо - купить яйцо\n\n"
        
        "**Дети:**\n"
        ".ребенок - меню детей\n"
        ".родить - родить ребёнка\n\n"
        
        "**Казино:**\n"
        ".казино - меню казино\n"
        ".транспорт - управление транспортом\n"
        ".локация - выбрать локацию\n"
        ".добыча - добывать крабиков\n\n"
        
        "**Админ:**\n"
        ".мут, .бан, .размут, .разбан"
    )
    
    await update.message.reply_text(
        help_text,
        parse_mode=ParseMode.MARKDOWN
    )

@require_user
@log_command
async def view_profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View user profile"""
    user = update.effective_user
    db_user = context.user_data['db_user']
    
    # Get stats
    relations = await db.get_user_relations(user.id)
    pets = await db.get_user_pets(user.id)
    
    # Get casino profile
    casino = await db.get_casino_profile(user.id)
    
    vip_status = "✅ VIP" if is_premium(db_user) else "❌ Нет"
    vip_until = ""
    if db_user.get('vip_until'):
        vip_until = f"\n⏳ Действует до: {db_user['vip_until'].strftime('%d.%m.%Y')}"
    
    gender_emoji = "👨" if db_user.get('gender') == 'm' else "👩" if db_user.get('gender') == 'f' else "❓"
    gender_text = "Мужской" if db_user.get('gender') == 'm' else "Женский" if db_user.get('gender') == 'f' else "Не указан"
    
    profile_text = (
        f"**👤 Профиль**\n\n"
        f"🆔 ID: `{user.id}`\n"
        f"📝 Имя: {db_user.get('first_name', 'Неизвестно')}\n"
        f"🏷️ Ник: {db_user.get('nickname', 'Не указан')}\n"
        f"{gender_emoji} Пол: {gender_text}\n"
        f"💎 VIP: {vip_status}{vip_until}\n\n"
        
        f"**📊 Статистика**\n"
        f"💑 Отношений: {len(relations)}\n"
        f"🐾 Питомцев: {len(pets)}\n"
        f"💰 Крабиков: {format_number(casino.get('crabs', 0)) if casino else 'Нет профиля'}\n"
        f"✨ Всего искр: {format_number(db_user.get('stats', {}).get('total_sparks_earned', 0))}\n"
        f"🎯 Команд: {db_user.get('stats', {}).get('total_commands_used', 0)}\n\n"
        
        f"Используй .вип для покупки премиум статуса"
    )
    
    # Create keyboard
    keyboard = [
        [
            InlineKeyboardButton("⚙️ Настройки", callback_data="profile_settings"),
            InlineKeyboardButton("📊 Подробнее", callback_data="profile_stats")
        ],
        [
            InlineKeyboardButton("💎 Купить VIP", callback_data="profile_vip")
        ]
    ]
    
    await update.message.reply_text(
        profile_text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

@require_user
@log_command
async def set_gender(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set user gender"""
    await update.message.reply_text(
        "Выберите ваш пол:",
        reply_markup=gender_selection_keyboard()
    )

@require_user
@log_command
async def set_nickname(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set user nickname"""
    args = context.args
    if not args:
        await update.message.reply_text(
            "❌ Использование: .ник <желаемый ник>\n"
            "Пример: .ник Алексей"
        )
        return
    
    nickname = ' '.join(args)
    if len(nickname) > 30:
        await update.message.reply_text("❌ Ник не может быть длиннее 30 символов")
        return
    
    await db.update_user(update.effective_user.id, nickname=nickname)
    
    await update.message.reply_text(
        f"✅ Ваш ник изменён на: {nickname}"
    )

@require_user
@log_command
async def buy_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Buy VIP status"""
    vip_text = (
        "💎 **VIP Преимущества**\n\n"
        
        "**🌟 Основные:**\n"
        "• 20% шанс на +1 искру за RP команды\n"
        "• -50% времени отката на все действия\n"
        "• -30% потребления искр\n"
        "• Защита от разрыва (1 раз)\n"
        "• Уникальные премиум-действия\n"
        "• Перенос отношений в другой чат\n\n"
        
        "**👶 Для детей:**\n"
        "• До 30 детей вместо 10\n"
        "• Развитие в 1.5 раза быстрее\n"
        "• До 3 талантов вместо 1\n"
        "• 5 кружков вместо 3\n"
        "• Элитные учебные заведения\n\n"
        
        "**🏠 Для дома:**\n"
        "• Уникальные премиум дома\n"
        "• Скорость стройки +30%\n"
        "• Скидка 15% на улучшения\n"
        "• Продажа за 60% вместо 35%\n"
        "• +25% к искрам за действия\n\n"
        
        "**🤰 Для беременности:**\n"
        "• Развитие в 2 раза быстрее\n"
        "• Скидка 40% на события\n"
        "• +20% эффективность лечения\n"
        "• +10% к здоровью малыша\n\n"
        
        "Выберите пакет:"
    )
    
    await update.message.reply_text(
        vip_text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=vip_packages_keyboard()
    )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle profile callbacks"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "menu_main":
        await query.edit_message_text(
            "Главное меню:",
            reply_markup=main_menu_keyboard()
        )
    
    elif data == "menu_profile":
        user = update.effective_user
        db_user = context.user_data.get('db_user', await db.get_user(user.id))
        
        profile_text = (
            f"**👤 Профиль**\n\n"
            f"🆔 ID: `{user.id}`\n"
            f"📝 Имя: {db_user.get('first_name')}\n"
            f"🏷️ Ник: {db_user.get('nickname', 'Не указан')}\n"
        )
        
        await query.edit_message_text(
            profile_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=main_menu_keyboard()
        )
    
    elif data == "profile_settings":
        settings_text = "⚙️ Настройки профиля"
        keyboard = [
            [InlineKeyboardButton("👤 Изменить пол", callback_data="profile_change_gender")],
            [InlineKeyboardButton("📝 Изменить ник", callback_data="profile_change_nickname")],
            [InlineKeyboardButton("🔔 Уведомления", callback_data="profile_notifications")],
            [InlineKeyboardButton("◀️ Назад", callback_data="menu_profile")]
        ]
        await query.edit_message_text(
            settings_text,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    elif data == "profile_change_gender":
        await query.edit_message_text(
            "Выберите пол:",
            reply_markup=gender_selection_keyboard()
        )
    
    elif data == "profile_vip":
        await buy_vip(update, context)
    
    elif data.startswith("gender_"):
        gender = data.split("_")[1]
        if gender in ["male", "female"]:
            db_gender = "m" if gender == "male" else "f"
            await db.update_user(update.effective_user.id, gender=db_gender)
            
            gender_text = "мужской" if db_gender == "m" else "женский"
            await query.edit_message_text(
                f"✅ Пол успешно установлен: {gender_text}"
            )
        else:
            await query.edit_message_text("❌ Отменено")
    
    elif data.startswith("vip_"):
        # Handle VIP purchase
        package = data.split("_")[1]
        months = {
            "1m": 1,
            "3m": 3,
            "6m": 6,
            "12m": 12,
            "24m": 24
        }.get(package, 1)
        
        prices = {
            "1m": 100,
            "3m": 270,
            "6m": 500,
            "12m": 900,
            "24m": 1600
        }
        
        stars = prices.get(package, 100)
        
        await query.edit_message_text(
            f"💰 Покупка VIP на {months} мес.\n"
            f"Стоимость: {stars} ⭐\n\n"
            f"Для оплаты отправьте {stars} звёзд боту\n"
            f"(команда .pay {stars} @botusername)"
        )

async def welcome_new_members(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Welcome new members to chat"""
    for member in update.message.new_chat_members:
        if member.is_bot:
            continue
        
        welcome = (
            f"👋 Добро пожаловать, {member.first_name}!\n"
            f"В этом чате доступны RP команды и система отношений.\n"
            f"Используй .help для списка команд"
        )
        
        await update.message.reply_text(welcome)