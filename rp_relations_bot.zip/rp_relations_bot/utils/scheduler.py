import asyncio
import logging
from datetime import datetime, timedelta
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger

from database import db
from config import Config
from utils.helpers import calculate_spark_cost, is_premium

logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler()

async def start_scheduler(application):
    """Start all background tasks"""
    logger.info("⏰ Starting scheduler...")
    
    # Daily spark consumption (every 24 hours)
    scheduler.add_job(
        daily_spark_consumption,
        trigger=IntervalTrigger(hours=24),
        args=[application],
        id="daily_spark_consumption",
        replace_existing=True
    )
    
    # Pet mood decay (every hour)
    scheduler.add_job(
        pet_mood_decay,
        trigger=IntervalTrigger(hours=1),
        args=[application],
        id="pet_mood_decay",
        replace_existing=True
    )
    
    # Pregnancy progression (every 2 hours for regular, 1 hour for VIP)
    scheduler.add_job(
        pregnancy_progression,
        trigger=IntervalTrigger(hours=1),
        args=[application],
        id="pregnancy_progression",
        replace_existing=True
    )
    
    # Child aging (every 12 hours)
    scheduler.add_job(
        child_aging,
        trigger=IntervalTrigger(hours=12),
        args=[application],
        id="child_aging",
        replace_existing=True
    )
    
    # House maintenance (every 24 hours)
    scheduler.add_job(
        house_maintenance,
        trigger=IntervalTrigger(hours=24),
        args=[application],
        id="house_maintenance",
        replace_existing=True
    )
    
    # VIP expiration check (every hour)
    scheduler.add_job(
        check_vip_expiration,
        trigger=IntervalTrigger(hours=1),
        args=[application],
        id="vip_expiration",
        replace_existing=True
    )
    
    # Database cleanup (weekly)
    scheduler.add_job(
        database_cleanup,
        trigger=CronTrigger(day_of_week="mon", hour=3),
        args=[],
        id="database_cleanup",
        replace_existing=True
    )
    
    scheduler.start()
    logger.info("✅ Scheduler started with 7 jobs")

async def daily_spark_consumption(application):
    """Daily spark consumption for all relations"""
    logger.info("💰 Processing daily spark consumption...")
    
    # Get all active relations
    cursor = db.db.relations.find({"status": "active"})
    relations = await cursor.to_list(length=None)
    
    consumed = 0
    ended = 0
    
    for relation in relations:
        relation_id = relation["_id"]
        level = relation["level"]
        children = relation.get("children_count", 0)
        
        # Check if premium
        user1 = await db.get_user(relation["user1_id"])
        user2 = await db.get_user(relation["user2_id"])
        premium = is_premium(user1) or is_premium(user2)
        
        # Calculate cost
        cost = calculate_spark_cost(level, children, premium)
        
        # Try to consume sparks
        if relation["sparks"] >= cost:
            await db.remove_sparks(relation_id, cost, "daily_maintenance")
            consumed += cost
            
            # Notify users
            try:
                chat_id = relation["chat_id"]
                await application.bot.send_message(
                    chat_id,
                    f"💫 Ежедневное обслуживание отношений: -{cost} искр"
                )
            except:
                pass
        else:
            # Not enough sparks - end relation
            await db.end_relation(relation_id, "sparks_depleted")
            ended += 1
            
            # Notify users
            try:
                chat_id = relation["chat_id"]
                await application.bot.send_message(
                    chat_id,
                    "💔 Ваши отношения разрушены из-за нехватки искр!"
                )
            except:
                pass
    
    logger.info(f"💰 Daily spark consumption: {consumed} sparks consumed, {ended} relations ended")

async def pet_mood_decay(application):
    """Hourly pet mood decay"""
    logger.info("😊 Processing pet mood decay...")
    
    # Get all pets
    cursor = db.db.pets.find({})
    pets = await cursor.to_list(length=None)
    
    updated = 0
    
    for pet in pets:
        user_id = pet["user_id"]
        pet_id = pet["pet_id"]
        
        # Calculate mood decay
        # Base: -2% per hour
        decay = 2
        
        # Apply personality
        personality = pet.get("personality", 0)
        if personality < 0:
            # Negative personality decays faster
            decay = int(decay * (1 + abs(personality) / 50))
        else:
            # Positive personality decays slower
            decay = int(decay * (1 - personality / 100))
        
        # Check if hungry (extra decay)
        last_fed = pet.get("last_fed")
        if last_fed:
            hours_since_fed = (datetime.utcnow() - last_fed).total_seconds() / 3600
            if hours_since_fed > 24:
                decay += 5  # Extra decay if not fed for over 24 hours
        
        # Update mood
        new_mood = max(0, pet["mood"] - decay)
        await db.db.pets.update_one(
            {"user_id": user_id, "pet_id": pet_id},
            {"$set": {"mood": new_mood}}
        )
        
        updated += 1
    
    logger.info(f"😊 Updated mood for {updated} pets")

async def pregnancy_progression(application):
    """Hourly pregnancy progression"""
    logger.info("🤰 Processing pregnancy progression...")
    
    # Get all active pregnancies
    cursor = db.db.pregnancies.find({})
    pregnancies = await cursor.to_list(length=None)
    
    progressed = 0
    completed = 0
    
    for pregnancy in pregnancies:
        relation_id = pregnancy["relation_id"]
        
        # Get relation to check VIP
        relation = await db.db.relations.find_one({"_id": relation_id})
        if not relation:
            continue
        
        user1 = await db.get_user(relation["user1_id"])
        user2 = await db.get_user(relation["user2_id"])
        premium = is_premium(user1) or is_premium(user2)
        
        # Determine progression rate
        # VIP: 1 hour per week, Regular: 2 hours per week
        last_update = pregnancy["last_update"]
        hours_since = (datetime.utcnow() - last_update).total_seconds() / 3600
        
        weeks_to_add = 0
        if premium:
            if hours_since >= 1:
                weeks_to_add = int(hours_since)
        else:
            if hours_since >= 2:
                weeks_to_add = int(hours_since / 2)
        
        if weeks_to_add > 0:
            new_week = pregnancy["week"] + weeks_to_add
            
            if new_week >= Config.PREGNANCY_WEEKS:
                # Pregnancy complete
                await db.db.pregnancies.update_one(
                    {"relation_id": relation_id},
                    {"$set": {"week": Config.PREGNANCY_WEEKS, "completed": True}}
                )
                completed += 1
                
                # Notify users
                try:
                    chat_id = relation["chat_id"]
                    await application.bot.send_message(
                        chat_id,
                        "👶 Ваш ребёнок готов родиться! Используйте .родить"
                    )
                except:
                    pass
            else:
                await db.db.pregnancies.update_one(
                    {"relation_id": relation_id},
                    {"$set": {"week": new_week, "last_update": datetime.utcnow()}}
                )
                progressed += 1
    
    logger.info(f"🤰 Pregnancy progression: {progressed} advanced, {completed} completed")

async def child_aging(application):
    """Child aging every 12 hours"""
    logger.info("👶 Processing child aging...")
    
    # Get all children
    cursor = db.db.children.find({})
    children = await cursor.to_list(length=None)
    
    aged = 0
    
    for child in children:
        relation_id = child["relation_id"]
        child_id = child["child_id"]
        
        # Update age
        from utils.helpers import update_child_age
        await db.update_child_age(relation_id, child_id)
        aged += 1
    
    logger.info(f"👶 Updated age for {aged} children")

async def house_maintenance(application):
    """Weekly house maintenance"""
    logger.info("🏠 Processing house maintenance...")
    
    # Get all houses
    cursor = db.db.houses.find({"status": "active"})
    houses = await cursor.to_list(length=None)
    
    collected = 0
    warned = 0
    demolished = 0
    
    for house in houses:
        relation_id = house["relation_id"]
        house_type = house["house_type"]
        
        # Get relation
        relation = await db.db.relations.find_one({"_id": relation_id})
        if not relation:
            continue
        
        # Calculate maintenance cost
        from utils.constants import HOUSE_TYPES
        house_config = HOUSE_TYPES.get(house_type, HOUSE_TYPES["хижина"])
        maintenance_percent = house_config.get("maintenance", 0.002)
        cost = int(house_config["price"] * maintenance_percent)
        
        # Check if enough sparks
        if relation["sparks"] >= cost:
            await db.remove_sparks(relation_id, cost, "house_maintenance")
            collected += cost
            
            # Reset warnings
            await db.db.houses.update_one(
                {"relation_id": relation_id},
                {"$set": {"maintenance_warnings": 0}}
            )
        else:
            # Not enough sparks - increment warnings
            warnings = house.get("maintenance_warnings", 0) + 1
            
            if warnings >= 3:
                # Demolish house
                await db.db.houses.update_one(
                    {"relation_id": relation_id},
                    {"$set": {"status": "demolished"}}
                )
                demolished += 1
                
                # Notify users
                try:
                    chat_id = relation["chat_id"]
                    await application.bot.send_message(
                        chat_id,
                        "🏚️ Ваш дом снесён из-за неуплаты обслуживания!"
                    )
                except:
                    pass
            else:
                # Send warning
                await db.db.houses.update_one(
                    {"relation_id": relation_id},
                    {"$set": {"maintenance_warnings": warnings}}
                )
                warned += 1
                
                # Notify users
                try:
                    chat_id = relation["chat_id"]
                    days_left = 3 - warnings
                    await application.bot.send_message(
                        chat_id,
                        f"⚠️ Внимание! У вас {days_left} дня на оплату обслуживания дома ({cost} искр), иначе он будет снесён!"
                    )
                except:
                    pass
    
    logger.info(f"🏠 House maintenance: {collected} sparks collected, {warned} warned, {demolished} demolished")

async def check_vip_expiration(application):
    """Check for expired VIP status"""
    logger.info("💎 Checking VIP expiration...")
    
    # Get all users with VIP
    cursor = db.db.users.find({"vip_until": {"$ne": None}})
    users = await cursor.to_list(length=None)
    
    expired = 0
    
    for user in users:
        vip_until = user["vip_until"]
        if vip_until and vip_until < datetime.utcnow():
            # VIP expired
            await db.db.users.update_one(
                {"user_id": user["user_id"]},
                {"$set": {"vip_until": None}}
            )
            expired += 1
            
            # Notify user
            try:
                await application.bot.send_message(
                    user["user_id"],
                    "💔 Срок вашего VIP статуса истёк. Приобретите новый по команде .вип"
                )
            except:
                pass
    
    logger.info(f"💎 {expired} VIP memberships expired")

async def database_cleanup():
    """Weekly database cleanup"""
    logger.info("🧹 Cleaning up database...")
    
    # Delete old history entries (>30 days)
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    
    # Clean relation history
    result = await db.db.relations.update_many(
        {},
        {"$pull": {"history": {"timestamp": {"$lt": thirty_days_ago}}}}
    )
    
    # Clean ended relations (>90 days)
    ninety_days_ago = datetime.utcnow() - timedelta(days=90)
    await db.db.relations.delete_many({
        "status": "ended",
        "ended_at": {"$lt": ninety_days_ago}
    })
    
    # Clean old logs
    await db.db.command_log.delete_many({
        "timestamp": {"$lt": thirty_days_ago}
    })
    
    logger.info(f"🧹 Database cleanup completed")