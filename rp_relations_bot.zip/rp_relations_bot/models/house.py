from datetime import datetime
from typing import Optional, Dict, List
from pydantic import BaseModel, Field

class RoomModel(BaseModel):
    """Room model"""
    room_type: str
    level: int = 1
    purchased_at: datetime = Field(default_factory=datetime.utcnow)
    last_action: Optional[datetime] = None
    
    @property
    def max_level(self) -> int:
        """Get max level for room type"""
        from utils.constants import ROOM_TYPES
        return ROOM_TYPES.get(self.room_type, {}).get("levels", 1)
    
    @property
    def can_upgrade(self) -> bool:
        """Check if room can be upgraded"""
        return self.level < self.max_level

class UpgradeModel(BaseModel):
    """House upgrade model"""
    upgrade_type: str
    level: int = 1
    purchased_at: datetime = Field(default_factory=datetime.utcnow)
    
    @property
    def max_level(self) -> int:
        """Get max level for upgrade type"""
        # All upgrades have 4 levels max
        return 4
    
    @property
    def can_upgrade(self) -> bool:
        """Check if upgrade can be upgraded"""
        return self.level < self.max_level

class HouseModel(BaseModel):
    """House model"""
    relation_id: int
    house_type: str
    level: int = 1
    prestige: int = 0
    rooms: Dict[str, RoomModel] = Field(default_factory=dict)
    upgrades: Dict[str, UpgradeModel] = Field(default_factory=dict)
    built_at: datetime = Field(default_factory=datetime.utcnow)
    last_maintenance: datetime = Field(default_factory=datetime.utcnow)
    status: str = "active"  # active, building, demolished, abandoned
    build_complete_at: Optional[datetime] = None
    maintenance_warnings: int = 0
    
    class Config:
        arbitrary_types_allowed = True
    
    @property
    def house_config(self):
        """Get house configuration"""
        from utils.constants import HOUSE_TYPES
        return HOUSE_TYPES.get(self.house_type, HOUSE_TYPES["хижина"])
    
    @property
    def maintenance_cost(self) -> int:
        """Get weekly maintenance cost"""
        config = self.house_config
        return int(config["price"] * config.get("maintenance", 0.002))
    
    @property
    def total_rooms(self) -> int:
        """Get total number of rooms"""
        return len(self.rooms)
    
    @property
    def max_rooms(self) -> int:
        """Get maximum rooms allowed"""
        config = self.house_config
        return config.get("rooms", 3)
    
    @property
    def can_add_room(self) -> bool:
        """Check if can add new room"""
        return self.total_rooms < self.max_rooms
    
    @property
    def prestige_bonus(self) -> float:
        """Get prestige bonus multiplier"""
        return 1 + (self.prestige * 0.002)
    
    def get_room_actions(self) -> List[Dict]:
        """Get all available room actions"""
        actions = []
        
        for room_type, room in self.rooms.items():
            from utils.constants import ROOM_TYPES
            room_config = ROOM_TYPES.get(room_type, {})
            room_actions = room_config.get("actions", [])
            
            for action in room_actions:
                actions.append({
                    "room": room_type,
                    "action": action,
                    "level": room.level,
                    "last_used": room.last_action
                })
        
        return actions