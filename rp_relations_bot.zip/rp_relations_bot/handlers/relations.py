import logging
import random
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CallbackQueryHandler
from telegram.constants import ParseMode

from database import db
from utils.constants import RELATION_ACTIONS, RELATION_LEVELS
from utils.decorators import require_user, require_relation, rate_limit, log_command, premium_required
from utils.helpers import extract_user, get_user_mention, format_duration, format_number, is_premium
from keyboards.inline import relation_menu_keyboard, confirmation_keyboard

logger = logging.getLogger(__name__)

@require_user
@log_command
async def relations_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Main relations menu"""
    user = update.effective_user
    message = update.effective_message
    
    # Check if user has active relation in this chat
    chat_id = update.effective_chat.id
    relations = await db.get_user_relations(user.id)
    
    active_relation = None
    for rel in relations:
        if rel.get("chat_id") == chat_id and rel.get("status") == "active":
            active_relation = rel
            break
    
    if active_relation:
        # Get partner info
        partner_id = active_relation["user2_id"] if active_relation["user1_id"] == user.id else active_relation["user1_id"]
        try:
            partner = await context.bot.get_chat(partner_id)
            partner_name = partner.first_name
        except:
            partner_name = f"User{partner_id}"
        
        # Get level name
        level_name = RELATION_LEVELS.get(active_relation["level"], f"Уровень {active_relation['level']}")
        
        # Calculate progress
        progress = active_relation.get("progress_percent", 0)
        progress_bar = "█" * (progress // 10) + "░" * (10 - (progress // 10))
        
        # Calculate daily cost
        children = active_relation.get("children_count", 0)
        premium = is_premium(await db.get_user(user.id)) or is_premium(await db.get_user(partner_id))
        daily_cost = calculate_spark_cost(active_relation["level"], children, premium)
        
        relation_text = (
            f"💑 **Ваши отношения**\n\n"
            f"👤 Партнёр: {partner_name}\n"
            f"📅 Вместе: {(datetime.utcnow() - active_relation['created_at']).days} дней\n"
            f"🏷️ Статус: {level_name}\n\n"
            
            f"✨ **Искры**\n"
            f"Текущий баланс: {format_number(active_relation['sparks'])}\n"
            f"До след. уровня: {format_number(active_relation.get('sparks_to_next_level', 0))}\n"
            f"Прогресс: {progress_bar} {progress}%\n"
            f"📊 Ежедневный расход: {format_number(daily_cost)} искр\n\n"
            
            f"👶 Детей: {active_relation.get('children_count', 0)}\n"
            f"🏠 Дом: {'✅' if await db.get_house(active_relation['_id']) else '❌'}"
        )
    else:
        relation_text = (
            "💑 **Отношения**\n\n"
            "У вас пока нет отношений в этом чате.\n"
            "Предложите отношения пользователю через .запрос @user"
        )
    
    await message.reply_text(
        relation_text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=relation_menu_keyboard(active_relation is not None)
    )

@require_user
@log_command
async def relation_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send relation request"""
    user = update.effective_user
    message = update.effective_message
    
    # Extract target user
    target_id, target_mention = extract_user(message)
    
    if not target_id:
        await message.reply_text(
            "❌ Укажите пользователя (ответом или упоминанием)\n"
            "Пример: .запрос @username"
        )
        return
    
    if target_id == user.id:
        await message.reply_text("❌ Нельзя предложить отношения самому себе")
        return
    
    # Check if already in relation in this chat
    chat_id = update.effective_chat.id
    relations = await db.get_user_relations(user.id)
    
    for rel in relations:
        if rel.get("chat_id") == chat_id and rel.get("status") == "active":
            await message.reply_text("❌ У вас уже есть отношения в этом чате")
            return
    
    # Check target's relations
    target_relations = await db.get_user_relations(target_id)
    for rel in target_relations:
        if rel.get("chat_id") == chat_id and rel.get("status") == "active":
            await message.reply_text("❌ У этого пользователя уже есть отношения в этом чате")
            return
    
    # Check if request already exists
    existing = await db.db.relation_requests.find_one({
        "from_user": user.id,
        "to_user": target_id,
        "chat_id": chat_id,
        "status": "pending"
    })
    
    if existing:
        await message.reply_text("❌ Запрос уже отправлен. Ожидайте ответа")
        return
    
    # Create request
    request = {
        "from_user": user.id,
        "to_user": target_id,
        "chat_id": chat_id,
        "created_at": datetime.utcnow(),
        "expires_at": datetime.utcnow() + timedelta(hours=24),
        "status": "pending"
    }
    
    await db.db.relation_requests.insert_one(request)
    
    # Send to target
    user_mention = get_user_mention(user)
    
    request_text = (
        f"💌 **Запрос на отношения**\n\n"
        f"{user_mention} предлагает вам создать отношения!\n\n"
        f"💕 Хотите стать парой?"
    )
    
    keyboard = [
        [
            InlineKeyboardButton("✅ Принять", callback_data=f"rel_accept_{user.id}"),
            InlineKeyboardButton("❌ Отклонить", callback_data=f"rel_decline_{user.id}")
        ]
    ]
    
    try:
        await context.bot.send_message(
            target_id,
            request_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except:
        await message.reply_text("❌ Не удалось отправить сообщение пользователю. Возможно, он не запускал бота")
        return
    
    await message.reply_text(
        f"✅ Запрос отправлен! Ожидайте ответа"
    )

@require_user
@log_command
async def break_relation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Break current relation"""
    user = update.effective_user
    message = update.effective_message
    
    # Find active relation
    chat_id = update.effective_chat.id
    relations = await db.get_user_relations(user.id)
    
    active_relation = None
    for rel in relations:
        if rel.get("chat_id") == chat_id and rel.get("status") == "active":
            active_relation = rel
            break
    
    if not active_relation:
        await message.reply_text("❌ У вас нет отношений в этом чате")
        return
    
    # Ask for confirmation
    keyboard = confirmation_keyboard("break", str(active_relation["_id"]))
    
    await message.reply_text(
        "💔 **Вы уверены?**\n\n"
        "Это действие необратимо! Все дети, дом и прогресс будут потеряны.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=keyboard
    )

@require_user
@log_command
async def check_faithfulness(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check if partner has other relations"""
    user = update.effective_user
    message = update.effective_message
    
    # Find active relation
    chat_id = update.effective_chat.id
    relations = await db.get_user_relations(user.id)
    
    active_relation = None
    for rel in relations:
        if rel.get("chat_id") == chat_id and rel.get("status") == "active":
            active_relation = rel
            break
    
    if not active_relation:
        await message.reply_text("❌ У вас нет отношений в этом чате")
        return
    
    # Get partner ID
    partner_id = active_relation["user2_id"] if active_relation["user1_id"] == user.id else active_relation["user1_id"]
    
    # Check partner's other relations
    partner_relations = await db.get_user_relations(partner_id)
    other_relations = [r for r in partner_relations if r["_id"] != active_relation["_id"] and r["status"] == "active"]
    
    if other_relations:
        text = "⚠️ **Результат проверки**\n\n"
        text += f"У вашего партнёра есть отношения в других чатах:\n\n"
        
        for rel in other_relations[:3]:
            try:
                chat = await context.bot.get_chat(rel["chat_id"])
                chat_name = chat.title or "Личка"
            except:
                chat_name = "Неизвестный чат"
            
            # Get other partner
            other_id = rel["user2_id"] if rel["user1_id"] == partner_id else rel["user1_id"]
            try:
                other = await context.bot.get_chat(other_id)
                other_name = other.first_name
            except:
                other_name = f"User{other_id}"
            
            text += f"• {chat_name} с {other_name}\n"
    else:
        text = "✅ **Результат проверки**\n\n"
        text += "У вашего партнёра нет других отношений. Всё чисто!"
    
    await message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

@require_user
@require_relation
@log_command
async def offense_mechanic(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Offense mechanic - block partner actions"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    
    # Check if already offended
    offended_by = relation.get("offended_by")
    offended_until = relation.get("offended_until")
    
    if offended_by == user.id and offended_until and offended_until > datetime.utcnow():
        # Remove offense
        await db.db.relations.update_one(
            {"_id": relation["_id"]},
            {"$set": {"offended_by": None, "offended_until": None}}
        )
        await update.effective_message.reply_text("😊 Вы больше не обижены")
        return
    
    # Set offense for 24 hours
    until = datetime.utcnow() + timedelta(hours=24)
    
    await db.db.relations.update_one(
        {"_id": relation["_id"]},
        {"$set": {"offended_by": user.id, "offended_until": until}}
    )
    
    partner_id = relation["user2_id"] if relation["user1_id"] == user.id else relation["user1_id"]
    partner_mention = get_user_mention({"user_id": partner_id, "first_name": "Партнёр"})
    
    await update.effective_message.reply_text(
        f"😤 Вы обиделись на {partner_mention} на 24 часа.\n"
        f"В течение этого времени {partner_mention} не может использовать действия на вас.",
        parse_mode=ParseMode.MARKDOWN
    )

@require_user
@require_relation
@rate_limit(300)  # 5 minutes cooldown
@log_command
async def relation_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Perform relation action"""
    user = update.effective_user
    message = update.effective_message
    relation = context.user_data['current_relation']
    target_id = context.user_data['target_id']
    
    # Get action from command
    command = message.text.split()[0][1:].lower()
    
    # Check if action exists
    if command not in RELATION_ACTIONS:
        await message.reply_text(f"❌ Действие .{command} не найдено")
        return
    
    action_data = RELATION_ACTIONS[command]
    
    # Check level requirement
    if relation["level"] < action_data["min_level"]:
        await message.reply_text(
            f"❌ Это действие доступно с {action_data['min_level']} уровня отношений"
        )
        return
    
    # Check premium requirement
    if action_data.get("premium"):
        db_user = await db.get_user(user.id)
        if not is_premium(db_user):
            await message.reply_text(
                "💎 Это действие доступно только для VIP пользователей"
            )
            return
    
    # Check gender requirement
    if action_data.get("gender_req"):
        target_user = await db.get_user(target_id)
        if not target_user or target_user.get("gender") != action_data["gender_req"]:
            gender_text = "мужского" if action_data["gender_req"] == "male" else "женского"
            await message.reply_text(f"❌ Это действие требует партнёра {gender_text} пола")
            return
    
    # Check if partner is offended
    if relation.get("offended_by") == target_id and relation.get("offended_until", datetime.utcnow()) > datetime.utcnow():
        await message.reply_text("❌ Ваш партнёр обижен и не хочет взаимодействовать")
        return
    
    # Calculate sparks
    base_sparks = action_data["sparks"]
    
    # Apply house prestige bonus if any
    house = await db.get_house(relation["_id"])
    prestige_bonus = house.get("prestige", 0) * 0.002 if house else 0
    
    # Apply pet bonuses
    pets = await db.get_user_pets(user.id)
    pet_multiplier = 1.0
    for pet in pets:
        if pet.get("mood", 0) >= 30:  # Pet must be in good mood
            # Check for spark talisman skill
            for skill in pet.get("skills", []):
                if skill["name"] == "spark_talisman":
                    pet_multiplier *= 1 + (skill["level"] * 0.04)
    
    total_sparks = int(base_sparks * (1 + prestige_bonus) * pet_multiplier)
    
    # Add sparks
    await db.add_sparks(relation["_id"], total_sparks, f"action_{command}")
    
    # Check for pregnancy
    if action_data.get("pregnancy_chance") and command in ["секс", "кекс", "пошалить"]:
        # Check if partner is using protection
        # This would need a separate protection system
        if random.randint(1, 100) <= action_data["pregnancy_chance"]:
            # Check if already pregnant
            existing = await db.get_pregnancy(relation["_id"])
            if not existing:
                await db.start_pregnancy(relation["_id"])
                await message.reply_text(
                    "🤰 **Вау!** Кажется, вы беременны!\n"
                    "Используйте .беременность для наблюдения за развитием."
                )
    
    # Format response
    user_mention = get_user_mention(user)
    target_mention = context.user_data['target_mention']
    
    action_templates = {
        "обнять": f"{user_mention} нежно обнял(а) {target_mention}",
        "поцеловать": f"{user_mention} нежно поцеловал(а) {target_mention}",
        "комплимент": f"{user_mention} сделал(а) комплимент {target_mention}",
        "романтика": f"{user_mention} устроил(а) романтический вечер для {target_mention}",
        "свидание": f"{user_mention} пригласил(а) {target_mention} на свидание",
        "признание": f"{user_mention} признался(ась) в любви {target_mention}",
        "подарок": f"{user_mention} подарил(а) подарок {target_mention}",
        "путешествие": f"{user_mention} отправился(ась) в путешествие с {target_mention}",
        "сюрприз": f"{user_mention} сделал(а) сюрприз для {target_mention}",
        "душевный_разговор": f"{user_mention} поговорил(а) по душам с {target_mention}",
        "мечты": f"{user_mention} поделился(ась) мечтами с {target_mention}",
        "обещание": f"{user_mention} дал(а) обещание {target_mention}",
        "ритуал": f"{user_mention} провёл(ела) особый ритуал с {target_mention}",
        "клятва": f"{user_mention} дал(а) вечную клятву {target_mention}",
        "секс": f"{user_mention} занялся(ась) любовью с {target_mention}",
        "кекс": f"{user_mention} занялся(ась) любовью с {target_mention}",
        "пошалить": f"{user_mention} пошалил(а) с {target_mention}"
    }
    
    # Premium actions
    premium_templates = {
        "аура_эмпатии": f"{user_mention} окутал(а) {target_mention} аурой эмпатии",
        "нейронная_связь": f"{user_mention} установил(а) нейронную связь с {target_mention}",
        "параллельный_мир": f"{user_mention} перенёс(ла) {target_mention} в параллельный мир",
        "днк_любовь": f"{user_mention} соединил(а) ДНК с {target_mention}",
        "квантовое_слияние": f"{user_mention} слился(ась) с {target_mention} на квантовом уровне"
    }
    
    all_templates = {**action_templates, **premium_templates}
    response = all_templates.get(command, f"{user_mention} выполнил(а) действие с {target_mention}")
    
    # Add spark info
    response += f"\n\n✨ +{total_sparks} искр"
    
    await message.reply_text(response, parse_mode=ParseMode.MARKDOWN)

@require_user
@log_command
async def buy_sparks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Buy sparks with stars"""
    user = update.effective_user
    message = update.effective_message
    
    args = context.args
    if not args:
        await message.reply_text(
            "✨ **Покупка искр**\n\n"
            "Купите искры за звёзды:\n"
            "• 100 ⭐ = 10 000 искр\n"
            "• 500 ⭐ = 60 000 искр\n"
            "• 1000 ⭐ = 150 000 искр\n\n"
            "Использование: .искры <количество звёзд>"
        )
        return
    
    try:
        stars = int(args[0])
    except:
        await message.reply_text("❌ Укажите число звёзд")
        return
    
    # Calculate sparks
    if stars == 100:
        sparks = 10000
    elif stars == 500:
        sparks = 60000
    elif stars == 1000:
        sparks = 150000
    else:
        await message.reply_text(
            "❌ Доступные пакеты: 100, 500, 1000 звёзд"
        )
        return
    
    # Find active relation
    chat_id = update.effective_chat.id
    relations = await db.get_user_relations(user.id)
    
    active_relation = None
    for rel in relations:
        if rel.get("chat_id") == chat_id and rel.get("status") == "active":
            active_relation = rel
            break
    
    if not active_relation:
        await message.reply_text("❌ У вас нет отношений в этом чате")
        return
    
    # Here would be Stars payment processing
    # For now, just add sparks
    await db.add_sparks(active_relation["_id"], sparks, "purchase")
    
    await message.reply_text(
        f"✅ Куплено {format_number(sparks)} искр за {stars} ⭐"
    )

@require_user
@require_relation
@log_command
async def spark_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View spark transaction history"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    
    history = relation.get("history", [])
    
    if not history:
        await update.effective_message.reply_text("📊 История операций пуста")
        return
    
    # Sort by timestamp (newest first)
    history.sort(key=lambda x: x["timestamp"], reverse=True)
    
    text = "📊 **История операций**\n\n"
    
    for entry in history[:10]:  # Show last 10
        timestamp = entry["timestamp"].strftime("%d.%m %H:%M")
        amount = entry["amount"]
        reason = entry["reason"]
        
        if entry["type"] == "earn":
            sign = "+"
            emoji = "✨"
        else:
            sign = "-"
            emoji = "💸"
        
        text += f"{emoji} {timestamp} {sign}{format_number(amount)} ({reason})\n"
    
    if len(history) > 10:
        text += f"\n...и ещё {len(history) - 10} записей"
    
    await update.effective_message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle relation callbacks"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "menu_relations":
        await relations_menu(update, context)
    
    elif data.startswith("rel_accept_"):
        from_user = int(data.split("_")[2])
        to_user = update.effective_user.id
        chat_id = update.effective_chat.id
        
        # Find request
        request = await db.db.relation_requests.find_one({
            "from_user": from_user,
            "to_user": to_user,
            "chat_id": chat_id,
            "status": "pending"
        })
        
        if not request:
            await query.edit_message_text("❌ Запрос не найден или уже обработан")
            return
        
        # Create relation
        relation = await db.create_relation(from_user, to_user, chat_id)
        
        # Update request
        await db.db.relation_requests.update_one(
            {"_id": request["_id"]},
            {"$set": {"status": "accepted"}}
        )
        
        # Get user mentions
        from_mention = get_user_mention({"user_id": from_user, "first_name": "Пользователь"})
        to_mention = get_user_mention({"user_id": to_user, "first_name": "Пользователь"})
        
        await query.edit_message_text(
            f"💕 **Поздравляем!**\n\n"
            f"{from_mention} и {to_mention} теперь пара!\n\n"
            f"Уровень: 1 - Зарождение интереса\n"
            f"Используйте .отн для управления отношениями",
            parse_mode=ParseMode.MARKDOWN
        )
    
    elif data.startswith("rel_decline_"):
        from_user = int(data.split("_")[2])
        to_user = update.effective_user.id
        
        # Find request
        request = await db.db.relation_requests.find_one({
            "from_user": from_user,
            "to_user": to_user,
            "status": "pending"
        })
        
        if request:
            await db.db.relation_requests.update_one(
                {"_id": request["_id"]},
                {"$set": {"status": "declined"}}
            )
        
        await query.edit_message_text("❌ Запрос отклонён")
    
    elif data.startswith("confirm_break_"):
        relation_id = data.split("_")[2]
        
        # End relation
        await db.end_relation(relation_id, "user_initiated")
        
        await query.edit_message_text(
            "💔 Отношения расторгнуты. Все дети, дом и прогресс потеряны."
        )
    
    elif data.startswith("cancel_break"):
        await query.edit_message_text("❌ Отменено")

# Helper function
def calculate_spark_cost(level: int, children: int = 0, premium: bool = False) -> int:
    """Calculate daily spark cost"""
    if level <= 5:
        cost = 15 * level
    elif level <= 10:
        cost = 50 * level + 50
    elif level <= 15:
        cost = 80 * level + 200
    elif level <= 20:
        cost = 150 * level + 500
    elif level <= 25:
        cost = 300 * level + 1500
    else:
        cost = 500 * level + 3000
    
    if children > 0:
        cost = int(cost * (1 + children * 0.1))
    
    if premium:
        cost = int(cost * 0.7)
    
    return cost