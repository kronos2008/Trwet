import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Bot
    BOT_TOKEN = os.getenv('BOT_TOKEN')
    
    # Admins
    ADMIN_IDS = [int(x) for x in os.getenv('ADMIN_IDS', '').split(',') if x]
    
    # Limits
    MAX_CUSTOM_COMMANDS_DEFAULT = 3
    MAX_CUSTOM_COMMANDS_VIP = 50
    MAX_IGNORE_LIST_DEFAULT = 3
    MAX_IGNORE_LIST_VIP = 20
    MAX_CHILDREN_DEFAULT = 10
    MAX_CHILDREN_VIP = 30
    MAX_PETS_PER_USER = 5
    
    # Relations
    RELATION_LEVELS = {
        1: "💕 Зарождение интереса",
        5: "🔥 Первая близость",
        10: "💖 Безусловная любовь",
        15: "💞 Гармоничная связь",
        20: "💑 Идеальная гармония",
        25: "💍 Нерушимый союз",
        30: "👑 Легендарная любовь"
    }
    
    # Pregnancy
    PREGNANCY_WEEKS = 40
    PREGNANCY_HOURS_PER_WEEK = 2
    PREGNANCY_VIP_HOURS_PER_WEEK = 1
    PREGNANCY_CHANCE = 15
    
    # VIP Perks
    VIP_DISCOUNT = 0.3
    VIP_COOLDOWN_REDUCTION = 0.5
    VIP_BUILD_SPEED = 0.3
    VIP_HOUSE_SELL_RATE = 0.6
    
    # Casino
    CASINO_STARTING_CRABS = 10000
    CASINO_FUEL_COST_PERCENT = 0.0015
    CASINO_REPAIR_COST_PERCENT = 0.02
    CASINO_MAX_REPAIR_COST = 1_000_000
    CASINO_MAX_FUEL_COST = 50_000
    CASINO_STORAGE_UNIT_SIZE = 250_000