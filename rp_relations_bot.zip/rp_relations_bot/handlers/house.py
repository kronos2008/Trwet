import logging
import random
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from database import db
from utils.constants import HOUSE_TYPES, ROOM_TYPES
from utils.decorators import require_user, require_relation, rate_limit, log_command, premium_required
from utils.helpers import format_number, format_duration, is_premium
from keyboards.inline import house_menu_keyboard, rooms_keyboard, confirmation_keyboard

logger = logging.getLogger(__name__)

@require_user
@require_relation
@log_command
async def house_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Main house menu"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    
    # Get house
    house = await db.get_house(relation["_id"])
    
    if not house:
        text = (
            "🏠 **Дом**\n\n"
            "У вас пока нет дома.\n"
            "Постройте дом для ваших отношений!"
        )
        keyboard = [
            [InlineKeyboardButton("🏗️ Построить дом", callback_data="house_build")],
            [InlineKeyboardButton("◀️ Назад", callback_data="menu_relations")]
        ]
    else:
        house_config = HOUSE_TYPES.get(house["house_type"], HOUSE_TYPES["хижина"])
        
        # Calculate maintenance
        maintenance_cost = int(house_config["price"] * house_config.get("maintenance", 0.002))
        days_until_maintenance = 7 - (datetime.utcnow() - house["last_maintenance"]).days
        
        text = (
            f"🏠 **{house_config['description']}**\n\n"
            f"📊 **Статистика**\n"
            f"Тип: {house_config['name'] if 'name' in house_config else house['house_type']}\n"
            f"Уровень: {house.get('level', 1)}\n"
            f"⭐ Престиж: {house.get('prestige', 0)}\n"
            f"🚪 Комнат: {len(house.get('rooms', {}))}/{house_config['rooms']}\n"
            f"🔧 Улучшений: {len(house.get('upgrades', {}))}\n\n"
            
            f"💰 **Финансы**\n"
            f"Обслуживание: {format_number(maintenance_cost)} искр/неделю\n"
            f"Следующий платёж: через {max(0, days_until_maintenance)} дн\n"
            f"Предупреждений: {house.get('maintenance_warnings', 0)}/3\n\n"
            
            f"💎 **Бонусы**\n"
            f"• Действия дают +{house.get('prestige', 0) * 0.2:.1f}% искр\n"
        )
        
        keyboard = house_menu_keyboard(True)
    
    await update.effective_message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard) if 'keyboard' in locals() else None
    )

@require_user
@require_relation
@log_command
async def build_house(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Build a house"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    
    # Check if already have house
    existing = await db.get_house(relation["_id"])
    if existing:
        await update.effective_message.reply_text("❌ У вас уже есть дом")
        return
    
    # Show available houses
    text = "🏗️ **Выберите тип дома**\n\n"
    
    for house_id, config in HOUSE_TYPES.items():
        if config.get("premium") and not is_premium(await db.get_user(user.id)):
            continue
        
        price = config["price"]
        build_time = config["build_time"]
        rooms = config["rooms"]
        maintenance = config["maintenance"] * 100
        
        text += f"**{config['description']}**\n"
        text += f"💰 Цена: {format_number(price)} искр\n"
        text += f"⏱️ Стройка: {build_time} ч\n"
        text += f"🚪 Комнат: {rooms}\n"
        text += f"📊 Обслуживание: {maintenance:.2f}%/нед\n"
        text += f"⭐ Престиж: {config['prestige']}\n\n"
    
    text += "\nВыберите тип командой .построить <тип>\n"
    text += "Пример: .построить хижина"
    
    await update.effective_message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

@require_user
@require_relation
@log_command
async def room_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manage rooms"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    
    house = await db.get_house(relation["_id"])
    if not house:
        await update.effective_message.reply_text("❌ Сначала постройте дом")
        return
    
    rooms = []
    for room_type, room_data in house.get("rooms", {}).items():
        rooms.append({
            "id": room_type,
            "name": ROOM_TYPES.get(room_type, {}).get("name", room_type),
            "level": room_data.get("level", 1),
            "max_level": ROOM_TYPES.get(room_type, {}).get("levels", 1)
        })
    
    await update.effective_message.reply_text(
        "🚪 **Комнаты**\n\nВыберите комнату для управления:",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=rooms_keyboard(rooms)
    )

@require_user
@require_relation
@rate_limit(3600)  # 1 hour cooldown
@log_command
async def room_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Perform action in room"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    message = update.effective_message
    
    args = context.args
    if len(args) < 1:
        await message.reply_text("❌ Использование: .дом действие <ид_комнаты>")
        return
    
    room_id = args[0].lower()
    
    house = await db.get_house(relation["_id"])
    if not house:
        await message.reply_text("❌ Сначала постройте дом")
        return
    
    if room_id not in house.get("rooms", {}):
        await message.reply_text("❌ Комната не найдена")
        return
    
    room_data = house["rooms"][room_id]
    room_config = ROOM_TYPES.get(room_id, {})
    
    # Check if action available
    actions = room_config.get("actions", [])
    if not actions:
        await message.reply_text("❌ В этой комнате нет доступных действий")
        return
    
    # Calculate rewards
    base_sparks = 500  # Base reward
    level_bonus = room_data.get("level", 1) * 100
    prestige_bonus = house.get("prestige", 0) * 0.002
    
    total_sparks = int((base_sparks + level_bonus) * (1 + prestige_bonus))
    
    # Apply premium bonus
    if is_premium(await db.get_user(user.id)):
        total_sparks = int(total_sparks * 1.25)
    
    # Add sparks
    await db.add_sparks(relation["_id"], total_sparks, f"house_action_{room_id}")
    
    # Update last action time
    await db.db.houses.update_one(
        {"relation_id": relation["_id"]},
        {"$set": {f"rooms.{room_id}.last_action": datetime.utcnow()}}
    )
    
    # Get random action description
    action_descriptions = {
        "отдых": "отдыхает в уютной спальне",
        "романтика": "наслаждается романтической атмосферой",
        "киномарафон": "устроил киномарафон",
        "вечеринка": "устроил вечеринку",
        "готовка": "готовит вместе вкусный ужин",
        "ужин": "наслаждается романтическим ужином",
        "семейный_ужин": "проводит семейный ужин",
        "спа": "расслабляется в спа",
        "творчество": "занимается творчеством",
        "игры": "играет в игры",
        "киносеанс": "смотрит кино",
        "тренировка": "тренируется",
        "плавание": "плавает в бассейне",
        "чтение": "читает книги",
        "парение": "парится в сауне",
        "дегустация": "проводит дегустацию вин"
    }
    
    action_text = action_descriptions.get(random.choice(actions), "проводит время в доме")
    
    partner_id = relation["user2_id"] if relation["user1_id"] == user.id else relation["user1_id"]
    user_mention = get_user_mention(user)
    partner_mention = get_user_mention({"user_id": partner_id, "first_name": "Партнёр"})
    
    await message.reply_text(
        f"🏠 {user_mention} {action_text} с {partner_mention}\n\n✨ +{total_sparks} искр",
        parse_mode=ParseMode.MARKDOWN
    )

@require_user
@require_relation
@log_command
async def upgrade_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Upgrade menu"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    
    house = await db.get_house(relation["_id"])
    if not house:
        await update.effective_message.reply_text("❌ Сначала постройте дом")
        return
    
    text = "🔧 **Улучшения дома**\n\n"
    
    upgrade_types = [
        ("electricity", "⚡ Электрика"),
        ("heating", "🔥 Отопление"),
        ("internet", "🌐 Интернет"),
        ("water", "💧 Водоснабжение"),
        ("gas", "⛽ Газоснабжение"),
        ("sewage", "🚽 Канализация"),
        ("waste", "🗑️ Утилизация"),
        ("purification", "💧 Очистка воды")
    ]
    
    upgrades = house.get("upgrades", {})
    
    for upgrade_id, upgrade_name in upgrade_types:
        current_level = upgrades.get(upgrade_id, {}).get("level", 0)
        if current_level < 4:
            next_level = current_level + 1
            price = 5000 * next_level
            text += f"{upgrade_name}: уровень {current_level} → {next_level} (💰 {format_number(price)} искр)\n"
        else:
            text += f"{upgrade_name}: уровень 4 (МАКС)\n"
    
    text += "\nКупить улучшение: .купить <тип>\n"
    text += "Пример: .купить electricity"
    
    await update.effective_message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

@require_user
@require_relation
@log_command
async def prestige_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show prestige info"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    
    house = await db.get_house(relation["_id"])
    if not house:
        await update.effective_message.reply_text("❌ Сначала постройте дом")
        return
    
    prestige = house.get("prestige", 0)
    bonus = prestige * 0.2
    
    text = (
        f"⭐ **Престиж дома**\n\n"
        f"Текущий престиж: {prestige}\n"
        f"Бонус к искрам: +{bonus:.1f}%\n\n"
        
        f"**Как получить престиж:**\n"
        f"• Покупка комнат: +5-60 за комнату\n"
        f"• Улучшения: +1-32 за улучшение\n"
        f"• Уровень дома: +{house.get('level', 1) * 10}\n\n"
        
        f"**Следующий уровень престижа:**\n"
        f"До {prestige + 10}: ещё +2% к бонусу"
    )
    
    await update.effective_message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle house callbacks"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "house_menu":
        await house_menu(update, context)
    
    elif data == "house_build":
        await build_house(update, context)
    
    elif data == "house_rooms":
        await room_menu(update, context)
    
    elif data.startswith("room_select_"):
        room_id = data.split("_")[2]
        
        # Show room info
        text = f"🚪 **Комната**: {room_id}\n\n"
        text += "Управление комнатой:\n"
        text += "• .дом действие <ид> - выполнить действие\n"
        text += "• .улучшить комната <ид> - улучшить комнату"
        
        await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN)
    
    elif data.startswith("rooms_page_"):
        page = int(data.split("_")[2])
        # Re-render rooms with new page
        await room_menu(update, context)