#!/usr/bin/env python3
import asyncio
import logging
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler
from telegram.ext import InlineQueryHandler, ChatMemberHandler

from config import Config
from database import db  # Это теперь будет JsonDatabase
from handlers import (
    rp_commands, relations, house, pets, children, 
    pregnancy, casino, admin, profile
)
from utils.helpers import setup_logging, error_handler
from utils.scheduler import start_scheduler

logger = setup_logging()

async def post_init(application: Application):
    """Initialize bot after startup"""
    logger.info("🤖 Bot is starting up with JSON storage...")
    
    # JSON базе не нужно подключение, просто проверяем папку
    import os
    if not os.path.exists("bot_data"):
        os.makedirs("bot_data")
        logger.info("📁 Created bot_data folder")
    
    # Start background scheduler
    await start_scheduler(application)
    
    # Set bot commands
    await application.bot.set_my_commands([
        ("start", "Запустить бота"),
        ("help", "Помощь"),
        ("отн", "Меню отношений"),
        ("дом", "Управление домом"),
        ("питомец", "Меню питомцев"),
        ("ребенок", "Управление детьми"),
        ("казино", "Казино и крабики"),
        ("профиль", "Мой профиль"),
        ("ррп", "Список RP команд"),
        ("срп", "Создать RP команду"),
        ("мрп", "Мои RP команды"),
        ("урп", "Удалить RP команду"),
        ("ирп", "Игнор-лист RP"),
        ("мойпол", "Установить пол"),
        ("ник", "Установить ник"),
        ("вип", "Приобрести VIP")
    ])
    
    logger.info(f"🤖 Bot @{application.bot.username} is running with JSON storage!")

def main():
    """Main entry point"""
    application = (
        Application.builder()
        .token(Config.BOT_TOKEN)
        .post_init(post_init)
        .build()
    )
    
    # ========== BASIC HANDLERS ==========
    application.add_handler(CommandHandler("start", profile.start))
    application.add_handler(CommandHandler("help", profile.help_command))
    
    # ========== RP COMMANDS ==========
    for cmd in rp_commands.STANDARD_COMMANDS.keys():
        application.add_handler(CommandHandler(cmd, rp_commands.handle_rp_command))
    
    application.add_handler(CommandHandler("ррп", rp_commands.list_all_rp))
    application.add_handler(CommandHandler("срп", rp_commands.create_custom_command))
    application.add_handler(CommandHandler("мрп", rp_commands.my_custom_commands))
    application.add_handler(CommandHandler("урп", rp_commands.delete_custom_command))
    application.add_handler(CommandHandler("ирп", rp_commands.ignore_list_manager))
    
    # ========== RELATIONS ==========
    application.add_handler(CommandHandler("отн", relations.relations_menu))
    application.add_handler(CommandHandler("запрос", relations.relation_request))
    application.add_handler(CommandHandler("расторгнуть", relations.break_relation))
    application.add_handler(CommandHandler("проверка", relations.check_faithfulness))
    application.add_handler(CommandHandler("обида", relations.offense_mechanic))
    application.add_handler(CommandHandler("искры", relations.buy_sparks))
    application.add_handler(CommandHandler("история", relations.spark_history))
    
    # ========== PROFILE ==========
    application.add_handler(CommandHandler("профиль", profile.view_profile))
    application.add_handler(CommandHandler("мойпол", profile.set_gender))
    application.add_handler(CommandHandler("ник", profile.set_nickname))
    application.add_handler(CommandHandler("вип", profile.buy_vip))
    
    # ========== HOUSE ==========
    application.add_handler(CommandHandler("дом", house.house_menu))
    application.add_handler(CommandHandler("построить", house.build_house))
    
    # ========== PETS ==========
    application.add_handler(CommandHandler("питомец", pets.pets_menu))
    application.add_handler(CommandHandler("яйцо", pets.buy_egg))
    application.add_handler(CommandHandler("покормить", pets.feed_pet))
    application.add_handler(CommandHandler("поиграть", pets.play_with_pet))
    
    # ========== CHILDREN ==========
    application.add_handler(CommandHandler("ребенок", children.children_menu))
    application.add_handler(CommandHandler("школа", children.school_menu))
    application.add_handler(CommandHandler("секция", children.club_menu))
    application.add_handler(CommandHandler("событие", children.family_event))
    
    # ========== PREGNANCY ==========
    application.add_handler(CommandHandler("беременность", pregnancy.pregnancy_menu))
    application.add_handler(CommandHandler("родить", pregnancy.give_birth))
    application.add_handler(CommandHandler("аборт", pregnancy.abortion))
    
    # ========== CASINO ==========
    application.add_handler(CommandHandler("казино", casino.casino_menu))
    application.add_handler(CommandHandler("транспорт", casino.vehicle_menu))
    application.add_handler(CommandHandler("локация", casino.location_menu))
    application.add_handler(CommandHandler("добыча", casino.mine_crabs))
    application.add_handler(CommandHandler("рулетка", casino.roulette))
    application.add_handler(CommandHandler("динамит", casino.dynamite_game))
    application.add_handler(CommandHandler("топ", casino.top_players))
    
    # ========== ADMIN ==========
    application.add_handler(CommandHandler("мут", admin.mute_user))
    application.add_handler(CommandHandler("размут", admin.unmute_user))
    application.add_handler(CommandHandler("бан", admin.ban_user))
    application.add_handler(CommandHandler("разбан", admin.unban_user))
    application.add_handler(CommandHandler("настройки", admin.chat_settings))
    
    # ========== CALLBACKS ==========
    application.add_handler(CallbackQueryHandler(profile.handle_callback))
    application.add_handler(CallbackQueryHandler(relations.handle_callback, pattern="^rel_"))
    application.add_handler(CallbackQueryHandler(house.handle_callback, pattern="^house_"))
    application.add_handler(CallbackQueryHandler(pets.handle_callback, pattern="^pet_"))
    application.add_handler(CallbackQueryHandler(children.handle_callback, pattern="^child_"))
    application.add_handler(CallbackQueryHandler(pregnancy.handle_callback, pattern="^preg_"))
    application.add_handler(CallbackQueryHandler(casino.handle_callback, pattern="^casino_"))
    
    # ========== ERROR HANDLER ==========
    application.add_error_handler(error_handler)
    
    logger.info("🚀 Starting bot with JSON storage...")
    application.run_polling(allowed_updates=['message', 'callback_query', 'inline_query', 'chat_member'])

if __name__ == "__main__":
    main()