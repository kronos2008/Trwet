from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel, Field

class PetSkillModel(BaseModel):
    """Pet skill model"""
    name: str
    type: str  # positive, negative
    level: int = 1
    
    @property
    def effect_value(self) -> float:
        """Get skill effect value based on level"""
        effects = {
            "spark_talisman": {1: 1.04, 2: 1.06, 3: 1.08},
            "cooldown_reducer": {1: 0.97, 2: 0.95, 3: 0.93},
            "house_economy": {1: 0.95, 2: 0.92, 3: 0.90},
            "nanny": {1: 1.05, 2: 1.07, 3: 1.10},
            "gluttonous": {1: 1.04, 2: 1.06, 3: 1.10},
            "lazy": {1: 1.05, 2: 1.10, 3: 1.15},
        }
        
        return effects.get(self.name, {}).get(self.level, 1.0)

class PetHouseModel(BaseModel):
    """Pet house model"""
    house_type: str
    purchased_at: datetime = Field(default_factory=datetime.utcnow)
    rooms: List[str] = Field(default_factory=list)
    
    @property
    def house_config(self):
        """Get house configuration"""
        from utils.constants import PET_HOUSES
        return PET_HOUSES.get(self.house_type, PET_HOUSES["картонная_коробка"])
    
    @property
    def slot_count(self) -> int:
        """Get number of slots"""
        return self.house_config.get("slots", 0)
    
    @property
    def room_count(self) -> int:
        """Get number of rooms"""
        return len(self.rooms)
    
    @property
    def can_add_room(self) -> bool:
        """Check if can add room"""
        return self.room_count < self.slot_count

class PetModel(BaseModel):
    """Pet model"""
    user_id: int
    pet_id: str
    name: str
    pet_type: str
    rarity: str
    level: int = 1
    exp: int = 0
    hp: int = 100
    mood: int = 80
    personality: int = 0  # -10 to +10
    skills: List[PetSkillModel] = Field(default_factory=list)
    food_consumption: int
    water_consumption: int
    last_fed: datetime = Field(default_factory=datetime.utcnow)
    last_played: datetime = Field(default_factory=datetime.utcnow)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    house: Optional[PetHouseModel] = None
    house_rooms: List[str] = Field(default_factory=list)
    
    class Config:
        arbitrary_types_allowed = True
    
    @property
    def rarity_config(self):
        """Get rarity configuration"""
        from utils.constants import PET_RARITIES
        return PET_RARITIES.get(self.rarity, PET_RARITIES["обычный"])
    
    @property
    def max_level(self) -> int:
        """Get max level based on rarity"""
        return self.rarity_config["max_level"]
    
    @property
    def exp_for_next_level(self) -> int:
        """Get exp needed for next level"""
        if self.level >= self.max_level:
            return 0
        return self._get_exp_for_level(self.level + 1)
    
    @property
    def exp_progress(self) -> int:
        """Get progress to next level"""
        if self.level >= self.max_level:
            return 100
        
        current_req = self._get_exp_for_level(self.level)
        next_req = self._get_exp_for_level(self.level + 1)
        
        progress = self.exp - current_req
        total = next_req - current_req
        
        return int((progress / total) * 100)
    
    def _get_exp_for_level(self, level: int) -> int:
        """Calculate exp needed for level"""
        return int(100 * (level ** 1.5))
    
    @property
    def mood_multiplier(self) -> float:
        """Get mood-based multiplier for skills"""
        if self.mood >= 80:
            return 1.0
        elif self.mood >= 60:
            return 0.8
        elif self.mood >= 40:
            return 0.6
        elif self.mood >= 20:
            return 0.3
        else:
            return 0.0  # Skills disabled
    
    @property
    def personality_multiplier(self) -> float:
        """Get personality multiplier for mood changes"""
        # Personality affects mood change speed
        # -10 = 50% faster decay, 50% slower recovery
        # +10 = 50% slower decay, 50% faster recovery
        return 1 + (self.personality / 20)
    
    def get_skill_effect(self, skill_name: str) -> float:
        """Get combined effect of a skill"""
        effect = 1.0
        
        for skill in self.skills:
            if skill.name == skill_name:
                effect *= skill.effect_value
        
        return effect * self.mood_multiplier
    
    def calculate_daily_cost(self) -> int:
        """Calculate daily food+water cost in sparks"""
        food_cost = self.food_consumption * 5
        water_cost = self.water_consumption * 3
        return food_cost + water_cost

# Pet houses
PET_HOUSES = {
    "картонная_коробка": {
        "name": "📦 Картонная коробка",
        "price": 0,
        "slots": 0,
        "mood_bonus": 0,
        "exp_bonus": 0,
        "skill_bonus": 0,
        "decay_reduction": 0
    },
    "уютный_коттедж": {
        "name": "🏡 Уютный коттедж",
        "price": 75000,
        "slots": 2,
        "mood_bonus": 5,
        "exp_bonus": 0,
        "skill_bonus": 0,
        "decay_reduction": 0
    },
    "просторный_особняк": {
        "name": "🏰 Просторный особняк",
        "price": 200000,
        "slots": 4,
        "mood_bonus": 10,
        "exp_bonus": 10,
        "skill_bonus": 0,
        "decay_reduction": 0
    },
    "величественный_замок": {
        "name": "🏯 Величественный замок",
        "price": 500000,
        "slots": 6,
        "mood_bonus": 15,
        "exp_bonus": 20,
        "skill_bonus": 15,
        "decay_reduction": 10
    }
}

# Pet house rooms
PET_ROOMS = {
    "игровая": {
        "name": "🎮 Игровая комната",
        "price": 20000,
        "mood_bonus": 3,
        "exp_bonus": 0,
        "skill_bonus": 0,
        "consumption_reduction": 0
    },
    "ресторан": {
        "name": "🍽️ Ресторан",
        "price": 25000,
        "mood_bonus": 0,
        "exp_bonus": 0,
        "skill_bonus": 0,
        "consumption_reduction": 5
    },
    "тренажерный_зал": {
        "name": "🏋️ Тренажёрный зал",
        "price": 28000,
        "mood_bonus": 0,
        "exp_bonus": 5,
        "skill_bonus": 0,
        "consumption_reduction": 0
    },
    "спа": {
        "name": "🛀 СПА-зона",
        "price": 30000,
        "mood_bonus": 0,
        "exp_bonus": 0,
        "skill_bonus": 0,
        "decay_reduction": 5
    },
    "медитация": {
        "name": "🧘 Комната медитации",
        "price": 32000,
        "mood_bonus": 0,
        "exp_bonus": 0,
        "skill_bonus": 0,
        "decay_reduction": 3,
        "recovery_bonus": 3
    },
    "арт_студия": {
        "name": "🎨 Арт-студия",
        "price": 35000,
        "mood_bonus": 2,
        "exp_bonus": 3,
        "skill_bonus": 0,
        "consumption_reduction": 0
    },
    "библиотека": {
        "name": "📚 Библиотека",
        "price": 40000,
        "mood_bonus": 0,
        "exp_bonus": 0,
        "skill_bonus": 4,
        "consumption_reduction": 0
    },
    "обсерватория": {
        "name": "🔭 Обсерватория",
        "price": 45000,
        "mood_bonus": 0,
        "exp_bonus": 4,
        "skill_bonus": 3,
        "consumption_reduction": 0
    }
}