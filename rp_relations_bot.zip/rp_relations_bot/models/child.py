from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel, Field

class ChildModel(BaseModel):
    """Child model"""
    relation_id: int
    child_id: str
    name: str
    gender: str
    age: int = 0  # in months
    stage: str = "baby"  # baby, toddler, preschool, child, teenager, adult
    talents: List[str] = Field(default_factory=list)
    health: Dict = Field(default_factory=lambda: {"status": "healthy", "conditions": []})
    
    stats: Dict = Field(default_factory=lambda: {
        "intelligence": 50,
        "creativity": 50,
        "athletics": 50,
        "social": 50,
        "discipline": 50
    })
    
    education: Optional[Dict] = None  # school type, grade
    clubs: List[Dict] = Field(default_factory=list)  # clubs/sections
    career: Optional[Dict] = None
    
    born_at: datetime = Field(default_factory=datetime.utcnow)
    last_update: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        arbitrary_types_allowed = True
    
    @property
    def stage_emoji(self) -> str:
        """Get emoji for current stage"""
        emojis = {
            "baby": "👶",
            "toddler": "🧒",
            "preschool": "🧒",
            "child": "🧒",
            "teenager": "👦",
            "adult": "👨"
        }
        return emojis.get(self.stage, "👤")
    
    @property
    def is_healthy(self) -> bool:
        """Check if child is healthy"""
        return self.health.get("status") == "healthy"
    
    @property
    def condition_count(self) -> int:
        """Get number of health conditions"""
        return len(self.health.get("conditions", []))
    
    def get_stat_bonus(self, stat: str) -> float:
        """Get talent bonus for a stat"""
        bonus = 1.0
        
        talent_bonuses = {
            "smart": {"intelligence": 1.2},
            "creative": {"creativity": 1.2},
            "athletic": {"athletics": 1.2},
            "musical": {"creativity": 1.15, "discipline": 1.1},
            "artistic": {"creativity": 1.2},
            "linguistic": {"intelligence": 1.15, "social": 1.1},
            "mathematical": {"intelligence": 1.2},
            "scientific": {"intelligence": 1.15, "discipline": 1.1},
            "leadership": {"social": 1.15, "discipline": 1.1},
            "empathy": {"social": 1.2},
            "charisma": {"social": 1.2},
            "memory": {"intelligence": 1.15},
            "logic": {"intelligence": 1.15},
            "speed": {"athletics": 1.15}
        }
        
        for talent in self.talents:
            if talent in talent_bonuses and stat in talent_bonuses[talent]:
                bonus *= talent_bonuses[talent][stat]
        
        return bonus
    
    def get_condition_penalty(self, stat: str) -> float:
        """Get health condition penalty for a stat"""
        penalty = 1.0
        
        condition_penalties = {
            "asthma": {"athletics": 0.7},
            "allergies": {"athletics": 0.8, "social": 0.9},
            "diabetes": {"athletics": 0.8, "discipline": 1.2},
            "heart_condition": {"athletics": 0.5},
            "vision_impairment": {"intelligence": 0.9, "athletics": 0.8},
            "hearing_impairment": {"intelligence": 0.8, "social": 0.7},
            "adhd": {"discipline": 0.6, "creativity": 1.1},
            "autism": {"social": 0.5, "intelligence": 1.1}
        }
        
        for condition in self.health.get("conditions", []):
            if condition in condition_penalties and stat in condition_penalties[condition]:
                penalty *= condition_penalties[condition][stat]
        
        return penalty
    
    def get_effective_stat(self, stat: str) -> int:
        """Get stat with bonuses and penalties"""
        base = self.stats.get(stat, 50)
        bonus = self.get_stat_bonus(stat)
        penalty = self.get_condition_penalty(stat)
        
        return int(base * bonus * penalty)
    
    @property
    def intelligence(self) -> int:
        """Get effective intelligence"""
        return self.get_effective_stat("intelligence")
    
    @property
    def creativity(self) -> int:
        """Get effective creativity"""
        return self.get_effective_stat("creativity")
    
    @property
    def athletics(self) -> int:
        """Get effective athletics"""
        return self.get_effective_stat("athletics")
    
    @property
    def social(self) -> int:
        """Get effective social"""
        return self.get_effective_stat("social")
    
    @property
    def discipline(self) -> int:
        """Get effective discipline"""
        return self.get_effective_stat("discipline")
    
    def add_exp(self, stat: str, amount: int):
        """Add experience to a stat"""
        current = self.stats.get(stat, 50)
        new_value = min(100, current + amount)
        self.stats[stat] = new_value
        return new_value

class SchoolModel(BaseModel):
    """School model"""
    school_type: str
    name: str
    grade: int = 1
    cost: int
    requirements: Dict = Field(default_factory=dict)
    bonuses: Dict = Field(default_factory=dict)

SCHOOL_TYPES = {
    "public": {
        "name": "🏫 Обычная школа",
        "cost": 1000,
        "grades": 11,
        "bonuses": {"intelligence": 1, "social": 1}
    },
    "private": {
        "name": "🏛️ Частная школа",
        "cost": 5000,
        "grades": 11,
        "bonuses": {"intelligence": 2, "discipline": 2, "social": 1}
    },
    "elite": {
        "name": "👑 Элитная гимназия",
        "cost": 15000,
        "grades": 11,
        "bonuses": {"intelligence": 3, "creativity": 2, "discipline": 2, "social": 2},
        "premium": True
    },
    "sports": {
        "name": "⚽ Спортивный интернат",
        "cost": 8000,
        "grades": 11,
        "bonuses": {"athletics": 3, "discipline": 2}
    },
    "arts": {
        "name": "🎨 Школа искусств",
        "cost": 8000,
        "grades": 11,
        "bonuses": {"creativity": 3, "discipline": 1}
    },
    "science": {
        "name": "🔬 Физико-математический лицей",
        "cost": 10000,
        "grades": 11,
        "bonuses": {"intelligence": 3, "discipline": 2}
    }
}

CLUB_TYPES = {
    "sports": {
        "name": "⚽ Спортивная секция",
        "cost": 500,
        "bonuses": {"athletics": 2, "discipline": 1}
    },
    "music": {
        "name": "🎵 Музыкальная школа",
        "cost": 800,
        "bonuses": {"creativity": 2, "discipline": 2}
    },
    "art": {
        "name": "🎨 Художественный кружок",
        "cost": 600,
        "bonuses": {"creativity": 2}
    },
    "dance": {
        "name": "💃 Танцевальная студия",
        "cost": 700,
        "bonuses": {"athletics": 1, "creativity": 1, "social": 1}
    },
    "chess": {
        "name": "♟️ Шахматный клуб",
        "cost": 400,
        "bonuses": {"intelligence": 2, "discipline": 1}
    },
    "robotics": {
        "name": "🤖 Робототехника",
        "cost": 1000,
        "bonuses": {"intelligence": 2, "creativity": 1}
    },
    "languages": {
        "name": "🗣️ Языковые курсы",
        "cost": 900,
        "bonuses": {"intelligence": 1, "social": 2}
    },
    "theater": {
        "name": "🎭 Театральная студия",
        "cost": 800,
        "bonuses": {"creativity": 1, "social": 2}
    }
}