import json
import os
import random
import time
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any

DATA_DIR = "bot_data"

class JsonDatabase:
    def __init__(self):
        # Создаем папку для данных
        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR)
            print(f"📁 Created {DATA_DIR} folder")
        
        # Все "таблицы" в виде JSON файлов
        self.files = {
            'users': 'users.json',
            'relations': 'relations.json',
            'custom_commands': 'custom_commands.json',
            'ignore_list': 'ignore_list.json',
            'houses': 'houses.json',
            'pets': 'pets.json',
            'children': 'children.json',
            'pregnancies': 'pregnancies.json',
            'casino': 'casino.json',
            'relation_requests': 'relation_requests.json',
            'chat_settings': 'chat_settings.json',
            'abortion_cooldown': 'abortion_cooldown.json'
        }
        
        # Создаем все файлы, если их нет
        for file in self.files.values():
            file_path = os.path.join(DATA_DIR, file)
            if not os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump([], f, ensure_ascii=False, indent=2)
                print(f"📄 Created {file}")
        
        # Простой кэш в памяти (для кулдаунов)
        self.cache = {}
        self.cooldowns = {}
        
        print("✅ JSON Database ready!")
    
    # ========== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ==========
    
    def _load(self, table: str) -> list:
        """Загрузить данные из JSON"""
        file_path = os.path.join(DATA_DIR, self.files[table])
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading {table}: {e}")
            return []
    
    def _save(self, table: str, data: list):
        """Сохранить данные в JSON"""
        file_path = os.path.join(DATA_DIR, self.files[table])
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        except Exception as e:
            print(f"Error saving {table}: {e}")
    
    def _find_one(self, table: str, **kwargs) -> Optional[dict]:
        """Найти одну запись"""
        data = self._load(table)
        for item in data:
            match = True
            for key, value in kwargs.items():
                if item.get(key) != value:
                    match = False
                    break
            if match:
                return item
        return None
    
    def _find(self, table: str, **kwargs) -> list:
        """Найти все записи"""
        data = self._load(table)
        result = []
        for item in data:
            match = True
            for key, value in kwargs.items():
                if item.get(key) != value:
                    match = False
                    break
            if match:
                result.append(item)
        return result
    
    def _insert(self, table: str, document: dict) -> dict:
        """Вставить запись"""
        data = self._load(table)
        
        # Добавляем ID если нет
        if '_id' not in document:
            document['_id'] = str(int(time.time() * 1000)) + str(random.randint(1000, 9999))
        
        data.append(document)
        self._save(table, data)
        return document
    
    def _update(self, table: str, filter_dict: dict, update_dict: dict):
        """Обновить запись"""
        data = self._load(table)
        updated = False
        
        for i, item in enumerate(data):
            # Проверяем соответствие фильтру
            match = True
            for key, value in filter_dict.items():
                if item.get(key) != value:
                    match = False
                    break
            
            if match:
                # Применяем обновления
                for op, fields in update_dict.items():
                    if op == '$set':
                        for key, value in fields.items():
                            data[i][key] = value
                            updated = True
                    
                    elif op == '$inc':
                        for key, value in fields.items():
                            data[i][key] = data[i].get(key, 0) + value
                            updated = True
                    
                    elif op == '$push':
                        for key, value in fields.items():
                            if key not in data[i]:
                                data[i][key] = []
                            data[i][key].append(value)
                            updated = True
        
        if updated:
            self._save(table, data)
    
    def _delete(self, table: str, **kwargs):
        """Удалить запись"""
        data = self._load(table)
        new_data = []
        
        for item in data:
            match = True
            for key, value in kwargs.items():
                if item.get(key) != value:
                    match = False
                    break
            if not match:
                new_data.append(item)
        
        self._save(table, new_data)
    
    def _now(self):
        """Текущее время"""
        return datetime.utcnow()
    
    # ========== REDIS ЗАМЕНА (кулдауны) ==========
    
    async def set_cooldown(self, key: str, seconds: int):
        """Установить кулдаун"""
        self.cooldowns[key] = time.time() + seconds
    
    async def get_cooldown(self, key: str) -> int:
        """Получить оставшееся время кулдауна"""
        if key in self.cooldowns:
            remaining = self.cooldowns[key] - time.time()
            if remaining > 0:
                return int(remaining)
            else:
                del self.cooldowns[key]
        return 0
    
    # ========== ПОЛЬЗОВАТЕЛИ ==========
    
    async def get_user(self, user_id: int) -> Optional[dict]:
        """Получить пользователя"""
        return self._find_one('users', user_id=user_id)
    
    async def create_user(self, user_id: int, username: str = None, first_name: str = None) -> dict:
        """Создать пользователя"""
        user = {
            "user_id": user_id,
            "username": username,
            "first_name": first_name,
            "gender": None,
            "nickname": None,
            "vip_until": None,
            "created_at": self._now().isoformat(),
            "stats": {
                "total_sparks_earned": 0,
                "total_commands_used": 0,
                "total_relations": 0
            }
        }
        return self._insert('users', user)
    
    async def update_user(self, user_id: int, **kwargs):
        """Обновить пользователя"""
        self._update('users', {'user_id': user_id}, {'$set': kwargs})
    
    # ========== ОТНОШЕНИЯ ==========
    
    async def create_relation(self, user1_id: int, user2_id: int, chat_id: int) -> dict:
        """Создать отношения"""
        relation = {
            "user1_id": user1_id,
            "user2_id": user2_id,
            "chat_id": chat_id,
            "level": 1,
            "sparks": 0,
            "created_at": self._now().isoformat(),
            "last_interaction": self._now().isoformat(),
            "status": "active",
            "children_count": 0,
            "total_sparks_earned": 0,
            "history": []
        }
        return self._insert('relations', relation)
    
    async def get_relation(self, user1_id: int, user2_id: int) -> Optional[dict]:
        """Получить отношения между двумя пользователями"""
        relations = self._find('relations', status='active')
        for rel in relations:
            if (rel['user1_id'] == user1_id and rel['user2_id'] == user2_id) or \
               (rel['user1_id'] == user2_id and rel['user2_id'] == user1_id):
                return rel
        return None
    
    async def get_user_relations(self, user_id: int) -> list:
        """Получить все отношения пользователя"""
        relations = self._find('relations', status='active')
        result = []
        for rel in relations:
            if rel['user1_id'] == user_id or rel['user2_id'] == user_id:
                result.append(rel)
        return result
    
    async def add_sparks(self, relation_id, amount: int, reason: str) -> int:
        """Добавить искры"""
        relation = self._find_one('relations', _id=relation_id)
        if not relation:
            return 0
        
        new_sparks = relation['sparks'] + amount
        new_level = self._calculate_level(new_sparks)
        
        self._update('relations', {'_id': relation_id}, {
            '$set': {
                'sparks': new_sparks,
                'level': new_level,
                'last_interaction': self._now().isoformat()
            },
            '$push': {
                'history': {
                    'type': 'earn',
                    'amount': amount,
                    'reason': reason,
                    'timestamp': self._now().isoformat()
                }
            }
        })
        
        return new_sparks
    
    async def remove_sparks(self, relation_id, amount: int, reason: str) -> int:
        """Удалить искры"""
        relation = self._find_one('relations', _id=relation_id)
        if not relation:
            return 0
        
        new_sparks = max(0, relation['sparks'] - amount)
        
        if new_sparks == 0:
            await self.end_relation(relation_id, "sparks_depleted")
            return 0
        
        self._update('relations', {'_id': relation_id}, {
            '$set': {'sparks': new_sparks},
            '$push': {
                'history': {
                    'type': 'spend',
                    'amount': amount,
                    'reason': reason,
                    'timestamp': self._now().isoformat()
                }
            }
        })
        
        return new_sparks
    
    async def end_relation(self, relation_id, reason: str):
        """Завершить отношения"""
        self._update('relations', {'_id': relation_id}, {
            '$set': {
                'status': 'ended',
                'ended_at': self._now().isoformat(),
                'end_reason': reason
            }
        })
        
        # Удалить дом
        self._delete('houses', relation_id=relation_id)
    
    def _calculate_level(self, sparks: int) -> int:
        """Рассчитать уровень по искрам"""
        if sparks < 100:
            return 1
        elif sparks < 500:
            return 2
        elif sparks < 1000:
            return 3
        elif sparks < 2000:
            return 4
        elif sparks < 3500:
            return 5
        elif sparks < 5500:
            return 6
        elif sparks < 8000:
            return 7
        elif sparks < 11000:
            return 8
        elif sparks < 15000:
            return 9
        elif sparks < 20000:
            return 10
        elif sparks < 26000:
            return 11
        elif sparks < 33000:
            return 12
        elif sparks < 41000:
            return 13
        elif sparks < 50000:
            return 14
        elif sparks < 60000:
            return 15
        elif sparks < 71000:
            return 16
        elif sparks < 83000:
            return 17
        elif sparks < 96000:
            return 18
        elif sparks < 110000:
            return 19
        elif sparks < 125000:
            return 20
        elif sparks < 141000:
            return 21
        elif sparks < 158000:
            return 22
        elif sparks < 176000:
            return 23
        elif sparks < 195000:
            return 24
        elif sparks < 215000:
            return 25
        elif sparks < 236000:
            return 26
        elif sparks < 258000:
            return 27
        elif sparks < 281000:
            return 28
        elif sparks < 305000:
            return 29
        else:
            return 30
    
    # ========== ЗАПРОСЫ НА ОТНОШЕНИЯ ==========
    
    async def create_relation_request(self, from_user: int, to_user: int, chat_id: int) -> dict:
        """Создать запрос на отношения"""
        request = {
            "from_user": from_user,
            "to_user": to_user,
            "chat_id": chat_id,
            "created_at": self._now().isoformat(),
            "expires_at": (self._now() + timedelta(hours=24)).isoformat(),
            "status": "pending"
        }
        return self._insert('relation_requests', request)
    
    # ========== ИГНОР-ЛИСТ ==========
    
    async def add_to_ignore(self, user_id: int, ignored_user_id: int):
        """Добавить в игнор"""
        ignore_data = {
            "user_id": user_id,
            "ignored_user_id": ignored_user_id,
            "created_at": self._now().isoformat()
        }
        self._insert('ignore_list', ignore_data)
    
    async def remove_from_ignore(self, user_id: int, ignored_user_id: int):
        """Удалить из игнора"""
        self._delete('ignore_list', user_id=user_id, ignored_user_id=ignored_user_id)
    
    async def get_ignore_list(self, user_id: int) -> list:
        """Получить игнор-лист"""
        items = self._find('ignore_list', user_id=user_id)
        return [item['ignored_user_id'] for item in items]
    
    async def is_ignored(self, user_id: int, target_id: int) -> bool:
        """Проверить, игнорирует ли target пользователя user_id"""
        items = self._find('ignore_list', user_id=target_id, ignored_user_id=user_id)
        return len(items) > 0
    
    # ========== КАСТОМНЫЕ КОМАНДЫ ==========
    
    async def add_custom_command(self, user_id: int, command: str, emoji: str, text: str) -> dict:
        """Добавить кастомную команду"""
        cmd_data = {
            "user_id": user_id,
            "command_name": command.lower(),
            "emoji": emoji,
            "text_template": text,
            "created_at": self._now().isoformat(),
            "uses": 0
        }
        return self._insert('custom_commands', cmd_data)
    
    async def get_custom_commands(self, user_id: int) -> list:
        """Получить кастомные команды пользователя"""
        return self._find('custom_commands', user_id=user_id)
    
    async def get_custom_command(self, user_id: int, command: str) -> Optional[dict]:
        """Получить конкретную кастомную команду"""
        return self._find_one('custom_commands', user_id=user_id, command_name=command.lower())
    
    async def delete_custom_command(self, user_id: int, command: str):
        """Удалить кастомную команду"""
        self._delete('custom_commands', user_id=user_id, command_name=command.lower())
    
    async def increment_command_use(self, user_id: int, command: str):
        """Увеличить счетчик использования"""
        self._update('custom_commands', 
                    {'user_id': user_id, 'command_name': command.lower()},
                    {'$inc': {'uses': 1}})
    
    # ========== ПИТОМЦЫ ==========
    
    async def create_pet(self, user_id: int, pet_type: str, rarity: str) -> dict:
        """Создать питомца"""
        personality = random.randint(-10, 10)
        
        # Потребление в зависимости от редкости
        consumption_map = {
            "обычный": {"food": random.randint(10, 20), "water": random.randint(8, 15)},
            "необычный": {"food": random.randint(12, 25), "water": random.randint(8, 18)},
            "редкий": {"food": random.randint(15, 30), "water": random.randint(10, 20)},
            "эпический": {"food": random.randint(20, 40), "water": random.randint(15, 30)},
            "легендарный": {"food": random.randint(40, 70), "water": random.randint(30, 50)}
        }
        
        cons = consumption_map.get(rarity, consumption_map["обычный"])
        
        pet = {
            "user_id": user_id,
            "pet_id": f"PET_{int(time.time())}_{random.randint(1000, 9999)}",
            "name": f"{pet_type}_{random.randint(1000, 9999)}",
            "pet_type": pet_type,
            "rarity": rarity,
            "level": 1,
            "exp": 0,
            "hp": 100,
            "mood": 80,
            "personality": personality,
            "skills": self._generate_pet_skills(rarity),
            "food_consumption": cons['food'],
            "water_consumption": cons['water'],
            "last_fed": self._now().isoformat(),
            "last_played": self._now().isoformat(),
            "created_at": self._now().isoformat(),
            "house": None,
            "house_rooms": []
        }
        
        return self._insert('pets', pet)
    
    def _generate_pet_skills(self, rarity: str) -> list:
        """Генерация навыков питомца"""
        positive_skills = [
            "spark_talisman", "cooldown_reducer", "house_economy",
            "nanny", "coupon_master", "realtor", "lucky_companion"
        ]
        
        negative_skills = [
            "gluttonous", "lazy", "spendthrift", "house_destroyer",
            "jealous", "evil_eye", "unlucky"
        ]
        
        skill_counts = {
            "обычный": 1,
            "необычный": 2,
            "редкий": 2,
            "эпический": 3,
            "легендарный": 5
        }
        
        skills = []
        count = skill_counts.get(rarity, 1)
        positive_count = max(1, random.randint(1, count))
        negative_count = count - positive_count
        
        if positive_count > 0:
            selected_positives = random.sample(positive_skills, min(positive_count, len(positive_skills)))
            for skill in selected_positives:
                skills.append({
                    "name": skill,
                    "type": "positive",
                    "level": random.randint(1, 3)
                })
        
        if negative_count > 0:
            selected_negatives = random.sample(negative_skills, min(negative_count, len(negative_skills)))
            for skill in selected_negatives:
                skills.append({
                    "name": skill,
                    "type": "negative",
                    "level": random.randint(1, 3)
                })
        
        return skills
    
    async def get_user_pets(self, user_id: int) -> list:
        """Получить всех питомцев пользователя"""
        return self._find('pets', user_id=user_id)
    
    async def get_pet(self, user_id: int, pet_id: str) -> Optional[dict]:
        """Получить конкретного питомца"""
        return self._find_one('pets', user_id=user_id, pet_id=pet_id)
    
    async def update_pet_mood(self, user_id: int, pet_id: str, change: int) -> int:
        """Обновить настроение питомца"""
        pet = await self.get_pet(user_id, pet_id)
        if not pet:
            return 0
        
        personality = pet.get('personality', 0)
        if change > 0:
            change = int(change * (1 + (personality / 100)))
        else:
            change = int(change * (1 - (personality / 100)))
        
        new_mood = max(0, min(100, pet['mood'] + change))
        
        self._update('pets', {'user_id': user_id, 'pet_id': pet_id},
                    {'$set': {'mood': new_mood}})
        
        return new_mood
    
    async def add_pet_exp(self, user_id: int, pet_id: str, exp: int) -> dict:
        """Добавить опыт питомцу"""
        pet = await self.get_pet(user_id, pet_id)
        if not pet:
            return {"level": 1, "exp": 0}
        
        new_exp = pet['exp'] + exp
        new_level = pet['level']
        
        # Проверка на повышение уровня
        while new_level < self._get_max_pet_level(pet['rarity']):
            exp_needed = self._get_pet_exp_for_level(new_level + 1)
            if new_exp >= exp_needed:
                new_level += 1
                new_exp -= exp_needed
            else:
                break
        
        self._update('pets', {'user_id': user_id, 'pet_id': pet_id}, {
            '$set': {'exp': new_exp, 'level': new_level}
        })
        
        return {"level": new_level, "exp": new_exp}
    
    def _get_pet_exp_for_level(self, level: int) -> int:
        return int(100 * (level ** 1.5))
    
    def _get_max_pet_level(self, rarity: str) -> int:
        levels = {
            "обычный": 10,
            "необычный": 20,
            "редкий": 30,
            "эпический": 40,
            "легендарный": 50
        }
        return levels.get(rarity, 10)
    
    # ========== КАЗИНО ==========
    
    async def get_casino_profile(self, user_id: int) -> Optional[dict]:
        """Получить профиль казино"""
        profile = self._find_one('casino', user_id=user_id)
        if not profile:
            profile = await self.create_casino_profile(user_id)
        return profile
    
    async def create_casino_profile(self, user_id: int) -> dict:
        """Создать профиль казино"""
        profile = {
            "user_id": user_id,
            "crabs": 10000,
            "vehicle": {
                "type": "basic",
                "level": 1,
                "power": 10,
                "fuel": 100,
                "max_fuel": 100,
                "condition": 100,
                "storage": 1,
                "storage_used": 0
            },
            "locations": {
                "beach": {"unlocked": True, "level": 1, "expeditions": 0, "total_crabs_mined": 0},
                "forest": {"unlocked": False, "level": 1, "expeditions": 0, "total_crabs_mined": 0},
                "mountains": {"unlocked": False, "level": 1, "expeditions": 0, "total_crabs_mined": 0},
                "desert": {"unlocked": False, "level": 1, "expeditions": 0, "total_crabs_mined": 0},
                "ocean": {"unlocked": False, "level": 1, "expeditions": 0, "total_crabs_mined": 0}
            },
            "inventory": {},
            "active_expedition": None,
            "stats": {
                "total_crabs_earned": 10000,
                "total_crabs_spent": 0,
                "total_expeditions": 0,
                "total_crabs_mined": 0
            },
            "created_at": self._now().isoformat()
        }
        return self._insert('casino', profile)
    
    async def add_crabs(self, user_id: int, amount: int, reason: str) -> int:
        """Добавить крабиков"""
        profile = await self.get_casino_profile(user_id)
        if not profile:
            return 0
        
        new_balance = profile['crabs'] + amount
        
        self._update('casino', {'user_id': user_id}, {
            '$set': {'crabs': new_balance},
            '$inc': {'stats.total_crabs_earned': amount}
        })
        
        return new_balance
    
    async def remove_crabs(self, user_id: int, amount: int, reason: str) -> Optional[int]:
        """Удалить крабиков"""
        profile = await self.get_casino_profile(user_id)
        if not profile or profile['crabs'] < amount:
            return None
        
        new_balance = profile['crabs'] - amount
        
        self._update('casino', {'user_id': user_id}, {
            '$set': {'crabs': new_balance},
            '$inc': {'stats.total_crabs_spent': amount}
        })
        
        return new_balance
    
    async def update_vehicle(self, user_id: int, **kwargs):
        """Обновить транспорт"""
        update_dict = {}
        for key, value in kwargs.items():
            update_dict[f"vehicle.{key}"] = value
        
        self._update('casino', {'user_id': user_id}, {'$set': update_dict})
    
    # ========== ДЕТИ ==========
    
    async def create_child(self, relation_id, name: str, gender: str) -> dict:
        """Создать ребёнка"""
        talents = random.sample(["smart", "creative", "athletic", "musical", "artistic"], 
                               min(2, random.randint(1, 3)))
        
        child = {
            "relation_id": relation_id,
            "child_id": f"CHILD_{int(time.time())}_{random.randint(1000, 9999)}",
            "name": name,
            "gender": gender,
            "age": 0,
            "stage": "newborn",
            "talents": talents,
            "health": {"status": "healthy", "conditions": []},
            "stats": {
                "intelligence": random.randint(30, 70),
                "creativity": random.randint(30, 70),
                "athletics": random.randint(30, 70),
                "social": random.randint(30, 70),
                "discipline": random.randint(30, 70)
            },
            "education": None,
            "clubs": [],
            "career": None,
            "born_at": self._now().isoformat(),
            "last_update": self._now().isoformat()
        }
        
        result = self._insert('children', child)
        
        # Увеличить счетчик детей в отношениях
        self._update('relations', {'_id': relation_id},
                    {'$inc': {'children_count': 1}})
        
        return result
    
    async def get_relation_children(self, relation_id) -> list:
        """Получить всех детей отношений"""
        return self._find('children', relation_id=relation_id)
    
    async def get_child(self, relation_id, child_id: str) -> Optional[dict]:
        """Получить конкретного ребёнка"""
        return self._find_one('children', relation_id=relation_id, child_id=child_id)
    
    async def update_child_age(self, relation_id, child_id: str) -> dict:
        """Обновить возраст ребёнка"""
        child = await self.get_child(relation_id, child_id)
        if not child:
            return {"age": 0, "stage": "unknown"}
        
        # Рассчет возраста в месяцах
        from datetime import datetime
        born = datetime.fromisoformat(child['born_at'])
        now = datetime.utcnow()
        months = (now.year - born.year) * 12 + now.month - born.month
        
        # Определение стадии
        if months < 12:
            stage = "baby"
        elif months < 36:
            stage = "toddler"
        elif months < 72:
            stage = "preschool"
        elif months < 144:
            stage = "child"
        elif months < 216:
            stage = "teenager"
        else:
            stage = "adult"
        
        self._update('children', {'relation_id': relation_id, 'child_id': child_id},
                    {'$set': {'age': months, 'stage': stage}})
        
        return {"age": months, "stage": stage}
    
    # ========== БЕРЕМЕННОСТЬ ==========
    
    async def start_pregnancy(self, relation_id) -> dict:
        """Начать беременность"""
        pregnancy = {
            "relation_id": relation_id,
            "week": 1,
            "health": 100,
            "baby_name": None,
            "baby_gender": None,
            "completed_events": [],
            "started_at": self._now().isoformat(),
            "last_update": self._now().isoformat(),
            "due_date": (self._now() + timedelta(hours=80)).isoformat(),
            "vip_assistant": False
        }
        return self._insert('pregnancies', pregnancy)
    
    async def get_pregnancy(self, relation_id) -> Optional[dict]:
        """Получить беременность"""
        return self._find_one('pregnancies', relation_id=relation_id)
    
    async def complete_pregnancy_event(self, relation_id, event_id: str, cost: int, health_effect: int):
        """Завершить событие беременности"""
        self._update('pregnancies', {'relation_id': relation_id}, {
            '$push': {
                'completed_events': {
                    'event_id': event_id,
                    'completed_at': self._now().isoformat(),
                    'cost': cost,
                    'health_effect': health_effect
                }
            },
            '$inc': {'health': health_effect}
        })
    
    async def set_baby_name(self, relation_id, name: str):
        """Установить имя ребёнка"""
        self._update('pregnancies', {'relation_id': relation_id},
                    {'$set': {'baby_name': name}})
    
    async def set_baby_gender(self, relation_id, gender: str):
        """Установить пол ребёнка"""
        self._update('pregnancies', {'relation_id': relation_id},
                    {'$set': {'baby_gender': gender}})
    
    async def buy_vip_assistant(self, relation_id):
        """Купить VIP ассистента"""
        self._update('pregnancies', {'relation_id': relation_id},
                    {'$set': {'vip_assistant': True}})

# Создаем глобальный экземпляр
db = JsonDatabase()