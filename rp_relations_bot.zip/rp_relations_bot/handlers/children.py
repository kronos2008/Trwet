import logging
import random
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from database import db
from models.child import SCHOOL_TYPES, CLUB_TYPES
from utils.decorators import require_user, require_relation, rate_limit, log_command, premium_required
from utils.helpers import format_number, get_user_mention, is_premium
from keyboards.inline import children_menu_keyboard

logger = logging.getLogger(__name__)

@require_user
@require_relation
@log_command
async def children_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Main children menu"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    
    # Get children
    children = await db.get_relation_children(relation["_id"])
    
    if not children:
        text = (
            "👶 **Дети**\n\n"
            "У вас пока нет детей.\n"
            "Чтобы завести детей, нужно:\n"
            "1. Иметь отношения 5+ уровня\n"
            "2. Использовать .секс без защиты\n"
            "3. Дождаться беременности\n"
            "4. Использовать .родить"
        )
        keyboard = [
            [InlineKeyboardButton("◀️ Назад", callback_data="menu_relations")]
        ]
    else:
        text = "👶 **Ваши дети**\n\n"
        
        for child in children:
            name = child["name"]
            age = child["age"]
            stage = child["stage"]
            stage_emoji = {
                "baby": "👶", "toddler": "🧒", "preschool": "🧒",
                "child": "🧒", "teenager": "👦", "adult": "👨"
            }.get(stage, "👤")
            
            # Get main stats
            intelligence = child.get("intelligence", 50)
            
            text += f"{stage_emoji} **{name}** ({age} мес, {stage})\n"
            text += f"  🧠 Интеллект: {intelligence}\n\n"
    
    await update.effective_message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=children_menu_keyboard(children) if children else InlineKeyboardMarkup(keyboard)
    )

@require_user
@require_relation
@log_command
async def school_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """School management"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    message = update.effective_message
    
    args = context.args
    if len(args) < 1:
        await message.reply_text(
            "❌ Использование: .школа <id ребенка> [тип школы]\n"
            "Типы: public, private, elite, sports, arts, science"
        )
        return
    
    child_id = args[0]
    
    # Get child
    child = await db.get_child(relation["_id"], child_id)
    if not child:
        await message.reply_text("❌ Ребёнок не найден")
        return
    
    if len(args) == 1:
        # Show available schools
        text = f"🏫 **Школы для {child['name']}**\n\n"
        
        for school_id, config in SCHOOL_TYPES.items():
            if config.get("premium") and not is_premium(await db.get_user(user.id)):
                continue
            
            text += f"**{config['name']}**\n"
            text += f"💰 Стоимость: {format_number(config['cost'])} искр/год\n"
            text += f"📚 Классов: {config['grades']}\n"
            text += f"📈 Бонусы: {config['bonuses']}\n\n"
        
        text += "Выберите школу: .школа <id> <тип>"
        
        await message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
        return
    
    # Enroll in school
    school_type = args[1].lower()
    
    if school_type not in SCHOOL_TYPES:
        await message.reply_text("❌ Неверный тип школы")
        return
    
    school_config = SCHOOL_TYPES[school_type]
    
    # Check premium
    if school_config.get("premium") and not is_premium(await db.get_user(user.id)):
        await message.reply_text("❌ Эта школа только для VIP пользователей")
        return
    
    # Check age
    if child["age"] < 84:  # 7 years in months
        await message.reply_text("❌ Ребёнок слишком мал для школы (нужно 7 лет)")
        return
    
    # Check cost
    cost = school_config["cost"]
    if relation["sparks"] < cost:
        await message.reply_text(f"❌ Недостаточно искр. Нужно: {format_number(cost)}")
        return
    
    # Enroll
    await db.remove_sparks(relation["_id"], cost, f"school_{child_id}")
    
    await db.db.children.update_one(
        {"relation_id": relation["_id"], "child_id": child_id},
        {"$set": {
            "education": {
                "type": school_type,
                "name": school_config["name"],
                "grade": 1,
                "enrolled_at": datetime.utcnow()
            }
        }}
    )
    
    await message.reply_text(
        f"✅ {child['name']} зачислен(а) в {school_config['name']}!"
    )

@require_user
@require_relation
@log_command
async def club_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Club/section management"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    message = update.effective_message
    
    args = context.args
    if len(args) < 1:
        await message.reply_text(
            "❌ Использование: .секция <id ребенка> [тип секции]\n"
            "Типы: sports, music, art, dance, chess, robotics, languages, theater"
        )
        return
    
    child_id = args[0]
    
    # Get child
    child = await db.get_child(relation["_id"], child_id)
    if not child:
        await message.reply_text("❌ Ребёнок не найден")
        return
    
    if len(args) == 1:
        # Show available clubs
        text = f"🎯 **Секции для {child['name']}**\n\n"
        
        # Check how many clubs child already has
        current_clubs = len(child.get("clubs", []))
        max_clubs = 3 if not is_premium(await db.get_user(user.id)) else 5
        
        text += f"Текущих секций: {current_clubs}/{max_clubs}\n\n"
        
        for club_id, config in CLUB_TYPES.items():
            text += f"**{config['name']}**\n"
            text += f"💰 Стоимость: {format_number(config['cost'])} искр/мес\n"
            text += f"📈 Бонусы: {config['bonuses']}\n\n"
        
        text += "Записать в секцию: .секция <id> <тип>"
        
        await message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
        return
    
    # Join club
    club_type = args[1].lower()
    
    if club_type not in CLUB_TYPES:
        await message.reply_text("❌ Неверный тип секции")
        return
    
    club_config = CLUB_TYPES[club_type]
    
    # Check age
    if child["age"] < 48:  # 4 years in months
        await message.reply_text("❌ Ребёнок слишком мал для секций (нужно 4 года)")
        return
    
    # Check if already in club
    current_clubs = child.get("clubs", [])
    if any(c["type"] == club_type for c in current_clubs):
        await message.reply_text("❌ Ребёнок уже в этой секции")
        return
    
    # Check limit
    max_clubs = 3 if not is_premium(await db.get_user(user.id)) else 5
    if len(current_clubs) >= max_clubs:
        await message.reply_text(f"❌ Максимум секций: {max_clubs}")
        return
    
    # Check cost
    cost = club_config["cost"]
    if relation["sparks"] < cost:
        await message.reply_text(f"❌ Недостаточно искр. Нужно: {format_number(cost)}")
        return
    
    # Join
    await db.remove_sparks(relation["_id"], cost, f"club_{child_id}")
    
    current_clubs.append({
        "type": club_type,
        "name": club_config["name"],
        "joined_at": datetime.utcnow()
    })
    
    await db.db.children.update_one(
        {"relation_id": relation["_id"], "child_id": child_id},
        {"$set": {"clubs": current_clubs}}
    )
    
    # Apply stat bonuses
    for stat, bonus in club_config["bonuses"].items():
        current = child["stats"].get(stat, 50)
        new_value = min(100, current + bonus)
        await db.db.children.update_one(
            {"relation_id": relation["_id"], "child_id": child_id},
            {"$set": {f"stats.{stat}": new_value}}
        )
    
    await message.reply_text(
        f"✅ {child['name']} записан(а) в {club_config['name']}!"
    )

@require_user
@require_relation
@log_command
async def family_event(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Organize family event"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    message = update.effective_message
    
    args = context.args
    if not args:
        await message.reply_text(
            "❌ Использование: .событие <тип>\n"
            "Типы: birthday, vacation, holiday"
        )
        return
    
    event_type = args[0].lower()
    
    # Get all children
    children = await db.get_relation_children(relation["_id"])
    if not children:
        await message.reply_text("❌ У вас нет детей")
        return
    
    # Event configs
    events = {
        "birthday": {
            "name": "🎂 День рождения",
            "cost": 2000,
            "bonus": {"all": 2},
            "description": "Организовать день рождения для всех детей"
        },
        "vacation": {
            "name": "🏖️ Семейный отпуск",
            "cost": 5000,
            "bonus": {"all": 3, "social": 5},
            "description": "Поехать всей семьёй в отпуск"
        },
        "holiday": {
            "name": "🎄 Семейный праздник",
            "cost": 3000,
            "bonus": {"all": 2, "creativity": 3},
            "description": "Отметить семейный праздник"
        }
    }
    
    if event_type not in events:
        await message.reply_text("❌ Неверный тип события")
        return
    
    event = events[event_type]
    
    # Check cost
    if relation["sparks"] < event["cost"]:
        await message.reply_text(f"❌ Недостаточно искр. Нужно: {format_number(event['cost'])}")
        return
    
    # Pay
    await db.remove_sparks(relation["_id"], event["cost"], f"family_event_{event_type}")
    
    # Apply bonuses to all children
    for child in children:
        child_id = child["child_id"]
        
        for stat, bonus in event["bonus"].items():
            if stat == "all":
                for s in ["intelligence", "creativity", "athletics", "social", "discipline"]:
                    current = child["stats"].get(s, 50)
                    new_value = min(100, current + bonus)
                    await db.db.children.update_one(
                        {"relation_id": relation["_id"], "child_id": child_id},
                        {"$set": {f"stats.{s}": new_value}}
                    )
            else:
                current = child["stats"].get(stat, 50)
                new_value = min(100, current + bonus)
                await db.db.children.update_one(
                    {"relation_id": relation["_id"], "child_id": child_id},
                    {"$set": {f"stats.{stat}": new_value}}
                )
    
    partner_id = relation["user2_id"] if relation["user1_id"] == user.id else relation["user1_id"]
    user_mention = get_user_mention(user)
    partner_mention = get_user_mention({"user_id": partner_id, "first_name": "Партнёр"})
    
    await message.reply_text(
        f"{event['name']} {user_mention} и {partner_mention} организовали для детей!\n\n"
        f"✨ Все дети получили +{event['bonus']} к характеристикам",
        parse_mode=ParseMode.MARKDOWN
    )

@require_user
@require_relation
@log_command
async def career_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Career for adult children"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    message = update.effective_message
    
    args = context.args
    if len(args) < 1:
        await message.reply_text(
            "❌ Использование: .карьера <id ребенка>"
        )
        return
    
    child_id = args[0]
    
    # Get child
    child = await db.get_child(relation["_id"], child_id)
    if not child:
        await message.reply_text("❌ Ребёнок не найден")
        return
    
    # Check age
    if child["age"] < 216:  # 18 years in months
        await message.reply_text("❌ Ребёнок слишком молод для карьеры (нужно 18 лет)")
        return
    
    # Check if already has career
    if child.get("career"):
        career = child["career"]
        await message.reply_text(
            f"👔 Текущая карьера {child['name']}: {career['name']}\n"
            f"Уровень: {career['level']}\n"
            f"Зарплата: {format_number(career['salary'])} искр/мес"
        )
        return
    
    # Career options based on stats
    stats = child["stats"]
    
    careers = [
        {
            "name": "👨‍🔬 Учёный",
            "requirements": {"intelligence": 80},
            "salary": 5000,
            "bonus": {"intelligence": 2}
        },
        {
            "name": "👨‍🎨 Художник",
            "requirements": {"creativity": 80},
            "salary": 4000,
            "bonus": {"creativity": 2}
        },
        {
            "name": "👨‍🏫 Учитель",
            "requirements": {"intelligence": 70, "social": 60},
            "salary": 3500,
            "bonus": {"intelligence": 1, "social": 1}
        },
        {
            "name": "👨‍⚕️ Врач",
            "requirements": {"intelligence": 85, "discipline": 80},
            "salary": 7000,
            "bonus": {"intelligence": 2, "discipline": 1}
        },
        {
            "name": "👨‍💻 Программист",
            "requirements": {"intelligence": 90},
            "salary": 8000,
            "bonus": {"intelligence": 3}
        },
        {
            "name": "👨‍🔧 Инженер",
            "requirements": {"intelligence": 75, "discipline": 70},
            "salary": 6000,
            "bonus": {"intelligence": 2}
        },
        {
            "name": "👨‍🍳 Шеф-повар",
            "requirements": {"creativity": 75, "discipline": 70},
            "salary": 4500,
            "bonus": {"creativity": 2}
        },
        {
            "name": "👮 Полицейский",
            "requirements": {"athletics": 70, "discipline": 80},
            "salary": 4000,
            "bonus": {"athletics": 2, "discipline": 1}
        },
        {
            "name": "👨‍🚒 Пожарный",
            "requirements": {"athletics": 80, "discipline": 70},
            "salary": 4500,
            "bonus": {"athletics": 2}
        },
        {
            "name": "👨‍✈️ Пилот",
            "requirements": {"intelligence": 75, "discipline": 85},
            "salary": 9000,
            "bonus": {"discipline": 2}
        }
    ]
    
    # Filter available careers
    available = []
    for career in careers:
        meets_requirements = True
        for stat, req in career["requirements"].items():
            if stats.get(stat, 0) < req:
                meets_requirements = False
                break
        
        if meets_requirements:
            available.append(career)
    
    if not available:
        await message.reply_text(
            "❌ К сожалению, ваш ребёнок не соответствует требованиям ни для одной карьеры.\n"
            "Продолжайте развивать характеристики!"
        )
        return
    
    # Show options
    text = f"👔 **Доступные карьеры для {child['name']}**\n\n"
    
    for i, career in enumerate(available[:5], 1):
        text += f"{i}. **{career['name']}**\n"
        text += f"   Требования: {career['requirements']}\n"
        text += f"   💰 Зарплата: {format_number(career['salary'])} искр/мес\n"
        text += f"   📈 Бонусы: {career['bonus']}\n\n"
    
    text += "Выберите карьеру: .карьера выбрать <id ребенка> <номер>"
    
    await message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle children callbacks"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "menu_children":
        await children_menu(update, context)
    
    elif data.startswith("child_select_"):
        child_id = data.split("_")[2]
        
        # Show child profile
        user = update.effective_user
        # Need relation in context
        # This would need proper relation handling
        await query.edit_message_text(f"👶 Профиль ребёнка {child_id}")
    
    elif data == "child_event":
        await family_event(update, context)
    
    elif data == "child_report":
        # Generate report for all children
        user = update.effective_user
        # Need relation
        await query.edit_message_text("📊 Генерация отчёта...")