import logging
import random
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from database import db
from utils.decorators import require_user, require_relation, rate_limit, log_command, premium_required
from utils.helpers import format_number, get_user_mention, is_premium
from keyboards.inline import confirmation_keyboard

logger = logging.getLogger(__name__)

@require_user
@require_relation
@log_command
async def pregnancy_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View pregnancy info"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    
    # Get pregnancy
    pregnancy = await db.get_pregnancy(relation["_id"])
    
    if not pregnancy:
        await update.effective_message.reply_text(
            "🤰 У вас нет активной беременности.\n"
            "Чтобы забеременеть, используйте .секс без защиты в отношениях 5+ уровня"
        )
        return
    
    week = pregnancy["week"]
    health = pregnancy["health"]
    baby_name = pregnancy.get("baby_name", "Не указано")
    baby_gender = pregnancy.get("baby_gender", "Неизвестно")
    
    # Calculate progress
    progress = (week / 40) * 100
    progress_bar = "█" * (int(progress) // 5) + "░" * (20 - (int(progress) // 5))
    
    # Check if VIP
    premium = is_premium(await db.get_user(user.id)) or is_premium(await db.get_user(
        relation["user2_id"] if relation["user1_id"] == user.id else relation["user1_id"]
    ))
    
    time_per_week = 1 if premium else 2  # hours per week
    weeks_left = 40 - week
    hours_left = weeks_left * time_per_week
    
    text = (
        f"🤰 **Беременность**\n\n"
        f"📅 Неделя: {week}/40\n"
        f"{progress_bar} {int(progress)}%\n\n"
        
        f"❤️ Здоровье: {health}%\n"
        f"👶 Имя: {baby_name}\n"
        f"⚥ Пол: {baby_gender}\n\n"
        
        f"⏳ Осталось: {weeks_left} недель (~{hours_left} часов)\n\n"
        
        f"**События беременности**\n"
        f"Используйте .беременность сб для списка доступных событий"
    )
    
    # Check if VIP assistant
    if pregnancy.get("vip_assistant"):
        text += "\n\n🐝 Пчёлка-помощница активна! События выполняются автоматически."
    
    # Birth button if ready
    keyboard = []
    if week >= 40:
        keyboard.append([InlineKeyboardButton("👶 Родить", callback_data="preg_birth")])
    
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="menu_relations")])
    
    await update.effective_message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard) if keyboard else None
    )

@require_user
@require_relation
@log_command
async def pregnancy_events(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List pregnancy events"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    
    # Get pregnancy
    pregnancy = await db.get_pregnancy(relation["_id"])
    
    if not pregnancy:
        await update.effective_message.reply_text("❌ Нет активной беременности")
        return
    
    week = pregnancy["week"]
    
    # Events based on week
    events = [
        {
            "id": "ultrasound",
            "week": 12,
            "name": "🏥 УЗИ",
            "cost": 500,
            "health": 2,
            "description": "Первое УЗИ - увидеть малыша"
        },
        {
            "id": "vitamins",
            "week": 8,
            "name": "💊 Витамины",
            "cost": 200,
            "health": 3,
            "description": "Приём витаминов для здоровья"
        },
        {
            "id": "doctor",
            "week": 16,
            "name": "👨‍⚕️ Врач",
            "cost": 300,
            "health": 2,
            "description": "Плановый осмотр у врача"
        },
        {
            "id": "gender",
            "week": 16,
            "name": "⚥ Определение пола",
            "cost": 400,
            "health": 0,
            "description": "Узнать пол будущего ребёнка"
        },
        {
            "id": "yoga",
            "week": 20,
            "name": "🧘 Йога для беременных",
            "cost": 250,
            "health": 4,
            "description": "Занятия йогой"
        },
        {
            "id": "swimming",
            "week": 24,
            "name": "🏊‍♀️ Плавание",
            "cost": 300,
            "health": 3,
            "description": "Плавание для будущих мам"
        },
        {
            "id": "courses",
            "week": 28,
            "name": "📚 Курсы для родителей",
            "cost": 600,
            "health": 2,
            "description": "Подготовка к родам"
        },
        {
            "id": "massage",
            "week": 32,
            "name": "💆 Массаж",
            "cost": 400,
            "health": 3,
            "description": "Расслабляющий массаж"
        },
        {
            "id": "hospital",
            "week": 36,
            "name": "🏥 Выбор роддома",
            "cost": 1000,
            "health": 5,
            "description": "Выбрать и оплатить роддом"
        }
    ]
    
    # Filter available events
    available = [e for e in events if e["week"] <= week and e["id"] not in pregnancy.get("completed_events", [])]
    
    if not available:
        await update.effective_message.reply_text(
            "✅ Все события на данный момент выполнены!\n"
            "Отдыхайте и ждите следующих недель."
        )
        return
    
    text = "📋 **Доступные события**\n\n"
    
    for event in available:
        text += f"**{event['name']}** (неделя {event['week']})\n"
        text += f"💰 Стоимость: {format_number(event['cost'])} искр\n"
        text += f"❤️ Здоровье: +{event['health']}%\n"
        text += f"📝 {event['description']}\n\n"
    
    text += "Выполнить событие: .беременность сб <id>\n"
    text += "Пример: .беременность сб ultrasound"
    
    await update.effective_message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

@require_user
@require_relation
@log_command
async def do_pregnancy_event(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Perform a pregnancy event"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    message = update.effective_message
    
    args = context.args
    if len(args) < 1:
        await message.reply_text("❌ Укажите ID события")
        return
    
    event_id = args[0].lower()
    
    # Get pregnancy
    pregnancy = await db.get_pregnancy(relation["_id"])
    
    if not pregnancy:
        await message.reply_text("❌ Нет активной беременности")
        return
    
    # Define events
    events = {
        "ultrasound": {"name": "УЗИ", "cost": 500, "health": 2},
        "vitamins": {"name": "Витамины", "cost": 200, "health": 3},
        "doctor": {"name": "Врач", "cost": 300, "health": 2},
        "gender": {"name": "Определение пола", "cost": 400, "health": 0},
        "yoga": {"name": "Йога", "cost": 250, "health": 4},
        "swimming": {"name": "Плавание", "cost": 300, "health": 3},
        "courses": {"name": "Курсы", "cost": 600, "health": 2},
        "massage": {"name": "Массаж", "cost": 400, "health": 3},
        "hospital": {"name": "Роддом", "cost": 1000, "health": 5}
    }
    
    if event_id not in events:
        await message.reply_text("❌ Неверный ID события")
        return
    
    event = events[event_id]
    
    # Check if already completed
    if event_id in pregnancy.get("completed_events", []):
        await message.reply_text("❌ Это событие уже выполнено")
        return
    
    # Check cost
    if relation["sparks"] < event["cost"]:
        await message.reply_text(f"❌ Недостаточно искр. Нужно: {format_number(event['cost'])}")
        return
    
    # Special handling for gender reveal
    if event_id == "gender" and not pregnancy.get("baby_gender"):
        gender = random.choice(["👦 Мальчик", "👧 Девочка"])
        await db.set_baby_gender(relation["_id"], gender)
        gender_text = f"\n\n⚥ Пол ребёнка: {gender}!"
    else:
        gender_text = ""
    
    # Complete event
    await db.complete_pregnancy_event(
        relation["_id"],
        event_id,
        event["cost"],
        event["health"]
    )
    
    await db.remove_sparks(relation["_id"], event["cost"], f"pregnancy_{event_id}")
    
    await message.reply_text(
        f"✅ Событие **{event['name']}** выполнено!\n"
        f"❤️ Здоровье +{event['health']}%{gender_text}",
        parse_mode=ParseMode.MARKDOWN
    )

@require_user
@require_relation
@log_command
async def give_birth(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Give birth to child"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    message = update.effective_message
    
    # Get pregnancy
    pregnancy = await db.get_pregnancy(relation["_id"])
    
    if not pregnancy:
        await message.reply_text("❌ Нет активной беременности")
        return
    
    if pregnancy["week"] < 40:
        await message.reply_text(f"❌ Ещё рано. Неделя {pregnancy['week']}/40")
        return
    
    # Get target user (the child)
    target_id, target_mention = extract_user(message)
    
    if not target_id:
        await message.reply_text(
            "❌ Укажите пользователя, который станет вашим ребёнком\n"
            "Пример: .родить @username"
        )
        return
    
    # Check if target is valid (not bot, not self, etc)
    if target_id == user.id:
        await message.reply_text("❌ Нельзя родить самого себя")
        return
    
    partner_id = relation["user2_id"] if relation["user1_id"] == user.id else relation["user1_id"]
    
    # Get baby name
    baby_name = pregnancy.get("baby_name")
    if not baby_name:
        await message.reply_text(
            "❌ Сначала дайте имя ребёнку:\n"
            ".беременность имя <имя>"
        )
        return
    
    # Get baby gender
    baby_gender = pregnancy.get("baby_gender", "Неизвестно")
    
    # Check child limit
    children = await db.get_relation_children(relation["_id"])
    premium = is_premium(await db.get_user(user.id)) or is_premium(await db.get_user(partner_id))
    max_children = 30 if premium else 10
    
    if len(children) >= max_children:
        await message.reply_text(f"❌ Достигнут лимит детей ({max_children})")
        return
    
    # Create child
    child = await db.create_child(relation["_id"], baby_name, baby_gender)
    
    # Remove pregnancy
    await db.db.pregnancies.delete_one({"relation_id": relation["_id"]})
    
    # Notify
    user_mention = get_user_mention(user)
    partner_mention = get_user_mention({"user_id": partner_id, "first_name": "Партнёр"})
    
    await message.reply_text(
        f"👶 **Поздравляем!**\n\n"
        f"{user_mention} и {partner_mention}, у вас родился ребёнок!\n\n"
        f"Имя: {baby_name}\n"
        f"Пол: {baby_gender}\n"
        f"ID: `{child['child_id']}`\n\n"
        f"Используйте .ребенок для воспитания"
    )
    
    # Notify the child
    try:
        await context.bot.send_message(
            target_id,
            f"👋 Привет! Ты родился в семье {user_mention} и {partner_mention}!\n"
            f"Твоё имя: {baby_name}\n"
            f"Твой ID: `{child['child_id']}`",
            parse_mode=ParseMode.MARKDOWN
        )
    except:
        pass

@require_user
@require_relation
@log_command
async def abortion(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Abort pregnancy"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    message = update.effective_message
    
    # Get pregnancy
    pregnancy = await db.get_pregnancy(relation["_id"])
    
    if not pregnancy:
        await message.reply_text("❌ Нет активной беременности")
        return
    
    if pregnancy["week"] > 20:
        await message.reply_text("❌ Аборт возможен только до 20 недели")
        return
    
    # Ask for confirmation
    keyboard = confirmation_keyboard("abort", str(relation["_id"]))
    
    await message.reply_text(
        "⚠️ **Вы уверены?**\n\n"
        "Это действие необратимо. Беременность будет прервана.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=keyboard
    )

@require_user
@require_relation
@premium_required
@log_command
async def buy_assistant(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Buy VIP pregnancy assistant"""
    user = update.effective_user
    relation = context.user_data['current_relation']
    message = update.effective_message
    
    # Get pregnancy
    pregnancy = await db.get_pregnancy(relation["_id"])
    
    if not pregnancy:
        await message.reply_text("❌ Нет активной беременности")
        return
    
    if pregnancy.get("vip_assistant"):
        await message.reply_text("🐝 Пчёлка-помощница уже активна")
        return
    
    # Check cost
    cost = 5000
    if relation["sparks"] < cost:
        await message.reply_text(f"❌ Недостаточно искр. Нужно: {format_number(cost)}")
        return
    
    # Buy
    await db.remove_sparks(relation["_id"], cost, "buy_assistant")
    await db.buy_vip_assistant(relation["_id"])
    
    await message.reply_text(
        "🐝 **Пчёлка-помощница куплена!**\n\n"
        "Она будет автоматически выполнять все доступные события беременности каждый час."
    )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle pregnancy callbacks"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "preg_birth":
        await give_birth(update, context)
    
    elif data.startswith("confirm_abort_"):
        relation_id = data.split("_")[2]
        
        # Delete pregnancy
        await db.db.pregnancies.delete_one({"relation_id": relation_id})
        
        # Apply cooldown
        # Regular: 5 days, VIP: 2 days
        premium = is_premium(await db.get_user(update.effective_user.id))
        cooldown_days = 2 if premium else 5
        
        # Store cooldown
        await db.db.abortion_cooldown.insert_one({
            "relation_id": relation_id,
            "until": datetime.utcnow() + timedelta(days=cooldown_days)
        })
        
        await query.edit_message_text(
            f"✅ Беременность прервана.\n"
            f"Следующая беременность возможна через {cooldown_days} дней."
        )
    
    elif data.startswith("cancel_abort"):
        await query.edit_message_text("❌ Отменено")