from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel, Field

class VehicleModel(BaseModel):
    """Vehicle model"""
    type: str
    level: int = 1
    power: int
    fuel: int
    max_fuel: int
    condition: int = 100
    storage: int
    storage_used: int = 0
    
    @property
    def vehicle_config(self):
        """Get vehicle configuration"""
        from utils.constants import VEHICLE_TYPES
        return VEHICLE_TYPES.get(self.type, VEHICLE_TYPES["basic"])
    
    @property
    def max_power(self) -> int:
        """Get max power based on level"""
        base_power = self.vehicle_config.get("power", 10)
        return base_power + (self.level - 1) * 5
    
    @property
    def max_storage(self) -> int:
        """Get max storage based on level"""
        base_storage = self.vehicle_config.get("storage", 1)
        return base_storage + (self.level - 1)
    
    @property
    def fuel_cost_per_liter(self) -> int:
        """Get fuel cost per liter"""
        from config import Config
        vehicle_price = self.vehicle_config.get("price", 0)
        cost = int(vehicle_price * Config.CASINO_FUEL_COST_PERCENT)
        return min(cost, Config.CASINO_MAX_FUEL_COST)
    
    @property
    def repair_cost(self) -> int:
        """Get repair cost"""
        from config import Config
        vehicle_price = self.vehicle_config.get("price", 0)
        damage = 100 - self.condition
        cost = int(vehicle_price * Config.CASINO_REPAIR_COST_PERCENT * (damage / 100))
        return min(cost, Config.CASINO_MAX_REPAIR_COST)
    
    def can_access_location(self, required_power: int) -> bool:
        """Check if vehicle can access location"""
        return self.max_power >= required_power
    
    def use_fuel(self, amount: int) -> bool:
        """Use fuel"""
        if self.fuel < amount:
            return False
        self.fuel -= amount
        return True
    
    def refuel(self, amount: int):
        """Add fuel"""
        self.fuel = min(self.max_fuel, self.fuel + amount)
    
    def take_damage(self, amount: int):
        """Take damage"""
        self.condition = max(0, self.condition - amount)
    
    def repair(self, amount: int):
        """Repair vehicle"""
        self.condition = min(100, self.condition + amount)

class LocationModel(BaseModel):
    """Location model"""
    location_id: str
    unlocked: bool = False
    level: int = 1
    expeditions: int = 0
    total_crabs_mined: int = 0
    
    @property
    def location_config(self):
        """Get location configuration"""
        from utils.constants import CASINO_LOCATIONS
        return CASINO_LOCATIONS.get(self.location_id, {})
    
    @property
    def name(self) -> str:
        """Get location name"""
        return self.location_config.get("name", self.location_id)
    
    @property
    def required_power(self) -> int:
        """Get required power"""
        return self.location_config.get("min_power", 1) * self.level
    
    @property
    def max_crabs(self) -> int:
        """Get max crabs per trip"""
        base = self.location_config.get("max_crabs_per_trip", 1000)
        return base * self.level
    
    @property
    def fuel_cost(self) -> int:
        """Get fuel cost"""
        base = self.location_config.get("fuel_cost", 10)
        return base * self.level
    
    @property
    def duration_minutes(self) -> int:
        """Get duration in minutes"""
        base = self.location_config.get("duration", 60)
        return base

class CasinoProfileModel(BaseModel):
    """Casino profile model"""
    user_id: int
    crabs: int
    vehicle: VehicleModel
    locations: Dict[str, LocationModel] = Field(default_factory=dict)
    inventory: Dict[str, int] = Field(default_factory=dict)
    
    stats: Dict = Field(default_factory=lambda: {
        "total_crabs_earned": 0,
        "total_crabs_spent": 0,
        "total_expeditions": 0,
        "total_crabs_mined": 0,
        "roulette_wins": 0,
        "roulette_losses": 0,
        "dynamite_wins": 0,
        "dynamite_losses": 0
    })
    
    active_expedition: Optional[Dict] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        arbitrary_types_allowed = True
    
    def can_afford(self, amount: int) -> bool:
        """Check if can afford amount"""
        return self.crabs >= amount
    
    def add_crabs(self, amount: int, reason: str):
        """Add crabs to balance"""
        self.crabs += amount
        self.stats["total_crabs_earned"] += amount
        self.stats["total_crabs_mined"] += amount if "mine" in reason else 0
    
    def remove_crabs(self, amount: int, reason: str) -> bool:
        """Remove crabs from balance"""
        if not self.can_afford(amount):
            return False
        self.crabs -= amount
        self.stats["total_crabs_spent"] += amount
        return True
    
    def start_expedition(self, location_id: str):
        """Start an expedition"""
        location = self.locations.get(location_id)
        if not location or not location.unlocked:
            return False
        
        self.active_expedition = {
            "location": location_id,
            "started_at": datetime.utcnow(),
            "duration": location.duration_minutes
        }
        return True
    
    def complete_expedition(self) -> Optional[int]:
        """Complete active expedition"""
        if not self.active_expedition:
            return None
        
        location_id = self.active_expedition["location"]
        location = self.locations.get(location_id)
        
        if not location:
            return None
        
        # Calculate crabs mined
        import random
        crabs_mined = random.randint(
            location.max_crabs // 2,
            location.max_crabs
        )
        
        # Update stats
        self.stats["total_expeditions"] += 1
        self.stats["total_crabs_mined"] += crabs_mined
        self.crabs += crabs_mined
        
        # Update location stats
        location.expeditions += 1
        location.total_crabs_mined += crabs_mined
        
        # Clear expedition
        self.active_expedition = None
        
        return crabs_mined

# Inventory items
INVENTORY_ITEMS = {
    "fuel": {
        "name": "⛽ Топливо",
        "price": 100,
        "description": "Используется для поездок в локации"
    },
    "repair_kit": {
        "name": "🔧 Ремкомплект",
        "price": 500,
        "description": "Восстанавливает 10% прочности транспорта"
    },
    "storage_upgrade": {
        "name": "📦 Улучшение хранилища",
        "price": 10000,
        "description": "Увеличивает хранилище на 1 слот"
    },
    "power_upgrade": {
        "name": "⚡ Улучшение двигателя",
        "price": 20000,
        "description": "Увеличивает мощность на 5"
    },
    "lucky_charm": {
        "name": "🍀 Амулет удачи",
        "price": 5000,
        "description": "+10% к добыче крабиков"
    },
    "map": {
        "name": "🗺️ Карта локации",
        "price": 3000,
        "description": "Открывает новую локацию"
    }
}