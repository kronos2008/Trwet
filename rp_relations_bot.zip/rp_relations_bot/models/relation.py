from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel, Field

class RelationModel(BaseModel):
    """Relation model"""
    user1_id: int
    user2_id: int
    chat_id: int
    level: int = 1
    sparks: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_interaction: datetime = Field(default_factory=datetime.utcnow)
    status: str = "active"  # active, ended
    children_count: int = 0
    total_sparks_earned: int = 0
    
    history: List[Dict] = Field(default_factory=list)
    
    # Offense mechanic
    offended_by: Optional[int] = None
    offended_until: Optional[datetime] = None
    
    # Protection
    protection_used: bool = False  # For VIP one-time protection
    
    class Config:
        arbitrary_types_allowed = True
    
    @property
    def partner_id(self, user_id: int) -> int:
        """Get partner ID"""
        return self.user2_id if self.user1_id == user_id else self.user1_id
    
    def get_level_name(self) -> str:
        """Get level name"""
        from utils.constants import RELATION_LEVELS
        
        for lvl, name in sorted(RELATION_LEVELS.items(), reverse=True):
            if self.level >= lvl:
                return name
        return "✨ Начало отношений"
    
    @property
    def sparks_to_next_level(self) -> int:
        """Get sparks needed for next level"""
        # Simplified level requirements
        level_req = {
            1: 100, 2: 500, 3: 1000, 4: 2000, 5: 3500,
            6: 5500, 7: 8000, 8: 11000, 9: 15000, 10: 20000,
            11: 26000, 12: 33000, 13: 41000, 14: 50000, 15: 60000,
            16: 71000, 17: 83000, 18: 96000, 19: 110000, 20: 125000,
            21: 141000, 22: 158000, 23: 176000, 24: 195000, 25: 215000,
            26: 236000, 27: 258000, 28: 281000, 29: 305000, 30: 330000
        }
        
        if self.level >= 30:
            return 0
        
        required = level_req.get(self.level + 1, 0)
        return max(0, required - self.sparks)
    
    @property
    def progress_percent(self) -> int:
        """Get progress percentage to next level"""
        if self.level >= 30:
            return 100
        
        # Simplified calculation
        level_req = {
            1: 100, 2: 500, 3: 1000, 4: 2000, 5: 3500,
            6: 5500, 7: 8000, 8: 11000, 9: 15000, 10: 20000,
            11: 26000, 12: 33000, 13: 41000, 14: 50000, 15: 60000,
            16: 71000, 17: 83000, 18: 96000, 19: 110000, 20: 125000,
            21: 141000, 22: 158000, 23: 176000, 24: 195000, 25: 215000,
            26: 236000, 27: 258000, 28: 281000, 29: 305000, 30: 330000
        }
        
        current_req = level_req.get(self.level, 0)
        next_req = level_req.get(self.level + 1, 0)
        
        if next_req == 0:
            return 100
        
        progress = self.sparks - current_req
        total = next_req - current_req
        
        return int((progress / total) * 100)

class RelationRequestModel(BaseModel):
    """Relation request model"""
    from_user: int
    to_user: int
    chat_id: int
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: datetime
    status: str = "pending"  # pending, accepted, declined, expired