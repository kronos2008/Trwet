from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel, Field

class UserModel(BaseModel):
    """User model"""
    user_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    gender: Optional[str] = None  # m/f
    nickname: Optional[str] = None
    vip_until: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    stats: Dict = Field(default_factory=lambda: {
        "total_sparks_earned": 0,
        "total_commands_used": 0,
        "total_relations": 0,
        "total_pets": 0,
        "total_children": 0
    })
    
    settings: Dict = Field(default_factory=lambda: {
        "notifications": True,
        "language": "ru"
    })
    
    class Config:
        arbitrary_types_allowed = True
    
    @property
    def is_vip(self) -> bool:
        """Check if user has active VIP"""
        if not self.vip_until:
            return False
        return self.vip_until > datetime.utcnow()
    
    @property
    def display_name(self) -> str:
        """Get display name (nickname or first name)"""
        if self.nickname:
            return self.nickname
        if self.first_name:
            return self.first_name
        return f"User{self.user_id}"
    
    def get_mention(self) -> str:
        """Get markdown mention"""
        return f"[{self.display_name}](tg://user?id={self.user_id})"

class CustomCommandModel(BaseModel):
    """Custom RP command model"""
    user_id: int
    command_name: str
    emoji: str
    text_template: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    uses: int = 0
    
    def format(self, user_mention: str, target_mention: str) -> str:
        """Format command with mentions"""
        text = self.text_template
        text = text.replace('%u', user_mention)
        text = text.replace('%t', target_mention)
        return f"{self.emoji} {text}"

class IgnoreModel(BaseModel):
    """Ignore list model"""
    user_id: int
    ignored_user_id: int
    created_at: datetime = Field(default_factory=datetime.utcnow)