import logging
import re
import emoji
from datetime import datetime, timedelta
from typing import Union, Optional, Tuple
from telegram import Update, User
from telegram.ext import ContextTypes

def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        level=logging.INFO
    )
    return logging.getLogger(__name__)

logger = logging.getLogger(__name__)

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle errors"""
    logger.error(f"Exception while handling an update: {context.error}")
    
    # Notify user
    if update and update.effective_message:
        await update.effective_message.reply_text(
            "❌ Произошла ошибка. Разработчики уже уведомлены."
        )

def extract_user(message) -> Optional[Tuple[int, str]]:
    """
    Extract user from message (reply, mention, or uid)
    Returns (user_id, mention_text)
    """
    # Check reply
    if message.reply_to_message:
        user = message.reply_to_message.from_user
        return user.id, f"[{user.first_name}](tg://user?id={user.id})"
    
    # Check text for mentions
    if message.text:
        # Check for uid:123456
        uid_match = re.search(r'uid:(\d+)', message.text)
        if uid_match:
            user_id = int(uid_match.group(1))
            return user_id, f"[Пользователь](tg://user?id={user_id})"
        
        # Check for @username
        mention_match = re.search(r'@(\w+)', message.text)
        if mention_match:
            # We can't get user_id from username without entities, return None
            pass
        
        # Check for entities
        if message.entities:
            for entity in message.entities:
                if entity.type == "text_mention" and entity.user:
                    return entity.user.id, f"[{entity.user.first_name}](tg://user?id={entity.user.id})"
    
    return None, None

def format_duration(seconds: int) -> str:
    """Format seconds into readable duration"""
    if seconds < 60:
        return f"{seconds} сек"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes} мин"
    elif seconds < 86400:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return f"{hours} ч {minutes} мин"
    else:
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        return f"{days} д {hours} ч"

def validate_emoji_string(text: str) -> bool:
    """Validate that string contains only emojis"""
    if not text:
        return False
    
    # Remove zero-width joiners and variation selectors
    clean_text = text.strip()
    
    # Check each character
    for char in clean_text:
        if not emoji.is_emoji(char):
            return False
    
    # Max 4 emojis
    if len(clean_text) > 4:
        return False
    
    return True

def validate_command_name(name: str) -> bool:
    """Validate custom command name"""
    if not name or len(name) > 20:
        return False
    
    # Only letters, numbers, underscore
    return bool(re.match(r'^[a-zA-Zа-яА-Я0-9_]+$', name))

def validate_command_template(template: str) -> bool:
    """Validate custom command template"""
    if not template or len(template) > 200:
        return False
    
    # Must contain at least one %u and one %t
    if '%u' not in template or '%t' not in template:
        return False
    
    return True

async def check_ignore_list(context: ContextTypes.DEFAULT_TYPE, 
                           user_id: int, target_id: int) -> bool:
    """Check if user is ignored by target"""
    from database import db
    return await db.is_ignored(user_id, target_id)

def calculate_spark_cost(level: int, children: int = 0, premium: bool = False) -> int:
    """Calculate daily spark cost for relation"""
    # Find the right formula
    if level <= 5:
        cost = 15 * level
    elif level <= 10:
        cost = 50 * level + 50
    elif level <= 15:
        cost = 80 * level + 200
    elif level <= 20:
        cost = 150 * level + 500
    elif level <= 25:
        cost = 300 * level + 1500
    else:
        cost = 500 * level + 3000
    
    # Add children penalty (10% each)
    if children > 0:
        cost = int(cost * (1 + children * 0.1))
    
    # Premium discount (30%)
    if premium:
        cost = int(cost * 0.7)
    
    return cost

def get_user_mention(user: Union[User, dict]) -> str:
    """Get markdown mention for user"""
    if isinstance(user, dict):
        name = user.get('first_name', 'Пользователь')
        user_id = user.get('user_id')
    else:
        name = user.first_name
        user_id = user.id
    
    return f"[{name}](tg://user?id={user_id})"

def parse_time_string(time_str: str) -> Optional[int]:
    """
    Parse time string like '10m', '2h', '3d' into seconds
    """
    if not time_str:
        return None
    
    match = re.match(r'^(\d+)([mhd]?)$', time_str.lower())
    if not match:
        return None
    
    value = int(match.group(1))
    unit = match.group(2)
    
    if unit == 'm':
        return value * 60
    elif unit == 'h':
        return value * 3600
    elif unit == 'd':
        return value * 86400
    else:
        return value  # Default to minutes if no unit
    
def is_premium(user_data: dict) -> bool:
    """Check if user has premium status"""
    vip_until = user_data.get('vip_until')
    if not vip_until:
        return False
    
    # Check if VIP is still valid
    if isinstance(vip_until, datetime):
        return vip_until > datetime.utcnow()
    
    return False

def calculate_spark_reward(base: int, 
                          prestige: int = 0, 
                          premium: bool = False,
                          pet_bonus: float = 1.0) -> int:
    """Calculate spark reward with bonuses"""
    # Prestige bonus (0.2% per point)
    if prestige > 0:
        base = int(base * (1 + prestige * 0.002))
    
    # Premium bonus (25%)
    if premium:
        base = int(base * 1.25)
    
    # Pet bonus
    base = int(base * pet_bonus)
    
    return base

def format_number(num: int) -> str:
    """Format number with spaces"""
    return f"{num:,}".replace(",", " ")

def get_level_name(level: int) -> str:
    """Get level name"""
    from utils.constants import RELATION_LEVELS
    
    # Find the highest level reached
    for lvl, name in sorted(RELATION_LEVELS.items(), reverse=True):
        if level >= lvl:
            return name
    
    return "✨ Начало отношений"