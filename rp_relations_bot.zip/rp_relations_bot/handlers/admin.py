import logging
from datetime import datetime, timedelta
from telegram import Update, ChatPermissions
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from database import db
from config import Config
from utils.decorators import admin_only, log_command
from utils.helpers import extract_user, parse_time_string

logger = logging.getLogger(__name__)

@admin_only
@log_command
async def mute_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mute user in chat"""
    message = update.effective_message
    chat = update.effective_chat
    
    if chat.type == 'private':
        await message.reply_text("❌ Эта команда работает только в группах")
        return
    
    args = context.args
    if len(args) < 2:
        await message.reply_text(
            "❌ Использование: .мут <время> <пользователь>\n"
            "Пример: .мут 10m @user\n"
            "Форматы: 10m (минуты), 2h (часы), 1d (дни)"
        )
        return
    
    # Parse time
    time_str = args[0]
    mute_seconds = parse_time_string(time_str)
    
    if not mute_seconds:
        await message.reply_text("❌ Неверный формат времени. Используйте 10m, 2h, 1d")
        return
    
    # Extract user
    # Reconstruct message text for extraction
    message.text = ' '.join(args[1:])
    target_id, target_mention = extract_user(message)
    
    if not target_id:
        await message.reply_text("❌ Укажите пользователя")
        return
    
    try:
        # Check if user is admin
        member = await chat.get_member(target_id)
        if member.status in ['creator', 'administrator']:
            await message.reply_text("❌ Нельзя замутить администратора")
            return
        
        # Mute user
        until_date = datetime.now() + timedelta(seconds=mute_seconds)
        permissions = ChatPermissions(can_send_messages=False)
        
        await chat.restrict_member(
            target_id,
            permissions,
            until_date=until_date
        )
        
        # Format time for display
        if mute_seconds < 60:
            time_display = f"{mute_seconds} сек"
        elif mute_seconds < 3600:
            time_display = f"{mute_seconds // 60} мин"
        elif mute_seconds < 86400:
            time_display = f"{mute_seconds // 3600} ч"
        else:
            time_display = f"{mute_seconds // 86400} д"
        
        await message.reply_text(
            f"🔇 Пользователь {target_mention} замучен на {time_display}",
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Log to database
        await db.db.admin_actions.insert_one({
            "chat_id": chat.id,
            "admin_id": update.effective_user.id,
            "action": "mute",
            "target_id": target_id,
            "duration": mute_seconds,
            "timestamp": datetime.utcnow()
        })
        
    except Exception as e:
        await message.reply_text(f"❌ Ошибка: {e}")

@admin_only
@log_command
async def unmute_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unmute user in chat"""
    message = update.effective_message
    chat = update.effective_chat
    
    if chat.type == 'private':
        await message.reply_text("❌ Эта команда работает только в группах")
        return
    
    # Extract user
    target_id, target_mention = extract_user(message)
    
    if not target_id:
        await message.reply_text("❌ Укажите пользователя")
        return
    
    try:
        # Unmute user
        permissions = ChatPermissions(
            can_send_messages=True,
            can_send_media_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True
        )
        
        await chat.restrict_member(target_id, permissions)
        
        await message.reply_text(
            f"🔊 Пользователь {target_mention} размучен",
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Log
        await db.db.admin_actions.insert_one({
            "chat_id": chat.id,
            "admin_id": update.effective_user.id,
            "action": "unmute",
            "target_id": target_id,
            "timestamp": datetime.utcnow()
        })
        
    except Exception as e:
        await message.reply_text(f"❌ Ошибка: {e}")

@admin_only
@log_command
async def ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ban user from chat"""
    message = update.effective_message
    chat = update.effective_chat
    
    if chat.type == 'private':
        await message.reply_text("❌ Эта команда работает только в группах")
        return
    
    args = context.args
    ban_seconds = None
    
    # Check if time specified
    if args and args[0].replace('m', '').replace('h', '').replace('d', '').isdigit():
        time_str = args[0]
        ban_seconds = parse_time_string(time_str)
        target_text = ' '.join(args[1:])
    else:
        target_text = ' '.join(args)
    
    # Extract user
    message.text = target_text
    target_id, target_mention = extract_user(message)
    
    if not target_id:
        await message.reply_text("❌ Укажите пользователя")
        return
    
    try:
        # Check if user is admin
        member = await chat.get_member(target_id)
        if member.status in ['creator', 'administrator']:
            await message.reply_text("❌ Нельзя забанить администратора")
            return
        
        # Ban user
        if ban_seconds:
            until_date = datetime.now() + timedelta(seconds=ban_seconds)
            await chat.ban_member(target_id, until_date=until_date)
            
            # Format time
            if ban_seconds < 60:
                time_display = f"{ban_seconds} сек"
            elif ban_seconds < 3600:
                time_display = f"{ban_seconds // 60} мин"
            elif ban_seconds < 86400:
                time_display = f"{ban_seconds // 3600} ч"
            else:
                time_display = f"{ban_seconds // 86400} д"
            
            await message.reply_text(
                f"🔨 Пользователь {target_mention} забанен на {time_display}",
                parse_mode=ParseMode.MARKDOWN
            )
        else:
            await chat.ban_member(target_id)
            await message.reply_text(
                f"🔨 Пользователь {target_mention} забанен навсегда",
                parse_mode=ParseMode.MARKDOWN
            )
        
        # Log
        await db.db.admin_actions.insert_one({
            "chat_id": chat.id,
            "admin_id": update.effective_user.id,
            "action": "ban",
            "target_id": target_id,
            "duration": ban_seconds,
            "timestamp": datetime.utcnow()
        })
        
    except Exception as e:
        await message.reply_text(f"❌ Ошибка: {e}")

@admin_only
@log_command
async def unban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unban user from chat"""
    message = update.effective_message
    chat = update.effective_chat
    
    if chat.type == 'private':
        await message.reply_text("❌ Эта команда работает только в группах")
        return
    
    # Extract user
    target_id, target_mention = extract_user(message)
    
    if not target_id:
        await message.reply_text("❌ Укажите пользователя")
        return
    
    try:
        await chat.unban_member(target_id)
        
        await message.reply_text(
            f"✅ Пользователь {target_mention} разбанен",
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Log
        await db.db.admin_actions.insert_one({
            "chat_id": chat.id,
            "admin_id": update.effective_user.id,
            "action": "unban",
            "target_id": target_id,
            "timestamp": datetime.utcnow()
        })
        
    except Exception as e:
        await message.reply_text(f"❌ Ошибка: {e}")

@admin_only
@log_command
async def chat_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View/edit chat settings"""
    message = update.effective_message
    chat = update.effective_chat
    
    if chat.type == 'private':
        await message.reply_text("❌ Эта команда работает только в группах")
        return
    
    # Get or create chat settings
    settings = await db.db.chat_settings.find_one({"chat_id": chat.id})
    
    if not settings:
        settings = {
            "chat_id": chat.id,
            "chat_title": chat.title,
            "rp_enabled": True,
            "relations_enabled": True,
            "welcome_enabled": True,
            "welcome_message": "👋 Добро пожаловать, {name}!",
            "log_channel": None,
            "created_at": datetime.utcnow()
        }
        await db.db.chat_settings.insert_one(settings)
    
    settings_text = (
        f"⚙️ **Настройки чата**\n\n"
        f"Чат: {chat.title}\n\n"
        f"🎭 RP команды: {'✅' if settings.get('rp_enabled') else '❌'}\n"
        f"💑 Отношения: {'✅' if settings.get('relations_enabled') else '❌'}\n"
        f"👋 Приветствия: {'✅' if settings.get('welcome_enabled') else '❌'}\n\n"
        
        f"**Команды для изменения:**\n"
        f".settings rp on/off - RP команды\n"
        f".settings relations on/off - Отношения\n"
        f".settings welcome on/off - Приветствия\n"
        f".settings welcome_msg <текст> - текст приветствия (используй {{name}})"
    )
    
    await message.reply_text(
        settings_text,
        parse_mode=ParseMode.MARKDOWN
    )

async def track_chat_members(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Track chat members for stats"""
    chat_member = update.chat_member
    
    # Log member changes
    await db.db.chat_members_log.insert_one({
        "chat_id": chat_member.chat.id,
        "user_id": chat_member.new_chat_member.user.id,
        "old_status": chat_member.old_chat_member.status,
        "new_status": chat_member.new_chat_member.status,
        "timestamp": datetime.utcnow()
    })