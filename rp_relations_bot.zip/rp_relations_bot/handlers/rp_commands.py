import logging
import random
import re
from datetime import datetime, timedelta
from telegram import Update, InlineQueryResultArticle, InputTextMessageContent
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from database import db
from utils.constants import STANDARD_RP_COMMANDS
from utils.decorators import require_user, check_ignore, rate_limit, log_command
from utils.helpers import extract_user, validate_emoji_string, validate_command_name, validate_command_template, get_user_mention

logger = logging.getLogger(__name__)

@require_user
@check_ignore
@rate_limit(2)  # 2 seconds cooldown
@log_command
async def handle_rp_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle standard RP commands"""
    user = update.effective_user
    message = update.effective_message
    
    # Get command name (without dot)
    command = message.text.split()[0][1:].lower()
    
    # Extract target user
    target_id, target_mention = extract_user(message)
    
    if not target_id:
        await message.reply_text(
            "❌ Укажите пользователя (ответом на сообщение или упоминанием)"
        )
        return
    
    # Check if self-targeting
    if target_id == user.id:
        await message.reply_text("❌ Нельзя использовать команду на себя")
        return
    
    # Check ignore list
    if await db.is_ignored(user.id, target_id):
        await message.reply_text("❌ Этот пользователь добавил вас в игнор-лист")
        return
    
    # Get command data
    cmd_data = STANDARD_RP_COMMANDS.get(command)
    if not cmd_data:
        # Check custom commands
        custom_cmd = await db.get_custom_command(user.id, command)
        if custom_cmd:
            await handle_custom_command(update, context, custom_cmd, target_id, target_mention)
            return
        else:
            await message.reply_text(f"❌ Команда .{command} не найдена")
            return
    
    # Get user mention
    user_mention = get_user_mention(user)
    
    # Get optional message text (after new line)
    message_text = ""
    if '\n' in message.text:
        parts = message.text.split('\n', 1)
        message_text = parts[1].strip()
    
    # Format response
    response = cmd_data["template"].format(
        user=user_mention,
        target=target_mention
    )
    
    if message_text:
        response += f"\n\n_{message_text}_"
    
    # Add emoji
    response = f"{cmd_data['emoji']} {response}"
    
    # Send response
    await message.reply_text(
        response,
        parse_mode=ParseMode.MARKDOWN
    )
    
    # Update stats
    await db.db.users.update_one(
        {"user_id": user.id},
        {"$inc": {"stats.total_commands_used": 1}}
    )
    
    # Small chance to get spark (if premium)
    db_user = await db.get_user(user.id)
    if db_user and db_user.get('vip_until'):
        if random.random() < 0.2:  # 20% chance
            # Check if user has active relation with target
            relation = await db.get_relation(user.id, target_id)
            if relation:
                await db.add_sparks(relation["_id"], 1, f"rp_command_{command}")
                await message.reply_text("✨ +1 искра за RP действие!")

async def handle_custom_command(update: Update, context: ContextTypes.DEFAULT_TYPE, 
                                cmd_data: dict, target_id: int, target_mention: str):
    """Handle custom RP command"""
    user = update.effective_user
    message = update.effective_message
    
    # Increment usage
    await db.increment_command_use(user.id, cmd_data["command_name"])
    
    # Get user mention
    user_mention = get_user_mention(user)
    
    # Get optional message text
    message_text = ""
    if '\n' in message.text:
        parts = message.text.split('\n', 1)
        message_text = parts[1].strip()
    
    # Format response
    response = cmd_data["text_template"]
    response = response.replace('%u', user_mention)
    response = response.replace('%t', target_mention)
    
    if message_text:
        response += f"\n\n_{message_text}_"
    
    # Add emoji
    response = f"{cmd_data['emoji']} {response}"
    
    await message.reply_text(
        response,
        parse_mode=ParseMode.MARKDOWN
    )

@require_user
@log_command
async def list_all_rp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all standard RP commands"""
    user = update.effective_user
    
    # Get user's custom commands
    custom_commands = await db.get_custom_commands(user.id)
    custom_list = "\n".join([f"  .{cmd['command_name']} {cmd['emoji']}" for cmd in custom_commands])
    
    # Group standard commands
    categories = {
        "💕 Романтика": ["поцеловать", "обнять", "флиртовать", "подмигнуть", "прижать"],
        "🔞 18+": ["трахнуть", "выебать", "изнасиловать", "отсосать", "отлизать", "лап", "сесть"],
        "👊 Насилие": ["ударить", "пнуть", "уебать", "вмазать", "пощечина", "щелбан"],
        "🤝 Дружеские": ["пожать руку", "дать пять", "поклониться", "подбодрить", "аплодировать"],
        "🎭 Остальные": []
    }
    
    text = "📋 **Список всех RP команд**\n\n"
    
    for category, commands in categories.items():
        cat_commands = []
        for cmd in commands:
            if cmd in STANDARD_RP_COMMANDS:
                emoji = STANDARD_RP_COMMANDS[cmd]["emoji"]
                cat_commands.append(f".{cmd} {emoji}")
        
        if cat_commands:
            text += f"{category}\n"
            text += "\n".join([f"  {c}" for c in cat_commands])
            text += "\n\n"
    
    # Add uncategorized
    uncategorized = []
    for cmd, data in STANDARD_RP_COMMANDS.items():
        if not any(cmd in cat for cat in categories.values()):
            uncategorized.append(f".{cmd} {data['emoji']}")
    
    if uncategorized:
        text += "📌 **Другие**\n"
        text += "\n".join([f"  {c}" for c in uncategorized[:10]])
        if len(uncategorized) > 10:
            text += f"\n  ...и ещё {len(uncategorized) - 10}"
        text += "\n\n"
    
    if custom_commands:
        text += "✨ **Ваши личные команды**\n"
        text += custom_list
    
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN
    )

@require_user
@log_command
async def create_custom_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Create custom RP command"""
    user = update.effective_user
    message = update.effective_message
    
    # Check format
    parts = message.text.split('\n')
    if len(parts) < 4:
        await message.reply_text(
            "❌ Неправильный формат. Используйте:\n"
            ".срп\n"
            "<команда>\n"
            "<эмодзи>\n"
            "<текст>\n\n"
            "В тексте обязательно используйте %u (вы) и %t (цель)\n"
            "Пример:\n"
            ".срп\n"
            "облизнуть\n"
            "😋\n"
            "%u облизнул(а) %t"
        )
        return
    
    command_name = parts[1].strip().lower()
    emoji_str = parts[2].strip()
    template = parts[3].strip()
    
    # Validate
    if not validate_command_name(command_name):
        await message.reply_text(
            "❌ Неверное имя команды. Используйте только буквы, цифры и _, максимум 20 символов"
        )
        return
    
    if not validate_emoji_string(emoji_str):
        await message.reply_text(
            "❌ Неверный формат эмодзи. Используйте только эмодзи (максимум 4)"
        )
        return
    
    if not validate_command_template(template):
        await message.reply_text(
            "❌ Неверный формат текста. Максимум 200 символов, обязательно используйте %u и %t"
        )
        return
    
    # Check if command already exists (standard or custom)
    if command_name in STANDARD_RP_COMMANDS:
        await message.reply_text(f"❌ Команда .{command_name} уже существует как стандартная")
        return
    
    existing = await db.get_custom_command(user.id, command_name)
    if existing:
        await message.reply_text(f"❌ У вас уже есть команда .{command_name}")
        return
    
    # Check limits
    custom_commands = await db.get_custom_commands(user.id)
    db_user = await db.get_user(user.id)
    
    max_commands = 50 if db_user and db_user.get('vip_until') else 3
    
    if len(custom_commands) >= max_commands:
        limit_text = f"Вы достигли лимита ({max_commands} команд). Удалите ненужные через .урп"
        await message.reply_text(limit_text)
        return
    
    # Create command
    await db.add_custom_command(user.id, command_name, emoji_str, template)
    
    await message.reply_text(
        f"✅ Команда .{command_name} успешно создана!\n"
        f"Используйте её как обычную RP команду"
    )

@require_user
@log_command
async def my_custom_commands(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List user's custom commands"""
    user = update.effective_user
    commands = await db.get_custom_commands(user.id)
    
    if not commands:
        await update.message.reply_text(
            "❌ У вас пока нет личных RP команд.\n"
            "Создайте через .срп"
        )
        return
    
    text = "📋 **Ваши личные RP команды**\n\n"
    
    for cmd in commands:
        text += f"`.{cmd['command_name']}` {cmd['emoji']}\n"
        text += f"  Шаблон: {cmd['text_template'][:50]}{'...' if len(cmd['text_template']) > 50 else ''}\n"
        text += f"  Использований: {cmd.get('uses', 0)}\n\n"
    
    text += f"Всего: {len(commands)}/{50 if await db.get_user(user.id) and db.get_user(user.id).get('vip_until') else 3}"
    
    await update.message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN
    )

@require_user
@log_command
async def delete_custom_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete custom command"""
    args = context.args
    if not args:
        await update.message.reply_text(
            "❌ Использование: .урп <команда>\n"
            "Пример: .урп облизнуть"
        )
        return
    
    command_name = args[0].lower()
    
    # Check if exists
    cmd = await db.get_custom_command(update.effective_user.id, command_name)
    if not cmd:
        await update.message.reply_text(f"❌ Команда .{command_name} не найдена")
        return
    
    # Delete
    await db.delete_custom_command(update.effective_user.id, command_name)
    
    await update.message.reply_text(f"✅ Команда .{command_name} удалена")

@require_user
@log_command
async def ignore_list_manager(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manage ignore list"""
    user = update.effective_user
    message = update.effective_message
    args = context.args
    
    # Get ignore list
    ignore_list = await db.get_ignore_list(user.id)
    db_user = await db.get_user(user.id)
    max_ignore = 20 if db_user and db_user.get('vip_until') else 3
    
    # No args - show list
    if not args:
        if not ignore_list:
            await message.reply_text(
                f"📋 Ваш игнор-лист пуст\n"
                f"Лимит: {len(ignore_list)}/{max_ignore}\n\n"
                f"Добавить: .ирп добавить @user\n"
                f"Удалить: .ирп удалить @user"
            )
            return
        
        # Get user info for each ignored user
        text = "📋 **Ваш игнор-лист**\n\n"
        
        for ignored_id in ignore_list:
            try:
                ignored_user = await context.bot.get_chat(ignored_id)
                name = ignored_user.first_name
                username = f" (@{ignored_user.username})" if ignored_user.username else ""
                text += f"• {name}{username}\n"
            except:
                text += f"• Пользователь {ignored_id}\n"
        
        text += f"\nЛимит: {len(ignore_list)}/{max_ignore}"
        
        await message.reply_text(
            text,
            parse_mode=ParseMode.MARKDOWN
        )
        return
    
    # With args - add/remove
    action = args[0].lower()
    
    # Extract target user
    target_id, target_mention = extract_user(message)
    
    if not target_id:
        await message.reply_text(
            "❌ Укажите пользователя (ответом, @username или uid:123456)"
        )
        return
    
    if target_id == user.id:
        await message.reply_text("❌ Нельзя добавить себя в игнор-лист")
        return
    
    if action == "добавить":
        if target_id in ignore_list:
            await message.reply_text("❌ Этот пользователь уже в игнор-листе")
            return
        
        if len(ignore_list) >= max_ignore:
            await message.reply_text(
                f"❌ Достигнут лимит игнор-листа ({max_ignore} пользователей)"
            )
            return
        
        await db.add_to_ignore(user.id, target_id)
        await message.reply_text(f"✅ Пользователь добавлен в игнор-лист")
    
    elif action == "удалить":
        if target_id not in ignore_list:
            await message.reply_text("❌ Этого пользователя нет в игнор-листе")
            return
        
        await db.remove_from_ignore(user.id, target_id)
        await message.reply_text(f"✅ Пользователь удалён из игнор-листа")
    
    else:
        await message.reply_text(
            "❌ Использование:\n"
            ".ирп - показать список\n"
            ".ирп добавить @user - добавить\n"
            ".ирп удалить @user - удалить"
        )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle regular messages (for potential spark gains)"""
    # This can be expanded for passive spark gains
    pass

async def inline_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Inline mode for RP commands"""
    query = update.inline_query.query.lower()
    
    if not query:
        return
    
    results = []
    
    # Search standard commands
    for cmd, data in STANDARD_RP_COMMANDS.items():
        if query in cmd:
            results.append(
                InlineQueryResultArticle(
                    id=f"std_{cmd}",
                    title=f".{cmd} {data['emoji']}",
                    description=data["template"],
                    input_message_content=InputTextMessageContent(
                        f"{data['emoji']} {data['template']}",
                        parse_mode=ParseMode.MARKDOWN
                    )
                )
            )
    
    # Add custom commands if user
    if update.inline_query.from_user:
        user_id = update.inline_query.from_user.id
        custom_cmds = await db.get_custom_commands(user_id)
        
        for cmd in custom_cmds:
            if query in cmd["command_name"]:
                results.append(
                    InlineQueryResultArticle(
                        id=f"custom_{cmd['command_name']}",
                        title=f".{cmd['command_name']} {cmd['emoji']} (личная)",
                        description=cmd["text_template"],
                        input_message_content=InputTextMessageContent(
                            f"{cmd['emoji']} {cmd['text_template']}",
                            parse_mode=ParseMode.MARKDOWN
                        )
                    )
                )
    
    await update.inline_query.answer(results[:50], cache_time=1)